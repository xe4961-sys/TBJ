using FuseTimer.Core;

int passed = 0;
void Test(string name, Action check) { check(); Console.WriteLine($"PASS {name}"); passed++; }
void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
void Near(double expected, double actual) { if (Math.Abs(expected - actual) > .000001) throw new Exception($"Expected {expected}, got {actual}"); }
void True(bool value) { if (!value) throw new Exception("Expected true"); }

Test("3-second deadline and one detonation", () => {
    var timer = new Countdown(); timer.Start(100);
    Near(3, timer.Advance(100).Remaining);
    Near(1.5, timer.Advance(101.5).Remaining);
    Equal(CountdownPhase.Counting, timer.Advance(102.999).Phase);
    var end = timer.Advance(103); True(end.Detonate); Near(0, end.Remaining); Equal(CountdownPhase.Detonated, end.Phase);
    True(!timer.Advance(104).Detonate);
});
Test("restart replaces the previous deadline", () => {
    var timer = new Countdown(); timer.Start(0); timer.Advance(2.5); timer.Start(2.5);
    Near(3, timer.Advance(2.5).Remaining); True(!timer.Advance(3).Detonate); True(timer.Advance(5.5).Detonate);
});
Test("late wake-up detonates once without negative time or missed-tick bursts", () => {
    var timer = new Countdown(); timer.Start(0);
    var late = timer.Advance(20); True(late.Detonate); True(!late.Tick); Near(0, late.Remaining); True(!timer.Advance(21).Detonate);
});
Test("ticks accelerate and never replay on duplicate updates", () => {
    var timer = new Countdown(); timer.Start(0);
    double[] times = [0, .75, 1.35, 1.86, 2.22, 2.49, 2.7, 2.85, 2.94];
    foreach (double time in times) { True(timer.Advance(time + .000001).Tick); True(!timer.Advance(time + .000001).Tick); }
    True(timer.Advance(3).Detonate);
    for (int i = 1; i < times.Length - 1; i++) True(times[i + 1] - times[i] < times[i] - times[i - 1]);
});
Test("cancel prevents an old detonation and restores the configured duration", () => {
    var timer = new Countdown(); timer.Start(0); timer.Reset(4); var frame = timer.Advance(5);
    Equal(CountdownPhase.Ready, frame.Phase); Near(4, frame.Remaining); True(!frame.Detonate);
});
Test("holding a key starts once; releasing and pressing starts again", () => {
    var edge = new PressEdge(); True(edge.Sample(true)); True(!edge.Sample(true)); True(!edge.Sample(true));
    True(!edge.Sample(false)); True(edge.Sample(true));
});
Test("enabling while held does not trigger; key-capture release does not start a countdown", () => {
    var edge = new PressEdge(); True(!edge.Sample(true, false)); True(!edge.Sample(true));
    edge.Synchronize(true); True(!edge.Sample(true)); True(!edge.Sample(false)); True(edge.Sample(true));
});
Test("custom fuse duration is used for timing and reset", () => {
    var timer = new Countdown(); timer.Start(10, 2.75); Near(1.75, timer.Advance(11).Remaining); True(timer.Advance(12.75).Detonate);
    timer.Reset(2.75); Near(2.75, timer.Advance(15).Remaining);
});
Test("invalid durations and timestamps are rejected", () => {
    foreach (double value in new[] { 0, -.5, 61, double.NaN, double.PositiveInfinity }) {
        try { new Countdown().Start(0, value); throw new Exception("Accepted invalid duration"); }
        catch (ArgumentOutOfRangeException) { }
    }
    try { new Countdown().Start(double.NaN); throw new Exception("Accepted invalid timestamp"); }
    catch (ArgumentOutOfRangeException) { }
});
Console.WriteLine($"{passed} tests passed.");
