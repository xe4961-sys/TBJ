using FuseTimer.Core;
using System.Text;

int passed = 0;
void Test(string name, Action check) { check(); Console.WriteLine($"PASS {name}"); passed++; }
void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
void Near(double expected, double actual, double tolerance = .000001) { if (Math.Abs(expected - actual) > tolerance) throw new Exception($"Expected {expected}, got {actual}"); }
void True(bool value) { if (!value) throw new Exception("Expected true"); }
short[] Samples(byte[] wave) => Enumerable.Range(0, (wave.Length - 44) / 2).Select(i => BitConverter.ToInt16(wave, 44 + i * 2)).ToArray();
double Rms(short[] samples, double start, double end) => Math.Sqrt(samples.Skip((int)(start * AudioClips.SampleRate)).Take((int)((end - start) * AudioClips.SampleRate)).Average(value => (double)value * value));

Test("3 seconds then ARMED 0.2s then RELEASE 0.5s, without an explosion", () => {
    var timer = new Countdown(); timer.Start(0);
    Near(3, timer.Advance(0).Remaining); Near(1.5, timer.Advance(1.5).Remaining);
    Equal(CountdownPhase.Counting, timer.Advance(2.9999).Phase);
    var armed = timer.Advance(3); Equal(CountdownPhase.Armed, armed.Phase); Near(0, armed.Remaining); True(armed.Tick);
    Equal(CountdownPhase.Armed, timer.Advance(3.1999).Phase);
    Equal(CountdownPhase.Release, timer.Advance(3.2).Phase);
    Equal(CountdownPhase.Release, timer.Advance(3.6999).Phase);
    var done = timer.Advance(3.7); Equal(CountdownPhase.Complete, done.Phase); True(!done.Tick);
    Equal(CountdownPhase.Complete, timer.Advance(4).Phase); True(!timer.Advance(5).Tick);
});
Test("restart replaces the deadline even during warning phases", () => {
    foreach (double when in new[] { 2.5, 3.1, 3.5, 4.0 }) {
        var timer = new Countdown(); timer.Start(0); timer.Advance(when); timer.Start(when);
        Near(3, timer.Advance(when).Remaining); Equal(CountdownPhase.Counting, timer.Advance(when + 2.9).Phase);
        Equal(CountdownPhase.Armed, timer.Advance(when + 3.00001).Phase);
    }
});
Test("late wake-up does not replay an expired warning", () => {
    var timer = new Countdown(); timer.Start(0);
    var late = timer.Advance(20); Equal(CountdownPhase.Complete, late.Phase); True(!late.Tick); Near(0, late.Remaining);
    True(!timer.Advance(21).Tick);
});
Test("late wake-up enters the current phase and emits at most one cue", () => {
    var timer = new Countdown(); timer.Start(0);
    var late = timer.Advance(3.4); Equal(CountdownPhase.Release, late.Phase); True(late.Tick);
    True(!timer.Advance(3.4).Tick);
});
Test("normal countdown ticks accelerate without repeating", () => {
    var timer = new Countdown(); timer.Start(0);
    double[] times = [0, .75, 1.35, 1.86, 2.22, 2.49, 2.7, 2.85, 2.94];
    foreach (double time in times) { True(timer.Advance(time + .000001).Tick); True(!timer.Advance(time + .000001).Tick); }
    for (int i = 1; i < times.Length - 1; i++) True(times[i + 1] - times[i] < times[i] - times[i - 1]);
});
Test("urgent beeps repeat across ARMED and RELEASE on a shared schedule", () => {
    var timer = new Countdown(); timer.Start(0);
    for (int index = 0; index < 8; index++) {
        double now = 3 + index * Countdown.WarningTickSeconds + .000001;
        True(timer.Advance(now).Tick); True(!timer.Advance(now).Tick);
    }
    True(!timer.Advance(3.7).Tick);
});
Test("cancel during a warning stops future warnings and restores the configured duration", () => {
    var timer = new Countdown(); timer.Start(0); timer.Advance(3.3); timer.Reset(4);
    var frame = timer.Advance(5); Equal(CountdownPhase.Ready, frame.Phase); Near(4, frame.Remaining); True(!frame.Tick);
});
Test("holding a key fires once; a fresh press restarts", () => {
    var edge = new PressEdge(); True(edge.Sample(true)); True(!edge.Sample(true)); True(!edge.Sample(true));
    True(!edge.Sample(false)); True(edge.Sample(true));
});
Test("enabling while held and completing key capture do not trigger", () => {
    var edge = new PressEdge(); True(!edge.Sample(true, false)); True(!edge.Sample(true));
    edge.Synchronize(true); True(!edge.Sample(true)); True(!edge.Sample(false)); True(edge.Sample(true));
});
Test("the controls binding has its own independent press edge", () => {
    var grenade = new PressEdge(); var controls = new PressEdge();
    True(grenade.Sample(true)); True(controls.Sample(true));
    True(!grenade.Sample(true)); True(!controls.Sample(true));
    controls.Sample(false); True(controls.Sample(true)); True(!grenade.Sample(true));
});
Test("custom countdown keeps ARMED and RELEASE durations unchanged", () => {
    var timer = new Countdown(); timer.Start(10, 2.75); Near(1.75, timer.Advance(11).Remaining);
    Equal(CountdownPhase.Armed, timer.Advance(12.75).Phase);
    Equal(CountdownPhase.Release, timer.Advance(12.95001).Phase);
    Equal(CountdownPhase.Complete, timer.Advance(13.45001).Phase);
});
Test("only-while-primed hides idle and completed timers and shows all active stages", () => {
    True(!OverlayPolicy.Visible(CountdownPhase.Ready, true)); True(!OverlayPolicy.Visible(CountdownPhase.Complete, true));
    foreach (var phase in new[] { CountdownPhase.Counting, CountdownPhase.Armed, CountdownPhase.Release }) True(OverlayPolicy.Visible(phase, true));
});
Test("positioning preview and always-visible mode can display an idle timer", () => {
    True(OverlayPolicy.Visible(CountdownPhase.Ready, true, true));
    True(OverlayPolicy.Visible(CountdownPhase.Ready, false)); True(OverlayPolicy.Visible(CountdownPhase.Complete, false));
});
Test("warning flashing can be disabled and never makes the text disappear", () => {
    for (int i = 0; i < 100; i++) {
        double age = i / 100.0;
        Near(1, OverlayPolicy.WarningOpacity(false, age));
        double alpha = OverlayPolicy.WarningOpacity(true, age); True(alpha >= .55 && alpha <= 1);
    }
});
Test("beep WAVs have valid PCM headers, smooth zero endpoints, and no clipping", () => {
    foreach (bool urgent in new[] { false, true }) {
        byte[] wave = AudioClips.Beep(urgent, 1);
        Equal("RIFF", Encoding.ASCII.GetString(wave, 0, 4)); Equal("WAVE", Encoding.ASCII.GetString(wave, 8, 4));
        Equal(16, (int)BitConverter.ToInt16(wave, 34)); Equal(AudioClips.SampleRate, BitConverter.ToInt32(wave, 24));
        Equal(wave.Length - 44, BitConverter.ToInt32(wave, 40));
        short[] samples = Samples(wave); Equal((short)0, samples[0]); Equal((short)0, samples[^1]);
        True(samples.Max(sample => Math.Abs((int)sample)) < short.MaxValue * .5);
        True(samples.Length / (double)AudioClips.SampleRate < (urgent ? .06 : .1));
    }
});
Test("beeps sustain a pitched middle instead of decaying into a popping tick", () => {
    foreach (bool urgent in new[] { false, true }) {
        var samples = Samples(AudioClips.Beep(urgent, 1));
        double early = Rms(samples, .010, .025), later = Rms(samples, .025, .040);
        True(early > 1000); True(later > early * .85 && later < early * 1.15);
        var middle = samples.Skip((int)(.01 * AudioClips.SampleRate)).Take((int)(.04 * AudioClips.SampleRate)).ToArray();
        int crossings = Enumerable.Range(1, middle.Length - 1).Count(i => middle[i - 1] <= 0 && middle[i] > 0);
        Near(urgent ? 2200 : 1600, crossings / .04, 60);
    }
});
Test("zero volume is silent and volume scaling is proportional", () => {
    True(Samples(AudioClips.Beep(true, 0)).All(value => value == 0));
    double full = Rms(Samples(AudioClips.Beep(false, 1)), .015, .03);
    double half = Rms(Samples(AudioClips.Beep(false, .5)), .015, .03);
    Near(.5, half / full, .002);
});
Test("invalid durations and timestamps are rejected", () => {
    foreach (double value in new[] { 0, -.5, 61, double.NaN, double.PositiveInfinity }) {
        try { new Countdown().Start(0, value); throw new Exception("Accepted invalid duration"); } catch (ArgumentOutOfRangeException) { }
    }
    try { new Countdown().Start(double.NaN); throw new Exception("Accepted invalid timestamp"); } catch (ArgumentOutOfRangeException) { }
});
Console.WriteLine($"{passed} tests passed.");
