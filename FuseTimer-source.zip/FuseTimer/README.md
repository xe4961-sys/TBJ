# Fuse Timer 1.2.2

A portable Windows x64 grenade-release timing aid. It starts hidden, leaving only a tray icon. Press **G** to show the transparent, borderless countdown; **F8** opens or hides settings. Both bindings are configurable, and grenade input is observed rather than consumed or replayed.

## Timing

| Time after the grenade key | Overlay and sound |
| --- | --- |
| 0–3.00 seconds | Numeric countdown; accelerating sharp electronic beeps |
| 3.00–3.20 seconds | **ARMED**, urgent high-pitched beeps |
| 3.20–3.70 seconds | **RELEASE!**, urgent high-pitched beeps |
| 3.70–4.00 seconds | **BULLSEYE!!**, steady green text; warning audio stops |
| After 4.00 seconds | Overlay hides when Only show while primed is enabled |

BULLSEYE!! marks the estimated airburst window; there is no added explosion sound or spoken voice. The app does not detect the game's actual detonation. `Seconds until ARMED` is configurable from 0.50 to 15.00; the ARMED, RELEASE, and BULLSEYE phases remain 0.20s, 0.50s, and 0.30s respectively. Restarting the grenade key starts a fresh sequence in any phase. Holding the key triggers once.

## Run and update

Exit the previous version from its tray icon first. Extract `FuseTimer-Windows-x64.zip` and run the new `FuseTimer.exe` on Windows 10/11 x64. It is self-contained and needs no separate .NET installation. Initial runtime extraction can take a few seconds.

**It starts hidden.** Press F8 (default) or double-click the clock icon in the system tray to open controls. Closing/minimizing the controls hides them; **Exit app** or tray **Exit** stops the process. It does not register itself to launch at Windows startup.

## Controls

- **Change key:** select either the grenade binding or controls binding, release the mouse/keys, then press a single key or Mouse middle/4/5. Escape cancels, and capture times out after 15 seconds. Chords and left/right mouse buttons are not capture targets. The two bindings must differ. If an old profile uses F8 for grenades, controls fall back to F9.
- **Sound on / muted**, **Volume:** mute or scale all countdown and warning sounds. Sharp beeps use a short attack, a steady pitched middle, and smooth release, rather than a rapidly decaying click. Final-second and warning beeps use a higher pitch. No sound plays at startup.
- **Test sound:** plays a 0.45-second electronic beep using the current mute/volume settings and refreshes the default audio-device connection. It cancels any active countdown. A visible message reports Windows audio errors; failed playback does not permanently disable later attempts.
- **Windows mixer:** opens Windows app volume/output settings. Check FuseTimer is unmuted and routed to the intended speakers/headphones.
- **Only show while primed:** enabled by default. The overlay appears on the grenade key and disappears at the end of BULLSEYE!!. Uncheck to leave a static idle/completed timer visible.
- **Gentle warning flashes:** optional, off by default. Pulse only the ARMED/RELEASE text at 2 Hz, keeping it legible and never fully invisible. Independent of mute.
- **Position overlay:** show an interactive preview, drag the digits to move it, then select Done positioning. Position is saved. In normal play, the overlay is click-through and does not steal keyboard focus.
- **Hotkey enabled:** pause/resume grenade triggering. Pausing cancels the current sequence. The controls key and manual Start remain available.

The overlay is an always-on-top, no-activate, per-pixel alpha window. It draws only text and a subtle glyph outline, without a rectangle, white border, title bar, or taskbar entry. Borderless fullscreen/windowed games work best; exclusive fullscreen can cover ordinary desktop overlays. The settings window is a normal window only when explicitly opened.

## Implementation

A hidden `ApplicationContext` keeps the Windows message loop, key polling, and tray icon alive without opening a main window. `GetAsyncKeyState` samples only the two configured keys outside capture; it does not register an exclusive shortcut, inject input, read game memory, or retain input history. Key bindings work globally, including outside the game.

The sequence uses a monotonic `Stopwatch` deadline. Delayed UI updates skip missed beeps and enter the current phase instead of replaying expired warnings. Actual display/audio still depends on Windows scheduling; this is a manual timing aid, not game synchronization. PCM WAV data is generated locally, with no external audio downloads or runtime network access. Version 1.2.1 replaces SoundPlayer with direct waveOut PCM playback, checks native error results, and retains prepared buffers until playback returns them. It uses the default Windows audio device; Test sound reconnects after an output-device change.

Preferences are stored at `%LOCALAPPDATA%\FuseTimer\settings.json`. Existing key, duration, volume, and mute settings are retained. Old unused display settings are ignored. Invalid controls-key collisions are normalized. Unavailable preference storage leaves the session usable.

## Build

Use the official .NET 10 SDK specified by `global.json`:

```powershell
dotnet run --project tests/FuseTimer.Tests -c Release
dotnet publish src/FuseTimer.App -c Release -r win-x64 --self-contained true -o artifacts/win-x64
```

`build.ps1` runs the tests and creates the release ZIP. The GitHub workflow is provided in the source archive for a future separate source repository. Publishing the downloadable ZIP to the `fuse-timer-download` branch does not change TBJ's `main` or its website.

## Validation

- 25 tests cover exact warning and BULLSEYE boundaries, restarts, cancellation, delayed frames, accelerating/urgent cue schedules, independent key edges, visibility and positioning rules, flashing bounds, and generated PCM headers, endpoints, sustain, pitch, clipping, and volume. Audio-control tests use a fake output to verify mute, correct cue selection, the longer preview, error feedback/recovery, and disposal; they do not exercise Windows drivers or speakers.
- The Windows executable is cross-compiled on Linux and unsigned. It is self-contained and targets Windows x64.
- Native Windows transparency, click-through/drag behavior, actual key input, and speaker output cannot be executed on this Linux build machine and still need testing on Windows.
