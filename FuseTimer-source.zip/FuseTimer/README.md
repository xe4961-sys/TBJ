# Fuse Timer

A separate, portable Windows grenade countdown app. Default: **G** starts or restarts a **3.00-second** countdown. Beeps accelerate toward zero, then a locally generated explosion sound plays and a burst/💥 is shown in the visible window. The countdown and audio continue while minimized.

## Use

Download and extract `FuseTimer-Windows-x64.zip`, then run `FuseTimer.exe` on Windows 10/11 x64. It is self-contained and needs no separate .NET installation. First launch can take a few seconds while the bundled native runtime extracts.

- **Change key:** click, release all keys/buttons, then press the grenade key. Capture times out after 15 seconds; Escape cancels. Supports a single keyboard key or Mouse middle/4/5. Chords and left/right mouse buttons are not capture targets.
- **Hotkey enabled:** pause/resume background triggering. Pausing cancels the current countdown. The manual Start button still works.
- **Sound on / Sound muted:** turn all audio on/off. Volume is configurable.
- **Start / restart / Cancel:** test manually without entering the game.
- **Grenade fuse:** defaults to 3 seconds; adjustable from 0.50 to 15.00 seconds.
- **Always on top / Hide settings:** keep a smaller visible counter over ordinary windows. Exclusive-fullscreen games can cover it; borderless/windowed mode is needed for a visible overlay in that case. A minimized window cannot show its 💥; audio still runs.
- Restore from the taskbar or the tray icon. Closing exits. Nothing installs into startup.

The app polls `GetAsyncKeyState` for the configured key and detects rising edges. It neither registers an exclusive hotkey nor consumes, synthesizes, or replays input, so the same key can reach the game. Holding the key triggers once, releasing and pressing restarts. Enabling while a key is already held does not trigger. Key capture does not start the timer itself. Outside capture, it checks only the configured key; it does not save input history or read game memory.

This is a global key-driven timing aid. It does not detect grenades, game state, network delay, or the game's internal fuse start. Countdowns are based on a monotonic `Stopwatch` deadline rather than repeatedly subtracting UI timer intervals. Delayed frames do not accumulate countdown drift, but actual sound/display still depends on Windows scheduling. Adjust the fuse for your game's behavior if needed.

Settings are saved to `%LOCALAPPDATA%\FuseTimer\settings.json`. Invalid/unreadable settings fall back to defaults. Failed saving leaves the app usable for the current session. Tick and explosion audio is synthesized locally as PCM WAV data. No audio downloads or network access are used at runtime.

## Build

Use the official .NET 10 SDK specified by `global.json`. From this directory:

```powershell
dotnet run --project tests/FuseTimer.Tests -c Release
dotnet publish src/FuseTimer.App -c Release -r win-x64 --self-contained true -o artifacts/win-x64
```

`build.ps1` runs those checks and creates the release ZIP. The optional GitHub Actions workflow builds and uploads the Windows artifact when this project is put in its own repository; it has not been uploaded to GitHub or deployed alongside TBJ.

The core tests run on Linux and Windows without third-party test dependencies. The app targets Windows Forms and requires Windows to execute. Cross-compilation is supported with `EnableWindowsTargeting`. Default packaging is a compressed single-file Windows x64 executable.

## Validation of this test build

- Official .NET SDK archive checked against the release manifest's SHA-512 hash.
- Nine tests executed for the 3-second deadline, one-time detonation, restarting, late updates, accelerating tick schedule, cancellation, held-key suppression, enabling/capture behavior, custom duration, and invalid values.
- A self-contained Windows build was cross-compiled on Linux; it is unsigned.
- Native Windows UI, real keyboard/mouse capture, fullscreen behavior, and speaker output could not be executed on the Linux build machine and need testing on the user's Windows PC.

This directory and its artifacts are separate from the TBJ initiative tracker; no TBJ files were changed.
