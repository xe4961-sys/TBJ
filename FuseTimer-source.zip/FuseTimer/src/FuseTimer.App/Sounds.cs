using FuseTimer.Core;

namespace FuseTimer;

internal interface IAudioOutput : IDisposable
{
    void Play(byte[] wave);
    void Stop();
}

internal sealed class Sounds : IDisposable
{
    private readonly byte[] tick, urgent, preview;
    private readonly IAudioOutput output;
    public bool Muted { get; set; }
    public string? LastError { get; private set; }
    public Sounds(int volume, IAudioOutput? output = null)
    {
        double level = Math.Clamp(volume / 100.0, 0, 1);
        tick = AudioClips.Beep(false, level);
        urgent = AudioClips.Beep(true, level);
        preview = AudioClips.TestTone(level);
        this.output = output ?? new WaveOutput();
    }
    public void PlayTick(bool warning) => Play(warning ? urgent : tick);
    public void PlayTest() => Play(preview);
    private void Play(byte[] wave)
    {
        if (Muted) return;
        try { output.Play(wave); LastError = null; }
        catch (IOException e) { LastError = e.Message; }
        // A failed attempt is reported, but must not disable future attempts.
    }
    public void Stop()
    {
        try { output.Stop(); }
        catch (IOException e) { LastError = e.Message; }
    }
    public void Dispose() => output.Dispose();
}
