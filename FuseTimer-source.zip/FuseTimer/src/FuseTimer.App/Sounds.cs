using System.Media;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class Sounds : IDisposable
{
    private readonly MemoryStream tickData;
    private readonly MemoryStream urgentData;
    private readonly SoundPlayer tick;
    private readonly SoundPlayer urgent;
    private bool available = true;
    public bool Muted { get; set; }
    public Sounds(int volume)
    {
        double level = Math.Clamp(volume / 100.0, 0, 1);
        tickData = new MemoryStream(AudioClips.Beep(false, level), false);
        urgentData = new MemoryStream(AudioClips.Beep(true, level), false);
        tick = new SoundPlayer(tickData); urgent = new SoundPlayer(urgentData);
        try { tick.Load(); urgent.Load(); }
        catch (Exception e) when (e is InvalidOperationException or IOException or System.TimeoutException) { available = false; }
    }
    public void PlayTick(bool warning)
    {
        if (Muted || !available) return;
        try { (warning ? urgent : tick).Play(); }
        catch (Exception e) when (e is InvalidOperationException or IOException or System.TimeoutException) { available = false; }
    }
    public void Stop() { if (available) tick.Stop(); }
    public void Dispose() { Stop(); tick.Dispose(); urgent.Dispose(); tickData.Dispose(); urgentData.Dispose(); }
}
