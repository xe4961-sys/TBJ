using System.Media;

namespace FuseTimer;

/// <summary>Locally generated PCM audio; no downloads, media files, or network.</summary>
internal sealed class Sounds : IDisposable
{
    private readonly MemoryStream tickData;
    private readonly MemoryStream urgentData;
    private readonly MemoryStream blastData;
    private readonly SoundPlayer tick;
    private readonly SoundPlayer urgent;
    private readonly SoundPlayer blast;
    private bool available = true;
    public bool Muted { get; set; }

    public Sounds(int volume)
    {
        double level = Math.Clamp(volume / 100.0, 0, 1);
        tickData = Wave(.055, time => Math.Sin(2 * Math.PI * 1000 * time) * Math.Exp(-time * 45) * .35 * level);
        urgentData = Wave(.045, time => Math.Sin(2 * Math.PI * 1450 * time) * Math.Exp(-time * 55) * .4 * level);
        var noise = new Random(303);
        double filtered = 0;
        blastData = Wave(.8, time =>
        {
            filtered = filtered * .78 + (noise.NextDouble() * 2 - 1) * .22;
            double attack = Math.Min(1, time / .006);
            return attack * Math.Exp(-time * 6) * (filtered * 1.2 + Math.Sin(2 * Math.PI * 65 * time) * .27) * .7 * level;
        });
        tick = new SoundPlayer(tickData);
        urgent = new SoundPlayer(urgentData);
        blast = new SoundPlayer(blastData);
        try { tick.Load(); urgent.Load(); blast.Load(); }
        catch (Exception e) when (e is InvalidOperationException or IOException or System.TimeoutException) { available = false; }
    }
    private static MemoryStream Wave(double seconds, Func<double, double> sample)
    {
        const int rate = 22050;
        int count = (int)(seconds * rate);
        var stream = new MemoryStream();
        using (var writer = new BinaryWriter(stream, System.Text.Encoding.UTF8, true))
        {
            writer.Write("RIFF"u8); writer.Write(36 + count * 2); writer.Write("WAVEfmt "u8);
            writer.Write(16); writer.Write((short)1); writer.Write((short)1); writer.Write(rate);
            writer.Write(rate * 2); writer.Write((short)2); writer.Write((short)16);
            writer.Write("data"u8); writer.Write(count * 2);
            for (int i = 0; i < count; i++) writer.Write((short)(Math.Clamp(sample(i / (double)rate), -1, 1) * short.MaxValue));
        }
        stream.Position = 0;
        return stream;
    }
    public void PlayTick(bool finalSecond) => Play(finalSecond ? urgent : tick);
    public void Detonate() => Play(blast);
    private void Play(SoundPlayer sound)
    {
        if (Muted || !available) return;
        try { sound.Play(); }
        catch (Exception e) when (e is InvalidOperationException or IOException or System.TimeoutException) { available = false; }
    }
    public void Stop() { if (available) tick.Stop(); }
    public void Dispose()
    {
        Stop(); tick.Dispose(); urgent.Dispose(); blast.Dispose();
        tickData.Dispose(); urgentData.Dispose(); blastData.Dispose();
    }
}
