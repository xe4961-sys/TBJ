namespace FuseTimer;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        using var instance = new Mutex(true, @"Local\FuseTimer.Countdown", out bool first);
        if (!first)
        {
            MessageBox.Show("Fuse Timer is already running. Use your controls key (F8 by default), or its clock icon in the system tray.", "Fuse Timer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        ApplicationConfiguration.Initialize();
        Application.Run(new TimerApplication());
    }
}

/// <summary>Runs the message loop without showing a main window on startup.</summary>
internal sealed class TimerApplication : ApplicationContext
{
    private readonly TimerForm controls;
    public TimerApplication()
    {
        controls = new TimerForm(SettingsStore.Load());
        controls.FormClosed += (_, _) => ExitThread();
        _ = controls.Handle; // Hidden handle for polling and explicit exit; no Show() or focus change.
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) controls.Dispose();
        base.Dispose(disposing);
    }
}
