namespace FuseTimer;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        using var instance = new Mutex(true, @"Local\FuseTimer.Countdown", out bool first);
        if (!first)
        {
            MessageBox.Show("Fuse Timer is already running. Restore it from the taskbar or the clock icon in the system tray.", "Fuse Timer", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        ApplicationConfiguration.Initialize();
        Application.Run(new TimerForm(SettingsStore.Load()));
    }
}
