using System.Text.Json;

namespace FuseTimer;

public sealed record TimerSettings
{
    public int KeyCode { get; set; } = 0x47;
    public double Duration { get; set; } = 3;
    public bool Sound { get; set; } = true;
    public bool Enabled { get; set; } = true;
    public bool OnTop { get; set; } = true;
    public int Volume { get; set; } = 60;
}

internal static class SettingsStore
{
    private static readonly string Folder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FuseTimer");
    private static readonly string Filename = Path.Combine(Folder, "settings.json");

    public static TimerSettings Load()
    {
        try
        {
            var settings = JsonSerializer.Deserialize<TimerSettings>(File.ReadAllText(Filename));
            if (settings is not null && WindowsInput.CapturableKeys.Contains(settings.KeyCode) && double.IsFinite(settings.Duration) && settings.Duration >= .5 && settings.Duration <= 15 && settings.Volume >= 0 && settings.Volume <= 100) return settings;
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException or JsonException) { }
        return new();
    }

    public static bool Save(TimerSettings settings)
    {
        try
        {
            Directory.CreateDirectory(Folder);
            File.WriteAllText(Filename + ".tmp", JsonSerializer.Serialize(settings, new JsonSerializerOptions { WriteIndented = true }));
            File.Move(Filename + ".tmp", Filename, true);
            return true;
        }
        catch (Exception exception) when (exception is IOException or UnauthorizedAccessException) { return false; }
    }
}
