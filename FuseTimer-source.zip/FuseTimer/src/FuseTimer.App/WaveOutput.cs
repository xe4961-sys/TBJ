using System.Runtime.InteropServices;
using System.Text;
using FuseTimer.Core;

namespace FuseTimer;

// Queue PCM directly to the default Windows audio device. Unlike SoundPlayer,
// every native operation has an error result that we can show in settings.
internal sealed class WaveOutput : IAudioOutput
{
    private IntPtr device;
    private readonly Dictionary<byte[], Buffer> buffers = new();
    private bool disposed;

    public void Play(byte[] wave)
    {
        ObjectDisposedException.ThrowIf(disposed, this);
        if (device == IntPtr.Zero)
        {
            var format = new WaveFormat
            {
                FormatTag = 1, Channels = 1, SamplesPerSecond = AudioClips.SampleRate,
                AverageBytesPerSecond = AudioClips.SampleRate * 2, BlockAlign = 2, BitsPerSample = 16
            };
            uint result = waveOutOpen(out device, uint.MaxValue, ref format, UIntPtr.Zero, UIntPtr.Zero, 0);
            if (result != 0) { device = IntPtr.Zero; Check(result, "Open audio device"); }
        }
        Stop();
        if (!buffers.TryGetValue(wave, out var buffer))
        {
            buffer = new Buffer(wave);
            uint result = waveOutPrepareHeader(device, buffer.Header, (uint)Marshal.SizeOf<WaveHeader>());
            if (result != 0) { buffer.Free(); Check(result, "Prepare audio"); }
            buffers.Add(wave, buffer);
        }
        Check(waveOutWrite(device, buffer.Header, (uint)Marshal.SizeOf<WaveHeader>()), "Play audio");
    }
    public void Stop()
    {
        if (device != IntPtr.Zero) Check(waveOutReset(device), "Stop audio");
    }
    public void Dispose()
    {
        if (disposed) return;
        disposed = true;
        if (device == IntPtr.Zero) return;
        // Reset returns queued buffers to us before they can be freed. In the
        // exceptional driver-failure case, retain native memory until process
        // exit rather than free a buffer that the driver may still be using.
        if (waveOutReset(device) != 0) return;
        foreach (var buffer in buffers.Values)
            if (waveOutUnprepareHeader(device, buffer.Header, (uint)Marshal.SizeOf<WaveHeader>()) == 0) buffer.Free();
        waveOutClose(device);
        device = IntPtr.Zero;
        buffers.Clear();
    }
    private static void Check(uint result, string operation)
    {
        if (result == 0) return;
        var message = new StringBuilder(256);
        waveOutGetErrorTextW(result, message, (uint)message.Capacity);
        throw new IOException($"{operation}: {(message.Length > 0 ? message.ToString() : $"Windows error {result}")}");
    }
    private sealed class Buffer
    {
        public IntPtr Header { get; }
        private readonly IntPtr data;
        public Buffer(byte[] wave)
        {
            // AudioClips creates canonical 44-byte-header, 16-bit mono PCM WAVs.
            int count = wave.Length - 44;
            data = Marshal.AllocHGlobal(count);
            Header = Marshal.AllocHGlobal(Marshal.SizeOf<WaveHeader>());
            Marshal.Copy(wave, 44, data, count);
            Marshal.StructureToPtr(new WaveHeader { Data = data, BufferLength = (uint)count }, Header, false);
        }
        public void Free() { Marshal.FreeHGlobal(Header); Marshal.FreeHGlobal(data); }
    }
    [StructLayout(LayoutKind.Sequential, Pack = 2)]
    private struct WaveFormat
    {
        public ushort FormatTag, Channels;
        public uint SamplesPerSecond, AverageBytesPerSecond;
        public ushort BlockAlign, BitsPerSample, ExtraSize;
    }
    [StructLayout(LayoutKind.Sequential)]
    private struct WaveHeader
    {
        public IntPtr Data;
        public uint BufferLength, BytesRecorded;
        public UIntPtr User;
        public uint Flags, Loops;
        public IntPtr Next;
        public UIntPtr Reserved;
    }
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutOpen(out IntPtr device, uint deviceId, ref WaveFormat format, UIntPtr callback, UIntPtr instance, uint flags);
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutPrepareHeader(IntPtr device, IntPtr header, uint size);
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutWrite(IntPtr device, IntPtr header, uint size);
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutReset(IntPtr device);
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutUnprepareHeader(IntPtr device, IntPtr header, uint size);
    [DllImport("winmm.dll", ExactSpelling = true)]
    private static extern uint waveOutClose(IntPtr device);
    [DllImport("winmm.dll", ExactSpelling = true, CharSet = CharSet.Unicode)]
    private static extern uint waveOutGetErrorTextW(uint error, StringBuilder message, uint characters);
}
