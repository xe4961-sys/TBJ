using System.ComponentModel;
using System.Drawing.Drawing2D;
using System.Globalization;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class Dial : Control
{
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public CountdownPhase Phase { get; set; }
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public double Remaining { get; set; } = 3;
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public double Duration { get; set; } = 3;
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public double BurstAge { get; set; }
    [DesignerSerializationVisibility(DesignerSerializationVisibility.Hidden)]
    public bool TimerEnabled { get; set; } = true;

    public Dial()
    {
        DoubleBuffered = true;
        BackColor = Color.FromArgb(16, 27, 45);
        Size = new Size(300, 180);
        AccessibleName = "Grenade countdown";
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        base.OnPaint(e);
        var g = e.Graphics;
        g.SmoothingMode = SmoothingMode.AntiAlias;
        var center = new PointF(Width / 2f, Height / 2f - 3);
        float radius = Math.Min(Width, Height) * .41f;
        var bounds = new RectangleF(center.X - radius, center.Y - radius, radius * 2, radius * 2);
        Color accent = !TimerEnabled ? Color.FromArgb(100, 119, 145) : Remaining < 1 && Phase == CountdownPhase.Counting ? Color.FromArgb(255, 177, 111) : Color.FromArgb(138, 200, 255);
        using var track = new Pen(Color.FromArgb(39, 59, 85), 5);
        using var progress = new Pen(accent, 5) { StartCap = LineCap.Round, EndCap = LineCap.Round };
        g.DrawEllipse(track, bounds);
        float sweep = (float)(360 * Math.Clamp(Remaining / Duration, 0, 1));
        if (sweep > 0) g.DrawArc(progress, bounds, -90, sweep);
        using var mainFont = new Font("Segoe UI", 38, FontStyle.Bold, GraphicsUnit.Pixel);
        using var captionFont = new Font("Segoe UI", 10, FontStyle.Regular, GraphicsUnit.Pixel);
        using var text = new SolidBrush(Color.FromArgb(233, 244, 255));
        using var muted = new SolidBrush(Color.FromArgb(153, 177, 207));
        using var alignment = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
        if (Phase == CountdownPhase.Detonated)
        {
            using var blastFont = new Font("Segoe UI Emoji", 64, FontStyle.Regular, GraphicsUnit.Pixel);
            using var blastBrush = new SolidBrush(Color.FromArgb(255, 193, 115));
            float pulse = BurstAge < .7 ? (float)(1 + .12 * Math.Sin(BurstAge * 23)) : 1;
            var saved = g.Save();
            g.TranslateTransform(center.X, center.Y - 4);
            g.ScaleTransform(pulse, pulse);
            g.DrawString("💥", blastFont, blastBrush, new PointF(0, 0), alignment);
            g.Restore(saved);
            if (BurstAge < .85)
            {
                float size = radius * (1 + (float)BurstAge * .18f);
                using var burst = new Pen(Color.FromArgb((int)(160 * (1 - BurstAge / .85)), 255, 165, 80), 3);
                g.DrawEllipse(burst, center.X - size, center.Y - size, size * 2, size * 2);
            }
            g.DrawString("0.00  ·  DETONATED", captionFont, muted, new PointF(center.X, center.Y + 51), alignment);
        }
        else
        {
            g.DrawString(Remaining.ToString("0.00", CultureInfo.InvariantCulture), mainFont, text, new PointF(center.X, center.Y - 8), alignment);
            string caption = !TimerEnabled ? "HOTKEY PAUSED" : Phase == CountdownPhase.Counting ? "SECONDS TO DETONATION" : "SECONDS  ·  READY";
            g.DrawString(caption, captionFont, muted, new PointF(center.X, center.Y + 30), alignment);
        }
    }
}
