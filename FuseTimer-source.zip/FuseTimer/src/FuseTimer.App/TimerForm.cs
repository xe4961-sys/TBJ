using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class TimerForm : Form
{
    private static readonly Color Background = Color.FromArgb(16, 27, 45);
    private static readonly Color Muted = Color.FromArgb(153, 177, 207);
    private readonly TimerSettings settings;
    private readonly Countdown countdown = new();
    private readonly PressEdge keyEdge = new();
    private readonly System.Windows.Forms.Timer poll = new() { Interval = 10 };
    private readonly Dial dial = new();
    private readonly Label status;
    private readonly Label keyLabel;
    private readonly CheckBox enabled;
    private readonly CheckBox sound;
    private readonly CheckBox onTop;
    private readonly NumericUpDown duration;
    private readonly Button capture;
    private readonly Button compactButton;
    private readonly Panel settingsPanel;
    private readonly Label hint;
    private readonly NotifyIcon tray;
    private readonly ToolStripMenuItem trayEnabled;
    private readonly ToolStripMenuItem traySound;
    private Sounds sounds;
    private bool capturing;
    private bool waitingForRelease;
    private bool compact;
    private double captureExpires;
    private double detonatedAt;
    private bool saveWarning;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;

    public TimerForm(TimerSettings initial)
    {
        settings = initial;
        sounds = new Sounds(settings.Volume) { Muted = !settings.Sound };
        Text = "Fuse Timer";
        Font = new Font("Segoe UI", 9);
        BackColor = Background;
        ForeColor = Color.FromArgb(233, 244, 255);
        ClientSize = new Size(340, 675);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        MaximizeBox = false;
        StartPosition = FormStartPosition.CenterScreen;
        TopMost = settings.OnTop;
        Icon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!) ?? SystemIcons.Application;
        var layout = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(19, 12, 19, 10), BackColor = Background };
        Controls.Add(layout);
        layout.Controls.Add(Label("FUSE TIMER", 24, 11, true, Color.FromArgb(138, 200, 255)));
        layout.Controls.Add(dial);
        status = Label("", 30, 9, false, Muted);
        status.TextAlign = ContentAlignment.MiddleCenter;
        layout.Controls.Add(status);
        var actions = Row(34);
        var start = Button("Start / restart", 145); start.Click += (_, _) => StartCountdown();
        var cancel = Button("Cancel", 145); cancel.Click += (_, _) => ResetCountdown();
        actions.Controls.Add(start); actions.Controls.Add(cancel);
        layout.Controls.Add(actions);
        var toggles = Row(29);
        enabled = Check("Hotkey enabled", settings.Enabled, 155);
        sound = Check("Sound on", settings.Sound, 140);
        toggles.Controls.Add(enabled); toggles.Controls.Add(sound);
        layout.Controls.Add(toggles);
        settingsPanel = new Panel { Size = new Size(300, 157), Margin = new Padding(0) };
        keyLabel = Label("", 28, 10, true, ForeColor); keyLabel.Location = new Point(0, 4); keyLabel.Width = 163;
        capture = Button("Change key", 125); capture.Location = new Point(172, 3);
        settingsPanel.Controls.Add(keyLabel); settingsPanel.Controls.Add(capture);
        var secondsLabel = Label("Grenade fuse", 28); secondsLabel.Location = new Point(0, 43); secondsLabel.Width = 170;
        duration = new NumericUpDown { Location = new Point(190, 46), Width = 106, DecimalPlaces = 2, Minimum = .5M, Maximum = 15M, Increment = .05M, Value = (decimal)settings.Duration, BackColor = Color.FromArgb(29, 48, 74), ForeColor = ForeColor };
        settingsPanel.Controls.Add(secondsLabel); settingsPanel.Controls.Add(duration);
        onTop = Check("Always on top", settings.OnTop, 200); onTop.Location = new Point(0, 81);
        settingsPanel.Controls.Add(onTop);
        var volumeLabel = Label("Volume", 27); volumeLabel.Location = new Point(0, 115); volumeLabel.Width = 100;
        var volume = new NumericUpDown { Location = new Point(190, 115), Width = 106, Minimum = 0, Maximum = 100, Increment = 10, Value = settings.Volume, BackColor = Color.FromArgb(29, 48, 74), ForeColor = ForeColor };
        settingsPanel.Controls.Add(volumeLabel); settingsPanel.Controls.Add(volume);
        layout.Controls.Add(settingsPanel);
        compactButton = Button("Hide settings", 300);
        layout.Controls.Add(compactButton);
        hint = Label("Press your grenade key to start or restart.\nThe game still receives the key. Hold = one timer.", 43, 8, false, Muted);
        layout.Controls.Add(hint);

        var menu = new ContextMenuStrip();
        menu.Items.Add("Open timer", null, (_, _) => RestoreWindow());
        trayEnabled = new ToolStripMenuItem("Hotkey enabled") { Checked = settings.Enabled };
        traySound = new ToolStripMenuItem("Sound on") { Checked = settings.Sound };
        menu.Items.Add(trayEnabled); menu.Items.Add(traySound); menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => Close());
        tray = new NotifyIcon { Text = "Fuse Timer", Icon = Icon, ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += (_, _) => RestoreWindow();
        trayEnabled.Click += (_, _) => enabled.Checked = !enabled.Checked;
        traySound.Click += (_, _) => sound.Checked = !sound.Checked;

        enabled.CheckedChanged += (_, _) =>
        {
            settings.Enabled = enabled.Checked; trayEnabled.Checked = enabled.Checked;
            if (!enabled.Checked) { CancelCapture(); ResetCountdown(); }
            dial.TimerEnabled = settings.Enabled; Save(); UpdateStatus();
        };
        sound.CheckedChanged += (_, _) =>
        {
            settings.Sound = sound.Checked; traySound.Checked = sound.Checked;
            sounds.Muted = !sound.Checked;
            if (!sound.Checked) sounds.Stop();
            sound.Text = sound.Checked ? "Sound on" : "Sound muted";
            Save();
        };
        onTop.CheckedChanged += (_, _) => { settings.OnTop = onTop.Checked; TopMost = settings.OnTop; Save(); };
        duration.ValueChanged += (_, _) => { settings.Duration = (double)duration.Value; ResetCountdown(); Save(); };
        volume.ValueChanged += (_, _) =>
        {
            settings.Volume = (int)volume.Value;
            sounds.Dispose(); sounds = new Sounds(settings.Volume) { Muted = !settings.Sound }; Save();
        };
        capture.Click += (_, _) => BeginCapture();
        compactButton.Click += (_, _) =>
        {
            compact = !compact;
            settingsPanel.Visible = !compact; hint.Visible = !compact;
            compactButton.Text = compact ? "Show settings" : "Hide settings";
            ClientSize = new Size((int)(340 * DeviceDpi / 96f), (int)((compact ? 375 : 675) * DeviceDpi / 96f));
        };
        poll.Tick += (_, _) => UpdateTimer();
        FormClosed += (_, _) => { poll.Stop(); poll.Dispose(); tray.Visible = false; tray.Dispose(); sounds.Dispose(); };
        countdown.Reset(settings.Duration);
        dial.TimerEnabled = settings.Enabled;
        sound.Text = settings.Sound ? "Sound on" : "Sound muted";
        keyEdge.Synchronize(WindowsInput.IsDown(settings.KeyCode));
        UpdateStatus(); UpdateTimer(); poll.Start();
    }

    private static FlowLayoutPanel Row(int height) => new() { Size = new Size(300, height), Margin = new Padding(0, 1, 0, 3), FlowDirection = FlowDirection.LeftToRight, WrapContents = false };
    private static Label Label(string text, int height, float size = 9, bool bold = false, Color? color = null) => new()
    { Text = text, Size = new Size(300, height), ForeColor = color ?? Color.FromArgb(233, 244, 255), Font = new Font("Segoe UI", size, bold ? FontStyle.Bold : FontStyle.Regular), Margin = new Padding(0), TextAlign = ContentAlignment.MiddleLeft };
    private static Button Button(string text, int width) => new()
    { Text = text, Size = new Size(width, 30), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(29, 52, 80), ForeColor = Color.FromArgb(197, 226, 255), Margin = new Padding(0, 0, 7, 0), UseVisualStyleBackColor = false };
    private static CheckBox Check(string text, bool value, int width) => new()
    { Text = text, Checked = value, Size = new Size(width, 27), ForeColor = Color.FromArgb(198, 218, 244), Margin = new Padding(0) };

    private void Save() { saveWarning = !SettingsStore.Save(settings); UpdateStatus(); }
    private void StartCountdown()
    {
        if (capturing) return;
        countdown.Start(Now, settings.Duration);
        sounds.Stop();
        UpdateStatus();
    }
    private void ResetCountdown() { countdown.Reset(settings.Duration); sounds.Stop(); UpdateStatus(); dial.Invalidate(); }
    private void BeginCapture()
    {
        ResetCountdown(); capturing = true; waitingForRelease = true; captureExpires = Now + 15;
        capture.Text = "Listening…"; UpdateStatus();
    }
    private void CancelCapture() { capturing = false; capture.Text = "Change key"; keyEdge.Synchronize(WindowsInput.IsDown(settings.KeyCode)); UpdateStatus(); }
    private void RestoreWindow() { Show(); WindowState = FormWindowState.Normal; Activate(); }
    private void UpdateStatus()
    {
        keyLabel.Text = $"Grenade key: {WindowsInput.Name(settings.KeyCode)}";
        tray.Text = $"Fuse Timer · {WindowsInput.Name(settings.KeyCode)} · {(settings.Enabled ? "enabled" : "paused")}";
        status.Text = capturing ? "Release buttons, then press a key. Esc cancels." :
            saveWarning ? "Settings could not save; this session still works." :
            countdown.Phase == CountdownPhase.Counting ? $"{WindowsInput.Name(settings.KeyCode)} restarts · {settings.Duration:0.00}s fuse" :
            countdown.Phase == CountdownPhase.Detonated ? $"Detonated · {WindowsInput.Name(settings.KeyCode)} to restart" :
            settings.Enabled ? $"Ready · press {WindowsInput.Name(settings.KeyCode)}" : "Hotkey paused · manual Start still works";
    }
    protected override bool ProcessCmdKey(ref Message message, Keys keyData)
    {
        // During assignment, keep Space/Enter from activating the focused
        // Change key button a second time. This affects only this form's UI;
        // it never intercepts keyboard messages belonging to the game.
        if (capturing) return true;
        return base.ProcessCmdKey(ref message, keyData);
    }
    private void UpdateTimer()
    {
        double now = Now;
        if (capturing)
        {
            if (WindowsInput.IsDown(27) || now >= captureExpires) CancelCapture();
            else if (waitingForRelease) { if (!WindowsInput.AnyKeyDown()) waitingForRelease = false; }
            else
            {
                int key = WindowsInput.CapturableKeys.FirstOrDefault(WindowsInput.IsDown);
                if (key != 0)
                {
                    settings.KeyCode = key; capturing = false; capture.Text = "Change key";
                    keyEdge.Synchronize(true); ActiveControl = null; Save();
                }
            }
        }
        else
        {
            bool down = WindowsInput.IsDown(settings.KeyCode);
            // Keep polling while minimized, without registering, swallowing,
            // replaying, or changing the game's input.
            if (keyEdge.Sample(down, settings.Enabled && !settingsPanel.Controls.OfType<NumericUpDown>().Any(control => control.ContainsFocus))) StartCountdown();
        }
        CountdownFrame frame = countdown.Advance(now);
        if (frame.Tick) sounds.PlayTick(frame.Remaining <= 1);
        if (frame.Detonate) { detonatedAt = now; sounds.Detonate(); UpdateStatus(); }
        dial.Phase = frame.Phase; dial.Remaining = frame.Remaining; dial.Duration = countdown.Duration;
        dial.BurstAge = Math.Max(0, now - detonatedAt); dial.TimerEnabled = settings.Enabled;
        dial.Invalidate();
    }
}
