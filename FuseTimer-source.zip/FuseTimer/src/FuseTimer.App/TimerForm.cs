using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class TimerForm : Form
{
    private enum CaptureTarget { None, Grenade, Controls }
    private static readonly Color Background = Color.FromArgb(16, 27, 45);
    private static readonly Color Muted = Color.FromArgb(153, 177, 207);
    private readonly TimerSettings settings;
    private readonly Countdown countdown = new();
    private readonly PressEdge grenadeEdge = new();
    private readonly PressEdge controlsEdge = new();
    private readonly System.Windows.Forms.Timer poll = new() { Interval = 10 };
    private readonly TimerOverlay overlay;
    private readonly Label status, grenadeLabel, controlsLabel;
    private readonly CheckBox enabled, sound, onlyPrimed, flashing;
    private readonly NumericUpDown duration, volume;
    private readonly Button captureGrenade, captureControls, positionButton;
    private readonly NotifyIcon tray;
    private readonly ContextMenuStrip menu;
    private readonly ToolStripMenuItem trayEnabled, traySound;
    private Sounds sounds;
    private CaptureTarget captureTarget;
    private bool waitingForRelease, positioning, exitRequested, saveWarning;
    private double captureExpires;
    private CountdownFrame frame;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;

    public TimerForm(TimerSettings initial)
    {
        settings = initial;
        sounds = new Sounds(settings.Volume) { Muted = !settings.Sound };
        countdown.Reset(settings.Duration);
        frame = countdown.Advance(Now);
        Text = "Fuse Timer — settings";
        Font = new Font("Segoe UI", 9);
        BackColor = Background; ForeColor = Color.FromArgb(233, 244, 255);
        ClientSize = new Size(360, 562);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        AutoScaleDimensions = new SizeF(96, 96); AutoScaleMode = AutoScaleMode.Dpi;
        MaximizeBox = false; ShowInTaskbar = false; StartPosition = FormStartPosition.CenterScreen;
        Icon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!) ?? SystemIcons.Application;
        var layout = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown, WrapContents = false, AutoScroll = true, Padding = new Padding(19, 12, 19, 10), BackColor = Background };
        Controls.Add(layout);
        layout.Controls.Add(Label("FUSE TIMER  /  1.2", 30, true, Color.FromArgb(138, 200, 255)));
        status = Label("", 43, false, Muted); layout.Controls.Add(status);
        var actions = Row(36);
        var start = Button("Start / restart", 145); start.Click += (_, _) => StartCountdown();
        var cancel = Button("Cancel", 145); cancel.Click += (_, _) => ResetCountdown();
        actions.Controls.Add(start); actions.Controls.Add(cancel); layout.Controls.Add(actions);
        var toggles = Row(31);
        enabled = Check("Hotkey enabled", settings.Enabled, 155); sound = Check("Sound on", settings.Sound, 140);
        toggles.Controls.Add(enabled); toggles.Controls.Add(sound); layout.Controls.Add(toggles);
        var options = new Panel { Size = new Size(300, 225), Margin = new Padding(0) };
        grenadeLabel = Label("", 30, true); grenadeLabel.Location = new Point(0, 2); grenadeLabel.Width = 165;
        captureGrenade = Button("Change key", 125); captureGrenade.Location = new Point(172, 2);
        controlsLabel = Label("", 30, true); controlsLabel.Location = new Point(0, 41); controlsLabel.Width = 165;
        captureControls = Button("Change key", 125); captureControls.Location = new Point(172, 41);
        options.Controls.AddRange([grenadeLabel, captureGrenade, controlsLabel, captureControls]);
        var durationLabel = Label("Seconds until ARMED", 28); durationLabel.Location = new Point(0, 83); durationLabel.Width = 180;
        duration = Number(83, .5M, 15, (decimal)settings.Duration, 2); duration.Increment = .05M;
        var volumeLabel = Label("Volume", 28); volumeLabel.Location = new Point(0, 121); volumeLabel.Width = 180;
        volume = Number(121, 0, 100, settings.Volume, 0); volume.Increment = 10;
        onlyPrimed = Check("Only show while primed", settings.OnlyWhilePrimed, 300); onlyPrimed.Location = new Point(0, 162);
        flashing = Check("Gentle warning flashes", settings.FlashWarnings, 300); flashing.Location = new Point(0, 192);
        options.Controls.AddRange([durationLabel, duration, volumeLabel, volume, onlyPrimed, flashing]); layout.Controls.Add(options);
        positionButton = Button("Position overlay", 300); layout.Controls.Add(positionButton);
        var bottom = Row(36);
        var hide = Button("Hide controls", 145); hide.Click += (_, _) => HideControls();
        var quit = Button("Exit app", 145); quit.Click += (_, _) => ExitApp();
        bottom.Controls.Add(hide); bottom.Controls.Add(quit); layout.Controls.Add(bottom);
        layout.Controls.Add(Label("Countdown → ARMED 0.20s → RELEASE 0.50s.\nUse the controls key or tray icon to reopen settings.\nOverlay is transparent and click-through while playing.", 62, false, Muted));

        menu = new ContextMenuStrip(); menu.Items.Add("Show controls", null, (_, _) => OpenControls());
        menu.Items.Add("Hide controls", null, (_, _) => HideControls());
        trayEnabled = new ToolStripMenuItem("Hotkey enabled") { Checked = settings.Enabled };
        traySound = new ToolStripMenuItem("Sound on") { Checked = settings.Sound };
        menu.Items.Add(trayEnabled); menu.Items.Add(traySound); menu.Items.Add(new ToolStripSeparator());
        menu.Items.Add("Exit", null, (_, _) => ExitApp());
        tray = new NotifyIcon { Text = "Fuse Timer", Icon = Icon, ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += (_, _) => OpenControls();
        trayEnabled.Click += (_, _) => enabled.Checked = !enabled.Checked;
        traySound.Click += (_, _) => sound.Checked = !sound.Checked;
        overlay = new TimerOverlay(settings.OverlayX, settings.OverlayY);
        overlay.ResizeEnd += (_, _) => Save();

        enabled.CheckedChanged += (_, _) =>
        {
            settings.Enabled = enabled.Checked; trayEnabled.Checked = enabled.Checked;
            if (!enabled.Checked) { CancelCapture(); ResetCountdown(); }
            Save();
        };
        sound.CheckedChanged += (_, _) =>
        {
            settings.Sound = sound.Checked; traySound.Checked = sound.Checked;
            sounds.Muted = !sound.Checked; if (!sound.Checked) sounds.Stop();
            sound.Text = sound.Checked ? "Sound on" : "Sound muted"; Save();
        };
        duration.ValueChanged += (_, _) => { settings.Duration = (double)duration.Value; ResetCountdown(); Save(); };
        volume.ValueChanged += (_, _) =>
        {
            settings.Volume = (int)volume.Value; sounds.Dispose();
            sounds = new Sounds(settings.Volume) { Muted = !settings.Sound }; Save();
        };
        onlyPrimed.CheckedChanged += (_, _) => { settings.OnlyWhilePrimed = onlyPrimed.Checked; Save(); RefreshOverlay(); };
        flashing.CheckedChanged += (_, _) => { settings.FlashWarnings = flashing.Checked; Save(); RefreshOverlay(); };
        captureGrenade.Click += (_, _) => BeginCapture(CaptureTarget.Grenade);
        captureControls.Click += (_, _) => BeginCapture(CaptureTarget.Controls);
        positionButton.Click += (_, _) =>
        {
            positioning = !positioning;
            if (positioning) ResetCountdown();
            positionButton.Text = positioning ? "Done positioning" : "Position overlay";
            overlay.SetInteractive(positioning); RefreshOverlay(); Save();
        };
        Resize += (_, _) => { if (WindowState == FormWindowState.Minimized) HideControls(); };
        FormClosing += (_, e) =>
        {
            if (!exitRequested && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; HideControls(); }
        };
        FormClosed += (_, _) =>
        {
            poll.Stop(); poll.Dispose(); StorePosition(); SettingsStore.Save(settings);
            overlay.Dispose(); tray.Visible = false; tray.Dispose(); menu.Dispose(); sounds.Dispose();
        };
        poll.Tick += (_, _) => UpdateTimer();
        sound.Text = settings.Sound ? "Sound on" : "Sound muted";
        SynchronizeKeys(); UpdateStatus(); poll.Start();
    }
    private NumericUpDown Number(int y, decimal min, decimal max, decimal value, int decimals) => new()
    { Location = new Point(194, y), Width = 102, Minimum = min, Maximum = max, Value = value, DecimalPlaces = decimals, BackColor = Color.FromArgb(29, 48, 74), ForeColor = ForeColor };
    private static FlowLayoutPanel Row(int height) => new() { Size = new Size(300, height), Margin = new Padding(0, 1, 0, 3), FlowDirection = FlowDirection.LeftToRight, WrapContents = false };
    private static Label Label(string text, int height, bool bold = false, Color? color = null) => new()
    { Text = text, Size = new Size(300, height), ForeColor = color ?? Color.FromArgb(233, 244, 255), Font = new Font("Segoe UI", 9, bold ? FontStyle.Bold : FontStyle.Regular), Margin = new Padding(0), TextAlign = ContentAlignment.MiddleLeft };
    private static Button Button(string text, int width) => new()
    { Text = text, Size = new Size(width, 30), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(29, 52, 80), ForeColor = Color.FromArgb(197, 226, 255), Margin = new Padding(0, 0, 7, 4), UseVisualStyleBackColor = false };
    private static CheckBox Check(string text, bool value, int width) => new()
    { Text = text, Checked = value, Size = new Size(width, 27), ForeColor = Color.FromArgb(198, 218, 244), Margin = new Padding(0) };
    private void StorePosition() { settings.OverlayX = overlay.Left; settings.OverlayY = overlay.Top; }
    private void Save() { StorePosition(); saveWarning = !SettingsStore.Save(settings); UpdateStatus(); }
    private void StartCountdown()
    {
        if (captureTarget != CaptureTarget.None) return;
        countdown.Start(Now, settings.Duration); sounds.Stop(); frame = countdown.Advance(Now);
        if (frame.Tick) sounds.PlayTick(false);
        RefreshOverlay(); UpdateStatus();
    }
    private void ResetCountdown()
    {
        countdown.Reset(settings.Duration); sounds.Stop(); frame = countdown.Advance(Now);
        RefreshOverlay(); UpdateStatus();
    }
    private void SynchronizeKeys()
    {
        grenadeEdge.Synchronize(WindowsInput.IsDown(settings.KeyCode));
        controlsEdge.Synchronize(WindowsInput.IsDown(settings.ControlsKey));
    }
    private void BeginCapture(CaptureTarget target)
    {
        ResetCountdown(); captureTarget = target; waitingForRelease = true; captureExpires = Now + 15;
        captureGrenade.Text = target == CaptureTarget.Grenade ? "Listening…" : "Change key";
        captureControls.Text = target == CaptureTarget.Controls ? "Listening…" : "Change key";
        UpdateStatus();
    }
    private void CancelCapture()
    {
        captureTarget = CaptureTarget.None; captureGrenade.Text = captureControls.Text = "Change key";
        SynchronizeKeys(); UpdateStatus();
    }
    private void OpenControls() { ShowInTaskbar = true; WindowState = FormWindowState.Normal; Show(); Activate(); UpdateStatus(); }
    private void HideControls()
    {
        if (captureTarget != CaptureTarget.None) CancelCapture();
        positioning = false; positionButton.Text = "Position overlay"; overlay.SetInteractive(false);
        Hide(); ShowInTaskbar = false; Save(); RefreshOverlay();
    }
    private void ExitApp() { exitRequested = true; _ = Handle; Close(); }
    private void RefreshOverlay() => overlay.Present(frame, settings.FlashWarnings, OverlayPolicy.Visible(frame.Phase, settings.OnlyWhilePrimed, positioning));
    private void UpdateStatus()
    {
        grenadeLabel.Text = $"Grenade: {WindowsInput.Name(settings.KeyCode)}";
        controlsLabel.Text = $"Controls: {WindowsInput.Name(settings.ControlsKey)}";
        tray.Text = $"Fuse Timer · {WindowsInput.Name(settings.KeyCode)} / {WindowsInput.Name(settings.ControlsKey)}";
        status.Text = captureTarget != CaptureTarget.None ? "Release buttons, then press a key. Esc cancels."
            : saveWarning ? "Settings could not save; this session still works."
            : overlay.LastError is not null ? overlay.LastError
            : frame.Phase == CountdownPhase.Armed ? "ARMED — release warning starts next."
            : frame.Phase == CountdownPhase.Release ? "RELEASE NOW!"
            : frame.Phase == CountdownPhase.Counting ? $"{frame.Remaining:0.00}s until ARMED."
            : $"{WindowsInput.Name(settings.KeyCode)} starts · {WindowsInput.Name(settings.ControlsKey)} controls";
    }
    protected override bool ProcessCmdKey(ref Message message, Keys keyData)
    {
        if (captureTarget != CaptureTarget.None) return true;
        return base.ProcessCmdKey(ref message, keyData);
    }
    private void UpdateTimer()
    {
        double now = Now;
        if (captureTarget != CaptureTarget.None)
        {
            if (WindowsInput.IsDown(27) || now >= captureExpires) CancelCapture();
            else if (waitingForRelease) { if (!WindowsInput.AnyKeyDown()) waitingForRelease = false; }
            else
            {
                int key = WindowsInput.CapturableKeys.FirstOrDefault(WindowsInput.IsDown);
                if (key != 0)
                {
                    int other = captureTarget == CaptureTarget.Grenade ? settings.ControlsKey : settings.KeyCode;
                    if (key == other) { waitingForRelease = true; status.Text = "Those keys must differ. Release and choose another."; }
                    else
                    {
                        if (captureTarget == CaptureTarget.Grenade) settings.KeyCode = key; else settings.ControlsKey = key;
                        CancelCapture(); ActiveControl = null; Save();
                    }
                }
            }
        }
        else
        {
            if (controlsEdge.Sample(WindowsInput.IsDown(settings.ControlsKey))) { if (Visible) HideControls(); else OpenControls(); }
            bool editing = duration.ContainsFocus || volume.ContainsFocus;
            if (grenadeEdge.Sample(WindowsInput.IsDown(settings.KeyCode), settings.Enabled && !editing)) StartCountdown();
        }
        var previous = frame.Phase;
        frame = countdown.Advance(now);
        if (frame.Tick) sounds.PlayTick(frame.Phase is CountdownPhase.Armed or CountdownPhase.Release || frame.Remaining <= 1);
        if (frame.Phase == CountdownPhase.Complete && previous != CountdownPhase.Complete) sounds.Stop();
        RefreshOverlay();
        if (previous != frame.Phase || Visible) UpdateStatus();
    }
}
