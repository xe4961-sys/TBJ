namespace FuseTimer.Core;

/// <summary>16-bit mono PCM clips, generated without Windows audio dependencies.</summary>
public static class AudioClips
{
    public const int SampleRate = 22050;

    public static byte[] Beep(bool urgent, double volume)
    {
        double seconds = urgent ? .050 : .095;
        double frequency = urgent ? 2200 : 1600;
        return Tone(seconds, frequency, volume);
    }

    public static byte[] TestTone(double volume) => Tone(.45, 1600, volume);

    private static byte[] Tone(double seconds, double frequency, double volume)
    {
        double level = Math.Clamp(volume, 0, 1) * .4;
        double lastTime = ((int)(seconds * SampleRate) - 1) / (double)SampleRate;
        return Wave(seconds, time =>
        {
            // A short attack, steady pitched tone, and smooth release. Unlike
            // an exponentially-decaying tick, this reads as a clear beep.
            double attack = Smooth(time / .003);
            double release = Smooth((lastTime - time) / .008);
            double tone = .88 * Math.Sin(2 * Math.PI * frequency * time)
                        + .12 * Math.Sin(4 * Math.PI * frequency * time);
            return tone * level * Math.Min(attack, release);
        });
    }

    private static double Smooth(double amount) => .5 - .5 * Math.Cos(Math.PI * Math.Clamp(amount, 0, 1));
    private static byte[] Wave(double seconds, Func<double, double> sample)
    {
        int count = (int)(seconds * SampleRate);
        using var stream = new MemoryStream();
        using (var writer = new BinaryWriter(stream, System.Text.Encoding.UTF8, true))
        {
            writer.Write("RIFF"u8); writer.Write(36 + count * 2); writer.Write("WAVEfmt "u8);
            writer.Write(16); writer.Write((short)1); writer.Write((short)1); writer.Write(SampleRate);
            writer.Write(SampleRate * 2); writer.Write((short)2); writer.Write((short)16);
            writer.Write("data"u8); writer.Write(count * 2);
            for (int i = 0; i < count; i++) writer.Write((short)(Math.Clamp(sample(i / (double)SampleRate), -1, 1) * short.MaxValue));
        }
        return stream.ToArray();
    }
}
