namespace FuseTimer.Core;

public enum CountdownPhase { Ready, Counting, Armed, Release, Complete }
public readonly record struct CountdownFrame(CountdownPhase Phase, double Remaining, bool Tick, double WarningAge = 0);

/// <summary>Deadline-based manual countdown and release warning.</summary>
public sealed class Countdown
{
    public const double ArmedSeconds = .2;
    public const double ReleaseSeconds = .5;
    public const double WarningTickSeconds = .09;
    private static readonly double[] TickFractions = [0, .25, .45, .62, .74, .83, .9, .95, .98];
    private double startedAt;
    private int nextTick;
    private int lastWarningTick = -1;
    public double Duration { get; private set; } = 3;
    public CountdownPhase Phase { get; private set; } = CountdownPhase.Ready;

    public void Start(double now, double duration = 3)
    {
        if (!double.IsFinite(now)) throw new ArgumentOutOfRangeException(nameof(now));
        CheckDuration(duration);
        startedAt = now;
        Duration = duration;
        Phase = CountdownPhase.Counting;
        nextTick = 0;
        lastWarningTick = -1;
    }
    public CountdownFrame Advance(double now)
    {
        if (!double.IsFinite(now)) throw new ArgumentOutOfRangeException(nameof(now));
        if (Phase is CountdownPhase.Ready or CountdownPhase.Complete)
            return new(Phase, Phase == CountdownPhase.Ready ? Duration : 0, false);
        var elapsed = Math.Max(0, now - startedAt);
        if (elapsed >= Duration + ArmedSeconds + ReleaseSeconds)
        {
            Phase = CountdownPhase.Complete;
            return new(Phase, 0, false, ArmedSeconds + ReleaseSeconds);
        }
        if (elapsed >= Duration)
        {
            double warningAge = elapsed - Duration;
            Phase = elapsed < Duration + ArmedSeconds ? CountdownPhase.Armed : CountdownPhase.Release;
            int tick = (int)Math.Floor(warningAge / WarningTickSeconds);
            bool play = tick > lastWarningTick;
            lastWarningTick = tick;
            return new(Phase, 0, play, warningAge);
        }
        Phase = CountdownPhase.Counting;
        // Skip missed cues; never emit a burst of catch-up sounds.
        bool cue = false;
        while (nextTick < TickFractions.Length && elapsed >= TickFractions[nextTick] * Duration)
        {
            cue = true;
            nextTick++;
        }
        return new(Phase, Math.Max(0, Duration - elapsed), cue);
    }
    public void Reset(double duration = 3)
    {
        CheckDuration(duration);
        Duration = duration;
        Phase = CountdownPhase.Ready;
        nextTick = 0;
        lastWarningTick = -1;
    }
    private static void CheckDuration(double duration)
    {
        if (!double.IsFinite(duration) || duration < .1 || duration > 60) throw new ArgumentOutOfRangeException(nameof(duration));
    }
}

public static class OverlayPolicy
{
    public static bool Active(CountdownPhase phase) => phase is CountdownPhase.Counting or CountdownPhase.Armed or CountdownPhase.Release;
    public static bool Visible(CountdownPhase phase, bool onlyWhilePrimed, bool positioning = false) => positioning || !onlyWhilePrimed || Active(phase);
    // Gentle text-only pulse, never a full-screen or fully invisible flash.
    public static double WarningOpacity(bool enabled, double warningAge) => enabled
        ? .78 + .22 * Math.Cos(2 * Math.PI * 2 * Math.Max(0, warningAge)) : 1;
}

/// <summary>A held key fires once; release and press again to restart.</summary>
public sealed class PressEdge
{
    private bool wasDown;
    public bool Sample(bool down, bool enabled = true)
    {
        bool pressed = enabled && down && !wasDown;
        wasDown = down;
        return pressed;
    }
    public void Synchronize(bool down) => wasDown = down;
}
