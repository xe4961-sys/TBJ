namespace FuseTimer.Core;

public enum CountdownPhase { Ready, Counting, Detonated }
public readonly record struct CountdownFrame(CountdownPhase Phase, double Remaining, bool Tick, bool Detonate);

/// <summary>Deadline-based countdown. Supply a monotonic timestamp in seconds.</summary>
public sealed class Countdown
{
    private static readonly double[] TickFractions = [0, .25, .45, .62, .74, .83, .9, .95, .98];
    private double startedAt;
    private int nextTick;
    public double Duration { get; private set; } = 3;
    public CountdownPhase Phase { get; private set; } = CountdownPhase.Ready;

    public void Start(double now, double duration = 3)
    {
        if (!double.IsFinite(now)) throw new ArgumentOutOfRangeException(nameof(now));
        if (!double.IsFinite(duration) || duration < .1 || duration > 60) throw new ArgumentOutOfRangeException(nameof(duration));
        startedAt = now;
        Duration = duration;
        Phase = CountdownPhase.Counting;
        nextTick = 0;
    }

    public CountdownFrame Advance(double now)
    {
        if (!double.IsFinite(now)) throw new ArgumentOutOfRangeException(nameof(now));
        if (Phase != CountdownPhase.Counting) return new(Phase, Phase == CountdownPhase.Ready ? Duration : 0, false, false);
        var elapsed = Math.Max(0, now - startedAt);
        var remaining = Math.Max(0, Duration - elapsed);
        if (remaining <= 0)
        {
            Phase = CountdownPhase.Detonated;
            return new(Phase, 0, false, true);
        }
        // If the UI wakes up late, emit one cue, never a burst of missed ticks.
        bool tick = false;
        while (nextTick < TickFractions.Length && elapsed >= TickFractions[nextTick] * Duration)
        {
            tick = true;
            nextTick++;
        }
        return new(Phase, remaining, tick, false);
    }

    public void Reset(double duration = 3)
    {
        if (!double.IsFinite(duration) || duration < .1 || duration > 60) throw new ArgumentOutOfRangeException(nameof(duration));
        Duration = duration;
        Phase = CountdownPhase.Ready;
        nextTick = 0;
    }
}

/// <summary>A held key fires once; release and press again to restart.</summary>
public sealed class PressEdge
{
    private bool wasDown;
    public bool Sample(bool down, bool enabled = true)
    {
        bool pressed = enabled && down && !wasDown;
        wasDown = down;
        return pressed;
    }
    public void Synchronize(bool down) => wasDown = down;
}
