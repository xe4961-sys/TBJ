using FuseTimer.Core;
using System.Text.Json;

internal static class MacroTests
{
    private static void True(bool value) { if (!value) throw new Exception("Expected true"); }
    private static void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
    private static CharacterMacro Example() => new("Game", 1920, 1200,
        [new(MacroAction.LeftDown, 100, 100, 0), new(MacroAction.LeftUp, 100, 100, 100),
         new(MacroAction.LeftDown, 500, 400, 1000), new(MacroAction.LeftUp, 500, 400, 100)]);
    public static int Run()
    {
        int passed = 0;
        void Test(string name, Action run) { run(); Console.WriteLine("PASS " + name); passed++; }
        Test("macro recordings require complete clicks within the recorded client area", () => {
            True(Example().Valid);
            True(!(Example() with { Steps = [new(MacroAction.LeftDown, 1, 1, 0)] }).Valid);
            True(!(Example() with { Steps = [new(MacroAction.LeftDown, 1920, 1, 0), new(MacroAction.LeftUp, 1920, 1, 1)] }).Valid);
            True(!(Example() with { Steps = [new((MacroAction)999, 1, 1, 0), new(MacroAction.LeftUp, 1, 1, 1)] }).Valid);
        });
        Test("recorded clicks preserve coordinates and inter-action waits through JSON", () => {
            var recorder = new CharacterMacroRecorder("Game", 1920, 1200, 0);
            recorder.Add(MacroAction.LeftDown, 30, 40, 1); recorder.Add(MacroAction.LeftUp, 30, 40, 1.12);
            var recording = JsonSerializer.Deserialize<CharacterMacro>(JsonSerializer.Serialize(recorder.Finish()))!;
            True(recording.Valid); Equal(0, recording.Steps[0].DelayMs); Equal(120, recording.Steps[1].DelayMs); Equal(30, recording.Steps[1].X);
        });
        Test("replay applies speed to recorded waits and preserves minimum menu and hold waits", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            True(player.Start(Example(), 400, 300, 0)); player.Tick(0); Equal(1, mouse.Sent.Count);
            player.Tick(.024); Equal(1, mouse.Sent.Count); player.Tick(.025); Equal(2, mouse.Sent.Count);
            player.Tick(.324); Equal(2, mouse.Sent.Count); player.Tick(.326); Equal(3, mouse.Sent.Count);
        });
        Test("late macro ticks never send a burst of actions through a menu", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 400, 30, 0); player.Tick(10); Equal(1, mouse.Sent.Count);
            player.Tick(10); Equal(1, mouse.Sent.Count); player.Tick(11); Equal(2, mouse.Sent.Count);
        });
        Test("wrong target or changed window size aborts before the first replay action", () => {
            var mouse = new FakeMouse { Matches = false }; var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 200, 150, 0); player.Tick(0);
            True(!player.Active); Equal(0, mouse.Sent.Count); Equal(0, mouse.Releases.Count);
        });
        Test("focus loss during a held click releases it and prevents later actions", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 200, 150, 0); player.Tick(0); mouse.Matches = false; player.Tick(.01);
            True(!player.Active); Equal((true, false), mouse.Releases.Single());
            player.Tick(100); Equal(1, mouse.Sent.Count);
        });
        Test("emergency cancellation releases only injected buttons and never moves the pointer", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 200, 150, 0); player.Tick(0); player.Stop("Escape"); player.Stop();
            Equal((true, false), mouse.Releases.Single()); Equal(1, mouse.Sent.Count); True(!player.Active);
        });
        Test("an input failure after a button-down still attempts cleanup", () => {
            var mouse = new FakeMouse { FailSend = true }; var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 200, 150, 0); player.Tick(0);
            True(!player.Active); Equal((true, false), mouse.Releases.Single()); True(player.Status.Contains("failed"));
        });
        Test("repeated switch shortcuts cannot overlap or queue another replay", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            True(player.Start(Example(), 200, 150, 0)); True(!player.Start(Example(), 200, 150, 0));
            player.Tick(0); Equal(1, mouse.Sent.Count);
        });
        Test("completed replay sends balanced actions without an extra release or claiming equip success", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            player.Start(Example(), 200, 150, 0); foreach (double now in new[] { 0.0, 1, 2, 3 }) player.Tick(now);
            True(!player.Active); Equal(4, mouse.Sent.Count); Equal(0, mouse.Releases.Count); True(player.Status.Contains("Check the game"));
        });
        Test("replay snapshots its actions instead of following edits to the saved sequence", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse); var recording = Example();
            player.Start(recording, 200, 150, 0); recording.Steps.Clear(); player.Tick(0); Equal(1, mouse.Sent.Count);
        });
        Test("invalid timing, unfinished clicks, and out-of-window recording do not start replay", () => {
            var mouse = new FakeMouse(); var player = new CharacterMacroPlayer(mouse);
            True(!player.Start(Example(), 0, 150, 0)); True(!player.Start(Example(), 200, 0, 0));
            var recorder = new CharacterMacroRecorder("Game", 1920, 1200, 0);
            bool rejected = false; try { recorder.Add(MacroAction.LeftDown, -1, 1, 0); } catch (InvalidOperationException) { rejected = true; }
            True(rejected); Equal(0, recorder.Count);
        });
        return passed;
    }
    private sealed class FakeMouse : IMacroMouse
    {
        public bool Matches = true, FailSend;
        public List<MacroStep> Sent { get; } = new();
        public List<(bool Left, bool Right)> Releases { get; } = new();
        public bool TargetMatches(CharacterMacro macro) => Matches;
        public void Send(MacroStep step) { if (FailSend) throw new IOException("Input failed"); Sent.Add(step); }
        public void Release(bool left, bool right) => Releases.Add((left, right));
    }
}
