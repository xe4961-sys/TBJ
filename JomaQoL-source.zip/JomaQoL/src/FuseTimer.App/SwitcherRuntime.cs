using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

public sealed record CharacterSlot
{
    public string Name { get; set; } = "Unassigned";
    public CharacterMacro? Recording { get; set; }
}
public sealed record SwitcherPreferences
{
    public bool Enabled { get; set; }
    public int RecordKey { get; set; } = 0x78;
    public int SpeedPercent { get; set; } = 200;
    public int MinimumWaitMs { get; set; } = 150;
    public List<CharacterSlot> Slots { get; set; } = Defaults();
    private static List<CharacterSlot> Defaults() => new[] { "Brawler", "Knight", "Guest", "Firefighter", "Unassigned" }.Select(name => new CharacterSlot { Name = name }).ToList();
    public void Normalize(int controlsKey)
    {
        SpeedPercent = Math.Clamp(SpeedPercent, 25, 400); MinimumWaitMs = Math.Clamp(MinimumWaitMs, 30, 3000);
        var defaults = Defaults();
        Slots = Enumerable.Range(0, 5).Select(i => Slots?.ElementAtOrDefault(i) ?? defaults[i]).ToList();
        foreach (var slot in Slots) { slot.Name = string.IsNullOrWhiteSpace(slot.Name) ? "Unassigned" : slot.Name[..Math.Min(slot.Name.Length, 30)]; if (slot.Recording?.Valid != true) slot.Recording = null; }
        if (!ValidRecordKey(RecordKey, controlsKey)) RecordKey = new[] { 0x78, 0x7a, 0x7b }.First(key => key != controlsKey);
    }
    public static bool ValidRecordKey(int key, int controlsKey) => key >= 8 && WindowsInput.CapturableKeys.Contains(key) && key != controlsKey && key is not (>= 0x61 and <= 0x65);
}

internal sealed class SwitcherRuntime : IDisposable
{
    private const int SlotBase = 0x5100, RecordId = 0x5105, StopId = 0x5106;
    private readonly TimerSettings settings;
    private readonly Form host;
    private readonly MacroWindows mouse = new();
    private readonly CharacterMacroPlayer player;
    private readonly HashSet<int> registered = new();
    private readonly HashSet<int> heldSlots = new();
    private string hotkeySignature = "", foregroundProcess = "";
    private nint foregroundWindow;
    private MacroMouseHook? hook;
    private CharacterMacroRecorder? recorder;
    private CharacterMacro? target;
    private int armedSlot = -1;
    private double started;
    private bool allowPlayback;
    public bool Busy => armedSlot >= 0 || player.Active;
    public bool Recording => recorder is not null;
    public string Status { get; private set; } = "Record each favorite first. Num Lock must be on.";
    public event Action? RequestHide;
    public event Action? Saved;
    public event Action<string>? Notify;
    public event Action? RunStarted;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
    public SwitcherRuntime(TimerSettings settings, Form host) { this.settings = settings; this.host = host; player = new(mouse); }
    public void Arm(int slot)
    {
        if (Busy) Stop();
        armedSlot = slot; started = Now;
        RunStarted?.Invoke();
        Status = $"Return to game. {WindowsInput.Name(settings.Switcher.RecordKey)} begins recording {settings.Switcher.Slots[slot].Name}; press again to save. Esc cancels.";
        RequestHide?.Invoke(); Notify?.Invoke(Status);
    }
    public void Tick(bool controlsVisible, bool paused)
    {
        for (int key = 0x61; key <= 0x65; key++)
        {
            if (!WindowsInput.IsDown(key)) heldSlots.Remove(key);
            else if (Busy || controlsVisible || paused) heldSlots.Add(key);
        }
        if (Busy && WindowsInput.IsDown(27)) Stop("Stopped with Escape. Previous recording kept if unfinished.");
        if ((controlsVisible || paused) && Busy) Stop("Stopped: controls opened or tracking calibration started.");
        if (armedSlot >= 0 && Now - started > 300) Stop("Recording timed out. The previous recording was kept.");
        if (recorder is not null && target is not null && !mouse.TargetMatches(target)) Stop("Recording cancelled: target app or window size changed. Previous recording kept.");
        bool wasPlaying = player.Active;
        player.Tick(Now);
        if (wasPlaying) Status = player.Status;
        allowPlayback = !controlsVisible && !paused && settings.Switcher.Enabled && !Busy;
        nint foreground = MacroWindows.Foreground;
        if (foreground != foregroundWindow) { foregroundWindow = foreground; foregroundProcess = MacroWindows.ProcessName(foreground); }
        var keys = new Dictionary<int, int>();
        if (!controlsVisible && !paused)
        {
            if (armedSlot >= 0) keys[RecordId] = settings.Switcher.RecordKey;
            if (Busy) keys[StopId] = 27;
            if (allowPlayback)
                for (int i = 0; i < 5; i++)
                    if (settings.Switcher.Slots[i].Recording is { Valid: true } recording && string.Equals(recording.ProcessName, foregroundProcess, StringComparison.OrdinalIgnoreCase)) keys[SlotBase + i] = 0x61 + i;
        }
        if (keys.Values.Contains(settings.ControlsKey))
        { Status = "Switcher hotkey conflicts with Controls. Change the Controls key first."; keys.Clear(); }
        int[] trackerKeys = settings.Mode == TrackerMode.Wrecker ? [settings.KeyCode]
            : [settings.Guest.KickKey, settings.Guest.RollKey, settings.Guest.RushKey, settings.Guest.ResetKey, settings.Guest.LearnKey,
                settings.Guest.PickupEnabled ? settings.Guest.PickupKey : 0];
        if (keys.Any(pair => pair.Key >= SlotBase && pair.Key < SlotBase + 5 && trackerKeys.Contains(pair.Value)))
        { Status = "Numpad shortcut conflicts with an active tracker bind. Change that tracker bind first."; keys.Clear(); }
        string signature = string.Join(",", keys.Select(pair => $"{pair.Key}:{pair.Value}"));
        if (signature == hotkeySignature) return;
        Unregister(); hotkeySignature = signature;
        foreach (var pair in keys)
        {
            if (!MacroWindows.RegisterHotKey(host.Handle, pair.Key, 0x4000, (uint)pair.Value))
            { Unregister(); Stop($"Could not register {WindowsInput.Name(pair.Value)}. Another app may use that shortcut."); break; }
            registered.Add(pair.Key);
        }
    }
    public void Hotkey(int id)
    {
        if (!registered.Contains(id)) return;
        if (id == StopId) { Stop("Stopped with Escape. Previous recording kept if recording was unfinished."); return; }
        if (id == RecordId && armedSlot >= 0) { if (recorder is null) BeginRecording(); else FinishRecording(); return; }
        if (!allowPlayback || id < SlotBase || id >= SlotBase + 5 || Busy) return;
        int slotKey = 0x61 + id - SlotBase;
        if (!heldSlots.Add(slotKey)) return;
        var slot = settings.Switcher.Slots[id - SlotBase];
        if (slot.Recording?.Valid != true) return;
        if (WindowsInput.IsDown(1) || WindowsInput.IsDown(2)) { Status = "Release mouse buttons before replay."; return; }
        mouse.SelectForeground();
        if (!mouse.TargetMatches(slot.Recording)) { Status = "Window size/app differs from the recording. Rerecord at this size."; return; }
        if (player.Start(slot.Recording, settings.Switcher.SpeedPercent, settings.Switcher.MinimumWaitMs, Now))
        { Status = $"Switching to {slot.Name}… Escape stops."; allowPlayback = false; RunStarted?.Invoke(); }
    }
    private void BeginRecording()
    {
        try
        {
            if (WindowsInput.IsDown(1) || WindowsInput.IsDown(2)) { Status = "Release mouse buttons, then press the recording key again."; return; }
            target = mouse.CaptureTarget();
            recorder = new(target.ProcessName, target.ClientWidth, target.ClientHeight, Now);
            hook = new MacroMouseHook(Receive);
            Status = $"Recording {settings.Switcher.Slots[armedSlot].Name}: Shop → character → Equip. {WindowsInput.Name(settings.Switcher.RecordKey)} saves; Esc cancels.";
            Notify?.Invoke(Status);
        }
        catch (Exception e) when (e is InvalidOperationException or System.ComponentModel.Win32Exception)
        { Stop("Could not record: " + e.Message); }
    }
    private void Receive(MacroAction action, MacroWindows.NativePoint point, int delta)
    {
        if (recorder is null || target is null) return;
        try
        {
            if (!mouse.TargetMatches(target) || !mouse.ToClient(point, out var client)) throw new InvalidOperationException("Click left the recorded app.");
            recorder.Add(action, client.X, client.Y, Now, delta);
        }
        catch (Exception e) when (e is InvalidOperationException or System.ComponentModel.Win32Exception)
        { Stop("Recording cancelled: " + e.Message + " Previous recording kept."); }
    }
    private void FinishRecording()
    {
        try
        {
            var recording = recorder!.Finish();
            settings.Switcher.Slots[armedSlot].Recording = recording;
            hook?.Dispose(); hook = null; recorder = null; target = null; armedSlot = -1;
            Status = "Recording saved. Enable the switcher, return to the same menu state, then use Numpad 1–5 (Num Lock on).";
            Saved?.Invoke(); Notify?.Invoke(Status);
        }
        catch (InvalidOperationException e) { Status = e.Message + " Release buttons and press the recording key again, or Esc to cancel."; }
    }
    public void Stop(string reason = "Stopped.")
    {
        hook?.Dispose(); hook = null; recorder = null; target = null; armedSlot = -1;
        player.Stop(reason); Status = player.Status; allowPlayback = false;
    }
    private void Unregister() { foreach (int id in registered) MacroWindows.UnregisterHotKey(host.Handle, id); registered.Clear(); }
    public void Dispose() { Stop(); Unregister(); }
}
