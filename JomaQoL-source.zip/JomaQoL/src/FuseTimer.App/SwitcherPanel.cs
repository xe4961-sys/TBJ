using FuseTimer.Core;

namespace FuseTimer;

internal sealed class SwitcherPanel : UserControl
{
    private readonly TimerSettings settings;
    private readonly SwitcherRuntime runtime;
    private readonly Action save;
    private readonly ComboBox slots = new() { Width = 380, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox name = new() { Width = 250, MaxLength = 30 };
    private readonly Label details, status;
    private readonly ListBox steps = new() { Width = 380, Height = 135, BackColor = Ui.Background, ForeColor = Ui.Text };
    private readonly NumericUpDown wait = Ui.Number(0, 0, 30000, 0);
    private CharacterMacro? displayed;
    public SwitcherPanel(TimerSettings settings, SwitcherRuntime runtime, Action save)
    {
        this.settings = settings; this.runtime = runtime; this.save = save;
        Dock = DockStyle.Fill; AutoScroll = true; BackColor = Ui.Background;
        var content = Ui.Stack(405); content.Padding = new Padding(5); Controls.Add(content);
        content.Controls.Add(Ui.Label("CHARACTER SWITCHER", 390, 32));
        content.Controls.Add(Ui.Check("Enable Numpad 1–5 character shortcuts", settings.Switcher.Enabled, value => { settings.Switcher.Enabled = value; runtime.Stop(); save(); }));
        content.Controls.Add(Ui.Label("Num Lock ON. Settings must be hidden for replay.\nWorks alongside your selected Wrecker/Guest tracker.", 390, 45));
        content.Controls.Add(slots);
        content.Controls.Add(name);
        content.Controls.Add(Ui.Button("Save favorite name", () =>
        { Selected.Name = string.IsNullOrWhiteSpace(name.Text) ? "Unassigned" : name.Text.Trim(); ReloadSlots(slots.SelectedIndex); save(); }, 380));
        var actions = Ui.Row();
        actions.Controls.Add(Ui.Button("Record selected", () => runtime.Arm(slots.SelectedIndex)));
        actions.Controls.Add(Ui.Button("Clear selected", () => { Selected.Recording = null; RefreshSelected(); save(); }));
        content.Controls.Add(actions);
        content.Controls.Add(Ui.Label("Record: return to game and press the recording key below.\nClick Shop → character → Equip. Press that key again to save.\nEscape cancels; your previous recording is kept.", 390, 65));
        var recordBind = new BindButton(settings.Switcher.RecordKey,
            key => SwitcherPreferences.ValidRecordKey(key, settings.ControlsKey),
            key => { runtime.Stop(); settings.Switcher.RecordKey = key; save(); });
        content.Controls.Add(Ui.Field("Begin / finish recording", recordBind));
        details = Ui.Label("", 390, 58); content.Controls.Add(details);
        var speed = Ui.Number(settings.Switcher.SpeedPercent, 25, 400, 0);
        speed.ValueChanged += (_, _) => { settings.Switcher.SpeedPercent = (int)speed.Value; save(); };
        content.Controls.Add(Ui.Field("Replay speed % (200 = 2×)", speed));
        var minimum = Ui.Number(settings.Switcher.MinimumWaitMs, 30, 3000, 0);
        minimum.ValueChanged += (_, _) => { settings.Switcher.MinimumWaitMs = (int)minimum.Value; save(); };
        content.Controls.Add(Ui.Field("Minimum menu wait (ms)", minimum));
        content.Controls.Add(Ui.Label("Start with menus closed, just as you recorded.\nRaise the wait if a menu loads too slowly. Keyboard typing\nand mouse-drag paths are not recorded; clicks/wheel only.", 390, 65));
        content.Controls.Add(Ui.Label("Recorded actions (optional wait adjustment)", 390, 30));
        content.Controls.Add(steps);
        content.Controls.Add(Ui.Field("Recorded wait before step (ms)", wait));
        content.Controls.Add(Ui.Button("Set selected step wait", () =>
        {
            if (Selected.Recording is not { } recording || steps.SelectedIndex < 0) return;
            int index = steps.SelectedIndex;
            recording.Steps[index] = recording.Steps[index] with { DelayMs = (int)wait.Value };
            displayed = null; RefreshSelected(); steps.SelectedIndex = index; save();
        }, 380));
        content.Controls.Add(Ui.Button("Stop macro / cancel recording", () => runtime.Stop(), 380));
        content.Controls.Add(Ui.Label("Escape stops replay. Opening controls also stops it.\nReplay requires the recorded app and window size.\nMoving that window is supported; resizing needs rerecording.\nThe sequence sends clicks; it cannot confirm equip success.", 390, 85));
        status = Ui.Label("", 390, 100); content.Controls.Add(status);
        slots.SelectedIndexChanged += (_, _) => RefreshSelected();
        steps.SelectedIndexChanged += (_, _) => { if (Selected.Recording is { } recording && steps.SelectedIndex >= 0) wait.Value = recording.Steps[steps.SelectedIndex].DelayMs; };
        ReloadSlots(0);
    }
    private CharacterSlot Selected => settings.Switcher.Slots[Math.Max(0, slots.SelectedIndex)];
    private void ReloadSlots(int selected)
    {
        slots.Items.Clear();
        for (int i = 0; i < 5; i++) slots.Items.Add($"Numpad {i + 1} — {settings.Switcher.Slots[i].Name}");
        slots.SelectedIndex = Math.Clamp(selected, 0, 4);
    }
    private void RefreshSelected()
    {
        name.Text = Selected.Name;
        var recording = Selected.Recording;
        displayed = recording; steps.Items.Clear();
        details.Text = recording is null ? "Not recorded yet. The fifth slot is yours to name."
            : $"{recording.ProcessName} · {recording.ClientWidth}×{recording.ClientHeight}\n{recording.Steps.Count} actions. First action is immediate.";
        if (recording is not null)
            for (int i = 0; i < recording.Steps.Count; i++)
            { var step = recording.Steps[i]; steps.Items.Add($"{i + 1}. +{step.DelayMs}ms {step.Action} ({step.X}, {step.Y})"); }
    }
    public void UpdateStatus()
    {
        status.Text = runtime.Status;
        if (!ReferenceEquals(displayed, Selected.Recording)) RefreshSelected();
    }
}
