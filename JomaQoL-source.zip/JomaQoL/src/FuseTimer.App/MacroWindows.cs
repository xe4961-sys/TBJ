using System.ComponentModel;
using System.Diagnostics;
using System.Runtime.InteropServices;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class MacroWindows : IMacroMouse
{
    [StructLayout(LayoutKind.Sequential)] internal struct NativePoint { public int X, Y; }
    [StructLayout(LayoutKind.Sequential)] private struct Rect { public int Left, Top, Right, Bottom; }
    [StructLayout(LayoutKind.Sequential)] private struct MouseInput { public int X, Y; public uint Data, Flags, Time; public nuint Extra; }
    [StructLayout(LayoutKind.Explicit)] private struct InputData { [FieldOffset(0)] public MouseInput Mouse; }
    [StructLayout(LayoutKind.Sequential)] private struct Input { public uint Type; public InputData Data; }
    [DllImport("user32.dll")] private static extern nint GetForegroundWindow();
    [DllImport("user32.dll")] private static extern nint GetAncestor(nint window, uint flags);
    [DllImport("user32.dll")] private static extern uint GetWindowThreadProcessId(nint window, out uint processId);
    [DllImport("user32.dll")] private static extern bool GetClientRect(nint window, out Rect rectangle);
    [DllImport("user32.dll")] private static extern bool ClientToScreen(nint window, ref NativePoint point);
    [DllImport("user32.dll")] private static extern bool ScreenToClient(nint window, ref NativePoint point);
    [DllImport("user32.dll")] private static extern nint WindowFromPoint(NativePoint point);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool SetCursorPos(int x, int y);
    [DllImport("user32.dll")] private static extern bool GetCursorPos(out NativePoint point);
    [DllImport("user32.dll", SetLastError = true)] private static extern uint SendInput(uint count, Input[] inputs, int size);
    [DllImport("user32.dll", SetLastError = true)] internal static extern bool RegisterHotKey(nint window, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] internal static extern bool UnregisterHotKey(nint window, int id);
    public nint Target { get; private set; }
    public static nint Foreground => GetAncestor(GetForegroundWindow(), 2);
    public static string ProcessName(nint window)
    {
        if (window == 0) return "";
        GetWindowThreadProcessId(window, out uint pid);
        if (pid == Environment.ProcessId) return "";
        try { using var process = Process.GetProcessById((int)pid); return process.ProcessName; }
        catch (Exception e) when (e is ArgumentException or InvalidOperationException or Win32Exception) { return ""; }
    }
    public CharacterMacro CaptureTarget()
    {
        Target = Foreground;
        string process = ProcessName(Target);
        if (process.Length == 0 || !GetClientRect(Target, out var box) || box.Right < 100 || box.Bottom < 100)
            throw new InvalidOperationException("Return to the game window before starting.");
        return new(process, box.Right, box.Bottom, []);
    }
    public void SelectForeground() => Target = Foreground;
    public bool TargetMatches(CharacterMacro macro) => Target != 0 && Foreground == Target
        && string.Equals(ProcessName(Target), macro.ProcessName, StringComparison.OrdinalIgnoreCase)
        && GetClientRect(Target, out var box) && box.Right == macro.ClientWidth && box.Bottom == macro.ClientHeight;
    public bool ToClient(NativePoint point, out NativePoint client)
    {
        client = point;
        return GetAncestor(WindowFromPoint(point), 2) == Target && ScreenToClient(Target, ref client);
    }
    public void Send(MacroStep step)
    {
        var point = new NativePoint { X = step.X, Y = step.Y };
        if (!ClientToScreen(Target, ref point) || Foreground != Target || GetAncestor(WindowFromPoint(point), 2) != Target)
            throw new InvalidOperationException("The target click is covered or the app lost focus.");
        if (!SetCursorPos(point.X, point.Y)) throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not move the cursor.");
        if (!GetCursorPos(out var actual) || Math.Abs(actual.X - point.X) > 2 || Math.Abs(actual.Y - point.Y) > 2)
            throw new InvalidOperationException("The game confined the cursor. Unlock it before replay.");
        if (Foreground != Target) throw new InvalidOperationException("App lost focus.");
        uint flag = step.Action switch { MacroAction.LeftDown => 0x2, MacroAction.LeftUp => 0x4, MacroAction.RightDown => 0x8, MacroAction.RightUp => 0x10, _ => 0x800 };
        Dispatch(flag, step.Action == MacroAction.Wheel ? unchecked((uint)step.WheelDelta) : 0);
    }
    private static void Dispatch(uint flag, uint data = 0)
    {
        var inputs = new[] { new Input { Data = new InputData { Mouse = new MouseInput { Flags = flag, Data = data } } } };
        if (SendInput(1, inputs, Marshal.SizeOf<Input>()) != 1) throw new Win32Exception(Marshal.GetLastWin32Error(), "Windows did not accept the mouse action.");
    }
    public void Release(bool left, bool right)
    {
        // Release only buttons this player pressed, without moving the pointer.
        Win32Exception? error = null;
        if (left) try { Dispatch(0x4); } catch (Win32Exception e) { error = e; }
        if (right) try { Dispatch(0x10); } catch (Win32Exception e) { error = e; }
        if (error is not null) throw error;
    }
}

internal sealed class MacroMouseHook : IDisposable
{
    private delegate nint HookProc(int code, nint message, nint data);
    [StructLayout(LayoutKind.Sequential)] private struct MouseData { public MacroWindows.NativePoint Point; public uint Data, Flags, Time; public nuint Extra; }
    [DllImport("user32.dll", SetLastError = true)] private static extern nint SetWindowsHookExW(int id, HookProc callback, nint module, uint threadId);
    [DllImport("user32.dll")] private static extern bool UnhookWindowsHookEx(nint hook);
    [DllImport("user32.dll")] private static extern nint CallNextHookEx(nint hook, int code, nint message, nint data);
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode)] private static extern nint GetModuleHandleW(string? module);
    private readonly HookProc callback;
    private nint hook;
    public MacroMouseHook(Action<MacroAction, MacroWindows.NativePoint, int> receive)
    {
        callback = (code, message, data) =>
        {
            if (code >= 0)
            {
                var value = Marshal.PtrToStructure<MouseData>(data);
                if ((value.Flags & 1) == 0)
                {
                    MacroAction? action = (int)message switch { 0x201 => MacroAction.LeftDown, 0x202 => MacroAction.LeftUp,
                        0x204 => MacroAction.RightDown, 0x205 => MacroAction.RightUp, 0x20a => MacroAction.Wheel, _ => null };
                    if (action is MacroAction kind) receive(kind, value.Point, kind == MacroAction.Wheel ? unchecked((short)(value.Data >> 16)) : 0);
                }
            }
            return CallNextHookEx(hook, code, message, data);
        };
        hook = SetWindowsHookExW(14, callback, GetModuleHandleW(null), 0);
        if (hook == 0) throw new Win32Exception(Marshal.GetLastWin32Error(), "Could not start the mouse recorder.");
    }
    public void Dispose() { if (hook != 0) { UnhookWindowsHookEx(hook); hook = 0; } GC.KeepAlive(callback); }
}
