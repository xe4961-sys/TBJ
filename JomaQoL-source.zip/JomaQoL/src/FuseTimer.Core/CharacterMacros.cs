namespace FuseTimer.Core;

public enum MacroAction { LeftDown, LeftUp, RightDown, RightUp, Wheel }
public sealed record MacroStep(MacroAction Action, int X, int Y, int DelayMs, int WheelDelta = 0);
public sealed record CharacterMacro(string ProcessName, int ClientWidth, int ClientHeight, List<MacroStep> Steps)
{
    public bool Valid
    {
        get
        {
            if (string.IsNullOrWhiteSpace(ProcessName) || ClientWidth is < 100 or > 20000 || ClientHeight is < 100 or > 20000
                || Steps is null || Steps.Count is < 2 or > 200) return false;
            bool left = false, right = false;
            foreach (var step in Steps)
            {
                if (step is null || !Enum.IsDefined(step.Action) || step.X < 0 || step.Y < 0 || step.X >= ClientWidth || step.Y >= ClientHeight
                    || step.DelayMs is < 0 or > 30000) return false;
                switch (step.Action)
                {
                    case MacroAction.LeftDown: if (left) return false; left = true; break;
                    case MacroAction.LeftUp: if (!left) return false; left = false; break;
                    case MacroAction.RightDown: if (right) return false; right = true; break;
                    case MacroAction.RightUp: if (!right) return false; right = false; break;
                    case MacroAction.Wheel: if (step.WheelDelta == 0 || Math.Abs((long)step.WheelDelta) > 1200) return false; break;
                }
            }
            return !left && !right && Steps.Any(step => step.Action is MacroAction.LeftDown or MacroAction.RightDown);
        }
    }
}

public interface IMacroMouse
{
    bool TargetMatches(CharacterMacro macro);
    void Send(MacroStep step);
    void Release(bool left, bool right);
}

/// <summary>Single-run, nonblocking replay. Focus/size checks precede every action.</summary>
public sealed class CharacterMacroPlayer
{
    private readonly IMacroMouse mouse;
    private CharacterMacro? macro;
    private int index, speed, minimumWait;
    private double nextAt;
    private bool left, right;
    public bool Active => macro is not null;
    public string Status { get; private set; } = "Ready.";
    public CharacterMacroPlayer(IMacroMouse mouse) => this.mouse = mouse;
    public bool Start(CharacterMacro recording, int speedPercent, int minimumWaitMs, double now)
    {
        if (Active) return false; // never queue or overlap recordings
        if (!recording.Valid || speedPercent is < 25 or > 400 || minimumWaitMs is < 30 or > 3000 || !double.IsFinite(now))
        { Status = "Invalid recording or replay timing."; return false; }
        macro = recording with { Steps = recording.Steps.ToList() };
        index = 0; speed = speedPercent; minimumWait = minimumWaitMs; nextAt = now;
        left = right = false; Status = "Replaying…";
        return true;
    }
    public void Tick(double now)
    {
        if (macro is null) return;
        try
        {
            if (!mouse.TargetMatches(macro)) { Stop("Stopped: return to the recorded app at the recorded window size."); return; }
            if (now < nextAt) return;
            var step = macro.Steps[index];
            if (step.Action == MacroAction.LeftDown) left = true;
            if (step.Action == MacroAction.RightDown) right = true;
            mouse.Send(step);
            if (step.Action == MacroAction.LeftUp) left = false;
            if (step.Action == MacroAction.RightUp) right = false;
            if (++index == macro.Steps.Count) { Stop("Sequence sent. Check the game for equip success."); return; }
            var next = macro.Steps[index];
            int floor = next.Action is MacroAction.LeftUp or MacroAction.RightUp ? 20 : minimumWait;
            // Schedule relative to actual dispatch: a late UI tick must not burst through a menu.
            nextAt = now + Math.Max(floor, next.DelayMs * 100.0 / speed) / 1000;
        }
        catch (Exception e) when (e is IOException or InvalidOperationException or ArgumentException or System.ComponentModel.Win32Exception)
        { Stop("Replay stopped: " + e.Message); }
    }
    public void Stop(string reason = "Stopped.")
    {
        macro = null; Status = reason;
        if (!left && !right) return;
        try { mouse.Release(left, right); }
        catch (Exception e) when (e is IOException or InvalidOperationException or System.ComponentModel.Win32Exception)
        { Status += " Mouse release failed; release the physical buttons."; }
        finally { left = right = false; }
    }
}

public sealed class CharacterMacroRecorder
{
    private readonly string process;
    private readonly int width, height;
    private readonly List<MacroStep> steps = new();
    private double lastAt;
    public CharacterMacroRecorder(string processName, int clientWidth, int clientHeight, double now)
    { process = processName; width = clientWidth; height = clientHeight; lastAt = now; }
    public int Count => steps.Count;
    public void Add(MacroAction action, int x, int y, double now, int wheelDelta = 0)
    {
        if (steps.Count >= 200 || now < lastAt || now - lastAt > 30 || x < 0 || y < 0 || x >= width || y >= height)
            throw new InvalidOperationException("Recording limits reached, or click was outside the target window. Try recording again.");
        int delay = steps.Count == 0 ? 0 : (int)Math.Round((now - lastAt) * 1000);
        steps.Add(new(action, x, y, delay, wheelDelta)); lastAt = now;
    }
    public CharacterMacro Finish()
    {
        var recording = new CharacterMacro(process, width, height, steps.ToList());
        if (!recording.Valid) throw new InvalidOperationException("No complete click sequence. Release mouse buttons before finishing.");
        return recording;
    }
}
