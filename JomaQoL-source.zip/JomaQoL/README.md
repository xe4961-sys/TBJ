# Joma QoL 3.0.0

A portable Windows 10/11 x64 app combining **Wrecker**, **Guest**, and a recorded **character switcher**. Wrecker retains the grenade timer; Guest tracks recast windows from configured inputs and two calibrated ability-label regions plus optional visual-event regions. This is the first Guest test build. It does not read game memory or detect actual hitboxes. Character macros replay explicitly recorded mouse actions.

## Start and update

1. Exit the previous Fuse Timer / Joma Tracker / Joma QoL from its tray icon first. They share a single-instance guard so two versions cannot compete for inputs/audio.
2. Extract `JomaQoL-Windows-x64.zip` and run **JomaQoL.exe**. No separate .NET installation is required.
3. It starts hidden. Press **F8** (or your saved controls key) or double-click the clock tray icon.
4. Select the **Wrecker** or **Guest** tab. Only the selected mode runs; the selection is saved.
5. Hide controls before playing. Ability inputs are paused while controls are open; Guest's detection preview continues. Closing/minimizing controls hides them; **Exit app** / tray **Exit** quits.

## Character switcher (3.0.0)

Open **F8 → Switcher**. The switcher works independently alongside the last selected Wrecker/Guest mode. **Enable Numpad 1–5 character shortcuts** starts off. The default favorites are **1 Brawler, 2 Knight, 3 Guest, 4 Firefighter, 5 Unassigned**; names are editable. Each favorite needs its own recording on your PC.

### Record a favorite

1. Select the favorite, then **Record selected**. Settings hide. Return to the game with the shop closed (or whichever starting menu state you intend to reuse).
2. Press **F9** (or the configurable recording key) to **begin**. Before this press no mouse actions are recorded.
3. Click **Shop → character → Equip** at your normal pace. Left/right clicks and wheel actions are recorded with client-relative coordinates and elapsed waits. Pointer paths, typing, and keyboard shortcuts are not recorded.
4. Release mouse buttons, then press **F9** again to save. The previous recording is replaced only by a valid complete sequence. **Escape**, opening controls, losing target focus, resizing, or a timeout cancels an unfinished recording and keeps the previous one.
5. Enable the switcher. Hide controls, return to the same game/menu state, and use the favorite's **Numpad key with Num Lock ON**.

An armed/active recording is limited to five minutes, 200 actions, and at most 30 seconds between mouse actions. Only clicks/wheel during explicit recording are retained, locally in the existing settings file. No keyboard typing, screen video, or mouse movement paths are recorded.

### Replay and timing

- Default **Replay speed 200%** halves recorded inter-action waits. A **150ms minimum menu wait** and at least **20ms before button-up** prevent zero-delay click bursts. Slow down/increase the minimum if a menu takes longer to load. You can edit an individual recorded wait in the action list; the first action is immediate.
- Replay jumps the pointer directly between recorded positions. Window movement is supported by transforming client-relative positions; **the client size must match**. Changing resolution, HUD/menu layout, zoom, or scrolling state may require rerecording. Start with exactly the same menu state as recording.
- **Escape**, **F8/opening controls**, **tray Stop macro**, focus loss, or a changed window size stops replay and attempts to release any button the replay held. Repeated favorite shortcuts do not queue or overlap.
- Hotkeys are active only with controls hidden, the switcher enabled, and a recorded target process focused. They use Windows no-repeat hotkeys; Num Lock OFF is unsupported. Conflicts with the Controls/active tracker binds or another program are reported, not silently reassigned.
- Before each replay action the app checks the same foreground window and recorded process name/client size. It also checks that the target point belongs to that window. It does not move focus to another app. SendInput errors stop playback; successful dispatch does not confirm that the game accepted the input or equipped the character.
- The tracker overlays/capture and ability inputs pause while recording or replaying so injected clicks do not start Guest windows. Your tracker resumes afterward. The switcher enable checkbox is independent of Tracking enabled.

Only self-contained Windows x64 cross-compilation and pure playback/recording regression tests were run here. **Real Windows hotkeys, global mouse recording, DPI/window movement, SendInput acceptance, and actual menu timing need testing on your PC.** There is no automatic menu recognition or equip verification.

Settings remain in `%LOCALAPPDATA%\FuseTimer\settings.json` for compatibility. The old single-instance mutex is retained; exit the old tray app before starting JomaQoL.exe. Wrecker/Guest settings and calibration are kept. This release changes the display/executable name, not the TBJ website.

## Wrecker

The default grenade key is **G**, configurable to match the game. The Wrecker timer observes the key without blocking or replaying it. A fresh press restarts the sequence; holding it triggers once.

| Default time after priming | Overlay / sound |
| --- | --- |
| 0–3.00s | Countdown; accelerating electronic beeps |
| 3.00–3.20s | ARMED; urgent beeps |
| 3.20–3.70s | RELEASE!; urgent beeps |
| 3.70–4.00s | BULLSEYE!! in green; audio stops |
| After 4.00s | Overlay hides by default |

Seconds until ARMED is adjustable. The following phases remain 0.20s / 0.50s / 0.30s. There is no spoken voice or added explosion sound. BULLSEYE is a timing marker, not detection of an actual hit.

## Optional visual events (2.0.5)

Both detectors are **off by default**, per-mode Guest settings. Calibrate the normal Kick/Rush profile first, on the current resolution. Open Guest, scroll to **OPTIONAL VISUAL EVENTS**. Extra captures target at most 10 checks/s, separately from the brief 60/s ability-label burst; actual frequency depends on the normal detection rate and capture time. No OCR model, video recording, or uploads.

### Landed Sweep XP

1. Click **Capture Sweep XP in 3s**. Controls hide and detection pauses for calibration. Return to game and land Sweep during that three-second delay.
2. The screen freezes. Select only the white phrase **Landed Sweep.**, including both words, excluding XP/point amounts and other message rows.
3. Select the XP search area, including the sampled phrase and the rows where these messages move. Keep it small (at most 200,000 pixels). Escape cancels.
4. Enable **Refresh Offensive on Landed Sweep XP**, then hide controls with F8.

The calibrated binary phrase is matched within the selected search area, ignoring numbers outside it. A newly appearing phrase, confirmed by two samples after a recent attack (within 1.5s), refreshes Offensive availability for the configured duration. The deadline is anchored to its first observed message, so any delay between the actual hit and the XP message is unavoidable. It does not extend the active Rush's sprint timer or reopen Sweep. Unchanged red Rush text and M1 alone never refresh this window.

A lingering/moving phrase is not new hit evidence. Multiple stacked phrases can be counted; messages replaced in place without a count change or a visible gap may be missed. A brief one-frame detection dropout does not rearm the event. The XP event must be visible in the search region; recalibrate after font/HUD changes. Calibration stores only a binary word template and normalized region. All numeric bonuses are excluded if the words are selected correctly. Both detectors remain off until explicitly enabled.

### Experimental passenger detection

1. Click **Capture red Rush box in 3s**, return to game, and initiate **Supportive Rush** during the delay.
2. Select a representative region containing the **red rectangular box**, including its sides, not just the green capsule. Limit selection to 200,000 pixels; exclude red HUD elements. The picker checks for a broad red cue.
3. Enable **Experimental passenger detection (+2s)**, hide controls, then initiate a fresh Supportive Rush.

Only after the measured 1.65s carry-hitbox startup does it sample this extra region. It requires at least three red-presence samples spanning 0.1s, then at least three absent samples spanning 0.15s. It adds two seconds at most once per Rush and displays **PICKUP? +2s**. Loss within the final 0.3s of the estimated sprint is ignored. Reset/cancel/settings visibility disarm the inference. A manual pickup before inference suppresses the automatic addition for that run. Avoid manually adding time again for the same automatically inferred pickup.

**A wall collision, camera turn, occlusion, or another red object can fool it.** The tracker has no independent confirmation that the character is still rushing; the local countdown alone cannot establish that. This is an optional heuristic, not confirmed passenger recognition. Use reset (default F7) after an interruption or disable it and use the existing manual pickup key. Immediate pickups before enough red samples are collected will be missed. Actual Windows/gameplay recognition must be tested on your PC.

Optional detector calibration/status and the latest XP match count/red visibility appear in Guest settings. Passenger sampling runs only during an active supportive sprint, so its diagnostic may show no current sample while settings are open. Optional capture failures do not stop the two main ability crops. The floating overlay is kept clear of all enabled capture regions. Replacing a main calibration profile also replaces its extra calibrations.

## Compact display (2.0.4)

Enable **Compact display (minimal text, no bars)** in the common settings. Guest combines sprint time and WINDUP / WAIT / READY on one line, with Sweep/Strike and Offensive availability together on another. Notices remain visible and test timers are marked TEST. Wrecker uses a smaller number/warning display. This preference is saved; the full display remains available. Timer and detection logic are unchanged.

Optional visual-event detectors are described above. A disappearing world hitbox remains ambiguous; manual pickup is available.

## Rapid Kick-to-Rush recovery (2.0.3)

- A confirmed Sweep label is additional landed-hit evidence for Offensive Rush selection; Strike alone and Kick input alone never confirm a hit. Sweep expiry/consumption does not erase the remaining hit window. A confirmed return from offensive to supportive availability clears it.
- After Kick, **Fast Kick checks** briefly target up to 60 checks/s for 0.4s, then return to the normal 5–30 setting. This option is on by default and can be disabled in Guest settings. The preview shows the current capture target. Actual capture frequency depends on scheduling/driver speed.
- On a Rush press after a recent Kick, a one-time sample of the small Rush prefix region can catch a red cue between normal checks. Unknown does not overwrite cached evidence. A fresh red sample captured within 1s of Kick can be used without waiting for a second sample; the damage-background filter still applies.
- During the first 0.25s of a Rush request after a recent Kick, an actual offensive cue from the immediate input interval can recover an unconfirmed request or correct an initially supportive estimate. Deadlines stay anchored to the original Rush press. Cancellation/reset closes recovery; unrelated later cues cannot rewrite the run. Captured frames are ordered by capture time, not arrival time.
- If every hit indicator disappears before any sample catches it, the tracker cannot determine a landed hit from input alone. This update improves capture/recovery rather than assuming every Kick connected. Live gameplay still needs checking, especially rapid sequences and whether the game accepts/queues inputs.

## Damage-vignette filtering (2.0.2)

Rush colors now use the lettering's RGB contrast against nearby background pixels. A red damage wash affects both text and card; subtracting the local background helps recover the original text color instead of treating the whole red region as Offensive Rush. Smooth low-contrast gradients, blank red regions, and fully obscured text are rejected. This uses the existing calibrated regions and unchanged 5–30 checks/s setting; it does not add a fixed detection delay or require a new profile. The learned Kick/Strike mask format is unchanged.

Six synthetic regressions cover red washes, gradients, genuine offensive text under tint, white text under tint, and fully hidden text. Actual game rendering can differ; verify during damage in live gameplay. Under severe obscuration the result may be Unknown instead of making a confident guess.

## Rush display and preview tests (2.0.1)

Guest settings has **Test supportive Rush** and **Test offensive Rush** buttons. They hide controls and simulate a timed Rush without calibration or game input. The overlay is clearly marked PREVIEW; press the controls key to stop it. Preview does not change the tracking-enabled setting or send input to the game.

Fixes Rush startup when the game hides its ability cards during windup: the most recent confirmed green/red cue is latched at the key press (maximum evidence age 0.35s), and the active timer continues while the cards are absent. The previous version waited for a post-input cue that could no longer be seen.

A separate sprint-duration line shows 4.00s / 3.00s during windup (marked NEXT), then counts down during sprinting. Offensive Rush additionally shows WAIT until its safe point, then DROPKICK READY. Rush lines are prioritized over unrelated availability lines, with room for six lines. The settings preview reports the last Rush input outcome.

**Persistent Rush: Unknown before input blocks the live Rush timer. A brief Unknown during windup is expected and does not cancel a latched timer.** Recalibrate around the colored Supportive/Offensive prefix, excluding the white Rush word, F icon, and card border. Calibration now rejects a region with no recognizable green/red cue. If the crop contains the correct colored word but remains Unknown, inspect it in borderless/windowed gameplay; do not interpret a successful simulated preview as successful live detection.

## Guest: first-time calibration

Use **windowed or borderless** gameplay. A desktop overlay may not appear above exclusive fullscreen, and protected/unsupported screen surfaces may capture as black.

1. Make base **Kick** and the colored **Supportive / Offensive** Rush prefix visible. Keep controls away from these HUD areas.
2. Open Guest settings. Choose the monitor, enter a profile name, then click **Calibrate text regions**. Controls hide and the monitor image freezes for selection.
3. Drag a tight box around the **Kick word only**, allowing enough empty width for Sweep/Strike. Exclude the card border and LMB icon. This captures the base Kick shape.
4. Drag a tight box around the colored **Supportive / Offensive word only**. Exclude the white Rush word and F icon.
5. Calibration saves automatically once a green/red Rush cue is recognized; otherwise Step 2 asks you to select the colored prefix again. Check the two live crops and the Kick/Rush detection text. Unknown means the cue is not confirmed; a timer should not invent a Rush variant.
6. For reliable white/gold Strike recognition, click **Learn Strike label**, hide controls, perform a roll in game, and press **F6** (default Learn key) while **Strike** is visible. Only the normalized text mask is saved; no gameplay recording is stored. A sample matching base Kick is rejected.
7. Return to controls to inspect recognition. Switch between actual ability states; verify Base / Sweep / Strike and Supportive / Offensive before relying on timings. Then hide controls to play.

Profiles store normalized coordinates, monitor identity, and base/Strike text masks. Selecting another saved profile restores its regions. Saving calibration under an existing name replaces it. Integer scaling is handled by mask normalization; different aspect ratios, HUD scaling, monitor layouts, and font rendering can still require a new calibration/profile. Maximum individual capture region: 200,000 pixels; select text, not the full screen.

## Guest behavior and defaults

All timing fields are adjustable, using the user's 60 FPS measurements as defaults:

| Event | Default |
| --- | --- |
| Sweep recast window | 118/60s = 1.967s |
| Strike availability window | 118/60s = 1.967s |
| Offensive Rush availability | 179/60s = 2.983s |
| Supportive movement windup | 93/60s = 1.550s |
| Supportive carrying hitbox delay | 99/60s = 1.650s |
| Offensive movement windup | 55/60s = 0.917s |
| Safe Dropkick delay, from Rush input | 63/60s = 1.050s |
| Supportive / offensive sprint | 4s / 3s after the respective windup |

- Red Sweep starts its follow-up window. Gold Strike or a learned Strike mask starts Strike. Base Kick clears the follow-up. Kick consumes the displayed follow-up; Roll also clears it until another label confirms availability. Enhanced Kick is excluded.
- The separate Rush color confirms offensive availability. Sweep ending does not clear it. Availability windows count from the first consistent screen observation, capped at the configured duration; returning to the base/supportive cue ends the respective window early. Starting tracking halfway through a window cannot recover its original start time.
- Rush input immediately latches the latest confirmed indicator, including a recent pre-input color if the HUD has just disappeared. Evidence older than 0.35s is rejected. The countdown stays anchored to the input timestamp, with no post-input detection wait. Missing/stale evidence shows **RUSH UNCONFIRMED**. If no hit or variant indicator is ever captured, the tracker cannot infer the missing state from the key press; check the selected variant during gameplay testing.
- After the brief input-race recovery interval, the selected Rush variant stays locked for that run even if its HUD color changes. Offensive Rush shows a windup/wait warning, then **DROPKICK READY** from 1.05s until about 3.917s after input. A second Rush input consumes the window; during startup it is treated as cancellation. This assumes the game accepts the input.
- Supportive Rush shows its windup then a four-second sprint. Optional **manual ally pickup +2s** is off by default. When enabled, each pickup-key press after the carrying hitbox starts adds two seconds to that supportive run. Use it only for a real pickup. The separate optional passenger heuristic is described above; do not manually add time again for the same inferred pickup.
- Windows have numeric timers and shrinking bars. The overlay hides when idle by default. **Reset Guest windows** clears estimates without instantly restarting from an unchanged label.
- Cooldowns, Enhanced Kick, actual hitbox detection, and automatic wall/stun/end detection are excluded. Use reset for interruptions.

### Guest bindings

| Action | Default |
| --- | --- |
| Kick / recast | Left mouse |
| Dodgeroll | Q |
| Rush / Dropkick | F |
| Reset Guest windows | F7 |
| Learn Strike sample | F6 |
| Manual pickup +2s (optional, initially disabled) | F10 |
| Open / hide controls (both modes) | F8 |

Click a binding button, release held keys/buttons, then press its replacement. Escape cancels; capture times out after 15 seconds. Guest binds and the controls key must differ, including the optional pickup key. The Wrecker grenade bind may overlap a Guest ability because only one mode runs. The app does not change in-game binds: configure it to match them.

## Shared controls

- **Tracking enabled** pauses/resumes tracking and Guest capture.
- **Sound on / Volume** affect all cues. Guest readiness beeps are separately optional, off by default.
- **Test sound** plays a longer beep and reconnects to the default Windows output. Errors are visible. **Windows mixer** opens app volume/output settings.
- **Hide idle overlay** hides inactive timers. **Wrecker text pulse** controls gentle 2 Hz ARMED/RELEASE pulsing only.
- **Position overlay** allows dragging the text; click Done positioning to restore click-through. Guest capture pauses during overlay positioning. When positioning ends, an overlapping overlay is moved to a nearby clear location to keep its text out of the two detector regions. If no clear placement is available, detection pauses with a warning. Guest and Wrecker positions are saved separately. The normal overlay is transparent, borderless, topmost, non-activating, and has no taskbar entry.

## Capture and performance

Guest uses GDI screen copies of the two selected regions, then local-background-relative color checks and normalized binary-mask matching. There is no OCR model, full-frame recognition loop, video encoding, network access, or gameplay recording. One background capture job is allowed at a time. Consecutive agreeing samples reduce false positives. The default steady rate is **20 checks/second**, adjustable from **5 to 30**, with an optional short up-to-60/s burst after Kick and one input-triggered Rush-region check. Wrecker mode does not capture the screen.

The preview reports the last capture/analysis wall time, not FPS loss or GPU utilization. Detection has capture/scheduling latency; low sample rates, animation fades, scaling, obstructed HUDs, or stale frames may affect accuracy. We have not measured in-game FPS impact. Compare tracking on/off on the target PC; reducing checks/s reduces work and increases detection latency.

Settings remain in `%LOCALAPPDATA%\FuseTimer\settings.json` for compatibility with the previous app. Existing Wrecker mute/volume/binds are preserved. Screen captures are discarded except the binary base/Strike/XP text masks saved in the selected profile. There is no telemetry. Tracker modes observe configured keys; the optional character switcher uses explicit recorded mouse actions and Windows hotkeys, then replays those mouse actions with SendInput. It does not retain typed key history. Favorite click coordinates, waits, target process name, and client size are saved locally.

## Build and validation

Use the official .NET 10 SDK pinned in `global.json`:

```powershell
dotnet run --project tests/FuseTimer.Tests -c Release
dotnet publish src/FuseTimer.App -c Release -r win-x64 --self-contained true -o artifacts/win-x64
```

`build.ps1` tests, builds, and creates the portable ZIP. A Windows CI workflow is included in the source archive. Binaries/source ZIPs are published only on TBJ's separate `fuse-timer-download` branch; do not merge it into the website's main branch.

**69 tests pass** for Wrecker timing/audio regression, Guest timing boundaries and the separate countdown/phase display, independent windows, input consumption, stale-cue rejection, variant locking, manual extensions, resets, debounce, normalized region scaling, and synthetic color/template samples. The Windows app is cross-compiled on Linux. Actual Windows capture, calibration UI, mixed-DPI behavior, game input, native overlay drawing, and speaker output still require a Windows gameplay test. Detector tests use synthetic images; they do not establish accuracy on live gameplay. The self-contained Windows x64 executable is unsigned.
