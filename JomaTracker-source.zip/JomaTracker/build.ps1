$ErrorActionPreference = 'Stop'
Push-Location $PSScriptRoot
try {
    dotnet run --project tests/FuseTimer.Tests -c Release
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    dotnet publish src/FuseTimer.App -c Release -r win-x64 --self-contained true -o artifacts/win-x64
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
    Compress-Archive -Path artifacts/win-x64/JomaTracker.exe, QUICKSTART.txt, README.md -DestinationPath artifacts/JomaTracker-Windows-x64.zip -Force
    Write-Host 'Ready: artifacts/JomaTracker-Windows-x64.zip'
} finally {
    Pop-Location
}
