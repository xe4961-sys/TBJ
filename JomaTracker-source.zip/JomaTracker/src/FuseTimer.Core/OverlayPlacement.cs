using System.Drawing;

namespace FuseTimer.Core;

public static class OverlayPlacement
{
    public static Rectangle? ClearOfLabels(Rectangle overlay, Rectangle workingArea, IReadOnlyList<Rectangle> labels)
    {
        bool Fits(Rectangle candidate) => workingArea.Contains(candidate) && labels.All(label => !candidate.IntersectsWith(label));
        if (Fits(overlay)) return overlay;
        var candidates = new List<Rectangle>();
        void Add(int x, int y)
        {
            x = Math.Clamp(x, workingArea.Left, Math.Max(workingArea.Left, workingArea.Right - overlay.Width));
            y = Math.Clamp(y, workingArea.Top, Math.Max(workingArea.Top, workingArea.Bottom - overlay.Height));
            candidates.Add(new(x, y, overlay.Width, overlay.Height));
        }
        Add(overlay.X, overlay.Y);
        foreach (var label in labels)
        {
            Add(overlay.X, label.Top - overlay.Height - 12);
            Add(overlay.X, label.Bottom + 12);
            Add(label.Left - overlay.Width - 12, overlay.Y);
            Add(label.Right + 12, overlay.Y);
        }
        Add(workingArea.Left, workingArea.Top); Add(workingArea.Right - overlay.Width, workingArea.Top);
        Add(workingArea.Left, workingArea.Bottom - overlay.Height); Add(workingArea.Right - overlay.Width, workingArea.Bottom - overlay.Height);
        return candidates.Where(Fits).OrderBy(candidate => Math.Abs((long)candidate.X - overlay.X) + Math.Abs((long)candidate.Y - overlay.Y)).Select(candidate => (Rectangle?)candidate).FirstOrDefault();
    }
}
