namespace FuseTimer.Core;

public sealed record GuestLine(string Text, double? Progress = null);

public static class GuestDisplay
{
    public static GuestLine[] Lines(GuestFrame frame, GuestTimings timings, bool checking, bool preview, string controlsName, bool compact = false)
    {
        if (compact) return CompactLines(frame, checking, preview, controlsName);
        var lines = new List<GuestLine>();
        void Add(string text, double? progress = null) => lines.Add(new(text, progress is double value ? Math.Clamp(value, 0, 1) : null));
        if (checking) Add("RUSH — CHECKING INDICATOR");
        bool support = frame.Rush is RushPhase.SupportWindup or RushPhase.SupportSprint;
        if (frame.Rush != RushPhase.Idle)
        {
            string variant = support ? "SUPPORT" : "OFFENSIVE";
            bool windup = frame.Rush is RushPhase.SupportWindup or RushPhase.OffensiveWindup;
            Add($"{variant} SPRINT{(windup ? " NEXT" : "")}  {frame.SprintRemaining:0.00}s", frame.SprintRemaining / frame.SprintTotal);
            if (windup) Add($"WINDUP  {frame.RushRemaining:0.00}s", frame.RushRemaining / frame.RushTotal);
            if (!support)
            {
                if (frame.Rush == RushPhase.DropkickReady) Add("DROPKICK READY");
                else Add($"WAIT — RECAST CANCELS  {frame.SafeRemaining:0.00}s", frame.SafeRemaining / timings.SafeDropkick);
            }
            else if (frame.Rush == RushPhase.SupportSprint && !frame.CarryReady) Add("CARRY HITBOX STARTING");
        }
        if (!string.IsNullOrEmpty(frame.Notice)) Add(frame.Notice);
        if (frame.Followup != KickCue.Unknown) Add($"{frame.Followup.ToString().ToUpperInvariant()} READY  {frame.FollowupRemaining:0.00}s", frame.FollowupRemaining / (frame.Followup == KickCue.Sweep ? timings.Sweep : timings.Strike));
        if (frame.OffensiveRemaining > 0) Add($"OFFENSIVE AVAILABLE  {frame.OffensiveRemaining:0.00}s", frame.OffensiveRemaining / timings.OffensiveAvailable);
        if (lines.Count == 0 && preview) { Add("GUEST — WAITING FOR CUES"); Add("SWEEP / STRIKE / RUSH"); Add($"{controlsName} opens controls"); }
        return lines.Take(6).ToArray();
    }
    private static GuestLine[] CompactLines(GuestFrame frame, bool checking, bool preview, string controlsName)
    {
        var lines = new List<GuestLine>();
        bool support = frame.Rush is RushPhase.SupportWindup or RushPhase.SupportSprint;
        if (frame.Rush != RushPhase.Idle)
        {
            string phase = frame.Rush switch
            {
                RushPhase.SupportWindup or RushPhase.OffensiveWindup => $"WINDUP {frame.RushRemaining:0.00}s",
                RushPhase.RecastWait => $"WAIT {frame.SafeRemaining:0.00}s",
                RushPhase.DropkickReady => "READY",
                _ => "RUN"
            };
            lines.Add(new($"{(support ? "SUP" : "OFF")} {frame.SprintRemaining:0.00}s | {phase}"));
        }
        else if (checking) lines.Add(new("RUSH: CHECKING"));
        var windows = new List<string>();
        if (frame.Followup != KickCue.Unknown) windows.Add($"{frame.Followup.ToString().ToUpperInvariant()} {frame.FollowupRemaining:0.00}s");
        if (frame.OffensiveRemaining > 0) windows.Add($"OFF {frame.OffensiveRemaining:0.00}s");
        if (windows.Count > 0) lines.Add(new(string.Join(" | ", windows)));
        if (!string.IsNullOrEmpty(frame.Notice)) lines.Add(new(frame.Notice));
        if (lines.Count == 0 && preview) lines.Add(new($"GUEST | {controlsName} controls"));
        return lines.ToArray();
    }
}
