namespace FuseTimer.Core;

public sealed record PixelGrid(int Width, int Height, int[] Pixels);
public sealed record NormalizedRegion(double X, double Y, double Width, double Height)
{
    public bool Valid => new[] { X, Y, Width, Height }.All(double.IsFinite) && X >= 0 && Y >= 0 && Width > 0 && Height > 0 && X + Width <= 1.000001 && Y + Height <= 1.000001;
    public (int X, int Y, int Width, int Height) Resolve(int screenWidth, int screenHeight)
    {
        if (!Valid || screenWidth < 1 || screenHeight < 1) throw new ArgumentException("Invalid capture region");
        int x = Math.Clamp((int)Math.Round(X * screenWidth), 0, screenWidth - 1);
        int y = Math.Clamp((int)Math.Round(Y * screenHeight), 0, screenHeight - 1);
        return (x, y, Math.Clamp((int)Math.Round(Width * screenWidth), 1, screenWidth - x), Math.Clamp((int)Math.Round(Height * screenHeight), 1, screenHeight - y));
    }
}

public static class CueDetection
{
    public const int MaskWidth = 64, MaskHeight = 24;
    private static bool Lit(int pixel) => Math.Max((pixel >> 16) & 255, Math.Max((pixel >> 8) & 255, pixel & 255)) >= 110;
    public static byte[] Mask(PixelGrid grid)
    {
        Validate(grid);
        int left = grid.Width, top = grid.Height, right = -1, bottom = -1;
        for (int y = 0; y < grid.Height; y++) for (int x = 0; x < grid.Width; x++)
            if (Lit(grid.Pixels[y * grid.Width + x])) { left = Math.Min(left, x); top = Math.Min(top, y); right = Math.Max(right, x); bottom = Math.Max(bottom, y); }
        var mask = new byte[MaskWidth * MaskHeight];
        if (right < left || bottom < top) return mask;
        for (int y = 0; y < MaskHeight; y++) for (int x = 0; x < MaskWidth; x++)
        {
            int sx = left + Math.Min(right - left, x * (right - left + 1) / MaskWidth);
            int sy = top + Math.Min(bottom - top, y * (bottom - top + 1) / MaskHeight);
            mask[y * MaskWidth + x] = Lit(grid.Pixels[sy * grid.Width + sx]) ? (byte)1 : (byte)0;
        }
        return mask;
    }
    public static double Similarity(byte[] sample, byte[]? template)
    {
        if (template is null || template.Length != sample.Length) return 0;
        int intersection = 0, union = 0;
        for (int i = 0; i < sample.Length; i++)
        { if (sample[i] != 0 || template[i] != 0) union++; if (sample[i] != 0 && template[i] != 0) intersection++; }
        return union < 10 ? 0 : intersection / (double)union;
    }
    public static bool UsableTemplate(byte[]? mask) => mask?.Length == MaskWidth * MaskHeight && mask.Count(value => value == 1) >= 30 && mask.All(value => value <= 1);
    public static KickCue Kick(PixelGrid grid, byte[]? baseTemplate, byte[]? strikeTemplate)
    {
        var colors = Colors(grid);
        if (colors.Lit < 10) return KickCue.Unknown;
        byte[] mask = Mask(grid);
        double baseScore = Similarity(mask, baseTemplate), strikeScore = Similarity(mask, strikeTemplate);
        if (strikeScore >= .78 && strikeScore > baseScore + .08) return KickCue.Strike;
        if (baseScore >= .78 && baseScore > strikeScore + .08) return KickCue.Base;
        if (colors.Red > .28) return KickCue.Sweep;
        if (colors.Gold > .35 && baseScore < .7) return KickCue.Strike;
        return KickCue.Unknown;
    }
    public static RushCue Rush(PixelGrid grid)
    {
        var colors = Colors(grid);
        if (colors.Lit < 10) return RushCue.Unknown;
        if (colors.Red > .30 && colors.Red > colors.Green * 1.5) return RushCue.Offensive;
        if (colors.Green > .30 && colors.Green > colors.Red * 1.5) return RushCue.Supportive;
        return RushCue.Unknown;
    }
    private static (int Lit, double Red, double Green, double Gold) Colors(PixelGrid grid)
    {
        Validate(grid);
        // Compare each pixel to nearby background rather than absolute red.
        // A damage vignette adds red to BOTH the card and its lettering. Local
        // channel differences remove that shared tint, including smooth gradients.
        int[] contrast = new int[grid.Pixels.Length];
        Span<int> histogram = stackalloc int[256]; histogram.Clear();
        for (int y = 0; y < grid.Height; y++) for (int x = 0; x < grid.Width; x++)
        {
            int pixel = grid.Pixels[y * grid.Width + x];
            int r = (pixel >> 16) & 255, g = (pixel >> 8) & 255, b = pixel & 255;
            int backgroundR = r, backgroundG = g, backgroundB = b;
            for (int dy = -3; dy <= 3; dy += 3) for (int dx = -3; dx <= 3; dx += 3)
            {
                int neighbor = grid.Pixels[Math.Clamp(y + dy, 0, grid.Height - 1) * grid.Width + Math.Clamp(x + dx, 0, grid.Width - 1)];
                backgroundR = Math.Min(backgroundR, (neighbor >> 16) & 255);
                backgroundG = Math.Min(backgroundG, (neighbor >> 8) & 255);
                backgroundB = Math.Min(backgroundB, neighbor & 255);
            }
            r -= backgroundR; g -= backgroundG; b -= backgroundB;
            contrast[y * grid.Width + x] = (r << 16) | (g << 8) | b;
            histogram[Math.Max(r, Math.Max(g, b))]++;
        }
        // Ignore isolated bright noise. Very low contrast is uncertain, not red.
        int target = (int)Math.Ceiling(grid.Pixels.Length * .99), sum = 0, peak = 0;
        for (int i = 0; i < histogram.Length; i++) { sum += histogram[i]; if (sum >= target) { peak = i; break; } }
        if (peak < 30) return (0, 0, 0, 0);
        double threshold = Math.Max(12, peak * .45);
        int lit = 0, red = 0, green = 0, gold = 0;
        for (int i = 0; i < contrast.Length; i++)
        {
            int pixel = contrast[i];
            int r = (pixel >> 16) & 255, g = (pixel >> 8) & 255, b = pixel & 255;
            if (!Lit(grid.Pixels[i]) || Math.Max(r, Math.Max(g, b)) < threshold) continue;
            lit++;
            if (r >= threshold && g < r * .8 && b < r * .85) red++;
            if (g >= threshold && r < g * .9 && b < g * .9) green++;
            if (r >= threshold && g >= threshold && b < Math.Min(r, g) * .82) gold++;
        }
        return (lit, red / (double)Math.Max(1, lit), green / (double)Math.Max(1, lit), gold / (double)Math.Max(1, lit));
    }
    private static void Validate(PixelGrid grid)
    {
        if (grid.Width < 1 || grid.Height < 1 || (long)grid.Width * grid.Height != grid.Pixels.Length) throw new ArgumentException("Invalid pixel grid");
    }
}
