namespace FuseTimer.Core;

/// <summary>Short, input-correlated capture boost; input itself never confirms a hit.</summary>
public sealed class FastKickEvidence
{
    private double kickAt = double.NegativeInfinity;
    public void Kick(double now) => kickAt = now;
    public bool IsBurst(double now) => now >= kickAt && now - kickAt <= .4;
    public bool Accept(RushCue rawCue, double capturedAt, double receivedAt) => rawCue == RushCue.Offensive
        && capturedAt >= kickAt && capturedAt - kickAt <= 1
        && receivedAt >= capturedAt && receivedAt - capturedAt <= .2;
    public void Reset() => kickAt = double.NegativeInfinity;
}
