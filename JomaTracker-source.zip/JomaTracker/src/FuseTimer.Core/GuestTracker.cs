namespace FuseTimer.Core;

public enum KickCue { Unknown, Base, Sweep, Strike }
public enum RushCue { Unknown, Supportive, Offensive }
public enum RushPhase { Idle, SupportWindup, SupportSprint, OffensiveWindup, RecastWait, DropkickReady }

public sealed record GuestTimings
{
    public double Sweep { get; set; } = 118 / 60.0;
    public double Strike { get; set; } = 118 / 60.0;
    public double OffensiveAvailable { get; set; } = 179 / 60.0;
    public double SupportWindup { get; set; } = 93 / 60.0;
    public double CarryHitbox { get; set; } = 99 / 60.0;
    public double OffensiveWindup { get; set; } = 55 / 60.0;
    public double SafeDropkick { get; set; } = 63 / 60.0;
    public double SupportSprint { get; set; } = 4;
    public double OffensiveSprint { get; set; } = 3;
    public bool Valid => new[] { Sweep, Strike, OffensiveAvailable, SupportWindup, CarryHitbox, OffensiveWindup, SafeDropkick, SupportSprint, OffensiveSprint }
        .All(value => double.IsFinite(value) && value > 0 && value <= 30)
        && SafeDropkick >= OffensiveWindup && SafeDropkick < OffensiveWindup + OffensiveSprint && CarryHitbox >= SupportWindup;
}

public readonly record struct GuestFrame(KickCue Followup, double FollowupRemaining, double OffensiveRemaining,
    RushPhase Rush, double RushRemaining, double SafeRemaining, bool CarryReady, string Notice, double RushTotal = 0,
    double SprintRemaining = 0, double SprintTotal = 0);

/// <summary>Independent follow-up/availability timers, with a latched rush variant.</summary>
public sealed class GuestTracker
{
    private readonly GuestTimings timings;
    private KickCue lastKick, followup;
    private RushCue lastConfirmedRush, latestRush, activeRush;
    private double followupEnd, offensiveEnd, rushObservedAt = double.NegativeInfinity;
    private double lastKnownRushAt = double.NegativeInfinity;
    private double rushStarted, rushEnd, noticeEnd;
    private string notice = "";
    public GuestTracker(GuestTimings timings) { if (!timings.Valid) throw new ArgumentException("Invalid Guest timings"); this.timings = timings with { }; }
    public void ObserveKick(KickCue cue, double now)
    {
        if (cue == KickCue.Unknown) return;
        if (cue == KickCue.Base) { followup = KickCue.Unknown; followupEnd = 0; }
        else if (cue != lastKick)
        {
            followup = cue;
            followupEnd = now + (cue == KickCue.Sweep ? timings.Sweep : timings.Strike);
        }
        lastKick = cue;
    }
    public void ObserveRush(RushCue cue, double now, double? appearedAt = null)
    {
        latestRush = cue; rushObservedAt = now;
        if (cue == RushCue.Unknown) return;
        lastKnownRushAt = now;
        if (cue == RushCue.Supportive) offensiveEnd = 0;
        else if (cue != lastConfirmedRush) offensiveEnd = (appearedAt ?? now) + timings.OffensiveAvailable;
        lastConfirmedRush = cue;
    }
    public void KickPressed() { followup = KickCue.Unknown; followupEnd = 0; }
    public void RollPressed() => KickPressed();
    public void CancelRush(double now) { activeRush = RushCue.Unknown; Notice("RUSH CANCELLED", now); }
    public void RushPressed(double now, double? inputTime = null)
    {
        if (activeRush != RushCue.Unknown && now < rushEnd)
        {
            bool dropkick = activeRush == RushCue.Offensive && now - rushStarted >= timings.SafeDropkick;
            activeRush = RushCue.Unknown;
            Notice(dropkick ? "DROPKICK USED" : "RUSH CANCELLED", now);
            return;
        }
        activeRush = RushCue.Unknown;
        // The game hides its ability cards during windup. A recent confirmed
        // pre-input color remains valid evidence even after an Unknown sample.
        RushCue variant = latestRush == RushCue.Unknown ? lastConfirmedRush : latestRush;
        double observedAt = latestRush == RushCue.Unknown ? lastKnownRushAt : rushObservedAt;
        if (variant == RushCue.Unknown || now - observedAt > .35 || now < observedAt)
        { Notice("RUSH UNCONFIRMED — check detection", now); return; }
        activeRush = variant;
        rushStarted = inputTime ?? now;
        rushEnd = rushStarted + (activeRush == RushCue.Offensive ? timings.OffensiveWindup + timings.OffensiveSprint : timings.SupportWindup + timings.SupportSprint);
        noticeEnd = 0;
    }
    public bool AddPickup(double now)
    {
        if (activeRush != RushCue.Supportive || now < rushStarted + timings.CarryHitbox || now >= rushEnd) return false;
        rushEnd += 2; Notice("ALLY PICKUP +2s", now); return true;
    }
    public GuestFrame Frame(double now)
    {
        double followupRemaining = Math.Max(0, followupEnd - now);
        var phase = RushPhase.Idle;
        double remaining = 0, safeRemaining = 0, total = 0, sprintRemaining = 0, sprintTotal = 0;
        bool carry = false;
        if (activeRush != RushCue.Unknown && now < rushEnd)
        {
            double age = Math.Max(0, now - rushStarted);
            double windup = activeRush == RushCue.Supportive ? timings.SupportWindup : timings.OffensiveWindup;
            sprintTotal = rushEnd - rushStarted - windup;
            sprintRemaining = Math.Min(sprintTotal, rushEnd - now);
            if (activeRush == RushCue.Supportive)
            {
                phase = age < timings.SupportWindup ? RushPhase.SupportWindup : RushPhase.SupportSprint;
                remaining = phase == RushPhase.SupportWindup ? timings.SupportWindup - age : rushEnd - now;
                total = phase == RushPhase.SupportWindup ? timings.SupportWindup : rushEnd - rushStarted - timings.SupportWindup;
                carry = age >= timings.CarryHitbox;
            }
            else
            {
                phase = age < timings.OffensiveWindup ? RushPhase.OffensiveWindup : age < timings.SafeDropkick ? RushPhase.RecastWait : RushPhase.DropkickReady;
                remaining = phase == RushPhase.OffensiveWindup ? timings.OffensiveWindup - age : rushEnd - now;
                safeRemaining = Math.Max(0, timings.SafeDropkick - age);
                total = phase == RushPhase.OffensiveWindup ? timings.OffensiveWindup : phase == RushPhase.RecastWait ? timings.SafeDropkick - timings.OffensiveWindup
                    : timings.OffensiveWindup + timings.OffensiveSprint - timings.SafeDropkick;
            }
        }
        else activeRush = RushCue.Unknown;
        return new(followupRemaining > 0 ? followup : KickCue.Unknown, followupRemaining,
            Math.Max(0, offensiveEnd - now), phase, remaining, safeRemaining, carry, now < noticeEnd ? notice : "", total, sprintRemaining, sprintTotal);
    }
    private void Notice(string text, double now) { notice = text; noticeEnd = now + 1.2; }
    public void Reset(bool forgetCues = true)
    {
        followup = KickCue.Unknown; activeRush = RushCue.Unknown;
        if (forgetCues) { lastKick = KickCue.Unknown; lastConfirmedRush = latestRush = RushCue.Unknown; rushObservedAt = lastKnownRushAt = double.NegativeInfinity; }
        followupEnd = offensiveEnd = rushEnd = noticeEnd = 0;
    }
}

/// <summary>Require consecutive agreeing samples; uncertainty never becomes a confirmed cue immediately.</summary>
public sealed class StableCue<T> where T : struct, Enum
{
    private T candidate;
    private int count;
    public T Value { get; private set; }
    public double Since { get; private set; }
    public bool Push(T value, double now = 0)
    {
        if (count == 0 || !value.Equals(candidate)) { candidate = value; count = 1; Since = now; }
        else count++;
        if (count < 2) return false;
        Value = value;
        return true;
    }
}
