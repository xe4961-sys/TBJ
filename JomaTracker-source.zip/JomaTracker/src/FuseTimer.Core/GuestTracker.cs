namespace FuseTimer.Core;

public enum KickCue { Unknown, Base, Sweep, Strike }
public enum RushCue { Unknown, Supportive, Offensive }
public enum RushPhase { Idle, SupportWindup, SupportSprint, OffensiveWindup, RecastWait, DropkickReady }

public sealed record GuestTimings
{
    public double Sweep { get; set; } = 118 / 60.0;
    public double Strike { get; set; } = 118 / 60.0;
    public double OffensiveAvailable { get; set; } = 179 / 60.0;
    public double SupportWindup { get; set; } = 93 / 60.0;
    public double CarryHitbox { get; set; } = 99 / 60.0;
    public double OffensiveWindup { get; set; } = 55 / 60.0;
    public double SafeDropkick { get; set; } = 63 / 60.0;
    public double SupportSprint { get; set; } = 4;
    public double OffensiveSprint { get; set; } = 3;
    public bool Valid => new[] { Sweep, Strike, OffensiveAvailable, SupportWindup, CarryHitbox, OffensiveWindup, SafeDropkick, SupportSprint, OffensiveSprint }
        .All(value => double.IsFinite(value) && value > 0 && value <= 30)
        && SafeDropkick >= OffensiveWindup && SafeDropkick < OffensiveWindup + OffensiveSprint && CarryHitbox >= SupportWindup;
}

public readonly record struct GuestFrame(KickCue Followup, double FollowupRemaining, double OffensiveRemaining,
    RushPhase Rush, double RushRemaining, double SafeRemaining, bool CarryReady, string Notice, double RushTotal = 0,
    double SprintRemaining = 0, double SprintTotal = 0);

/// <summary>Independent follow-up/availability timers, with a latched rush variant.</summary>
public sealed class GuestTracker
{
    private readonly GuestTimings timings;
    private KickCue lastKick, followup;
    private RushCue lastConfirmedRush, latestRush, activeRush;
    private double followupEnd, offensiveEnd, rushObservedAt = double.NegativeInfinity;
    private double lastKnownRushAt = double.NegativeInfinity;
    private double rushStarted, rushEnd, noticeEnd;
    private double kickPressedAt = double.NegativeInfinity, hitAt = double.NegativeInfinity, hitUntil;
    private double requestedRushAt = double.NegativeInfinity;
    private bool hitSawOffensive, correctionAllowed;
    private string notice = "";
    public GuestTracker(GuestTimings timings) { if (!timings.Valid) throw new ArgumentException("Invalid Guest timings"); this.timings = timings with { }; }
    public void ObserveKick(KickCue cue, double now, double? receivedAt = null)
    {
        if (cue == KickCue.Unknown) return;
        if (cue == KickCue.Base) { followup = KickCue.Unknown; followupEnd = 0; }
        else if (cue != lastKick)
        {
            followup = cue;
            followupEnd = now + (cue == KickCue.Sweep ? timings.Sweep : timings.Strike);
            // Sweep is the game's confirmed-hit follow-up. Strike is also
            // available after a roll and must never count as hit evidence.
            if (cue == KickCue.Sweep)
            {
                hitAt = now; hitUntil = now + timings.OffensiveAvailable;
                hitSawOffensive = lastConfirmedRush == RushCue.Offensive && now - lastKnownRushAt <= .35;
                TryConfirmOffensive(now, receivedAt ?? now);
            }
        }
        lastKick = cue;
    }
    public void ObserveRush(RushCue cue, double now, double? appearedAt = null, double? receivedAt = null)
    {
        if (now < rushObservedAt) return;
        latestRush = cue; rushObservedAt = now;
        if (cue == RushCue.Unknown) return;
        lastKnownRushAt = now;
        if (cue == RushCue.Supportive)
        {
            offensiveEnd = 0;
            if (hitSawOffensive && now >= hitAt) hitUntil = 0;
        }
        else
        {
            if (cue != lastConfirmedRush) offensiveEnd = (appearedAt ?? now) + timings.OffensiveAvailable;
            if (now >= hitAt) hitSawOffensive = true;
            TryConfirmOffensive(appearedAt ?? now, receivedAt ?? now);
        }
        lastConfirmedRush = cue;
    }
    public void KickPressed(double? now = null)
    {
        followup = KickCue.Unknown; followupEnd = 0;
        if (now is double stamp) kickPressedAt = stamp;
    }
    public void RollPressed() => KickPressed();
    public void CancelRush(double now) { activeRush = RushCue.Unknown; correctionAllowed = false; Notice("RUSH CANCELLED", now); }
    public void RushPressed(double now, double? inputTime = null)
    {
        if (activeRush == RushCue.Unknown && correctionAllowed && now >= requestedRushAt && now - requestedRushAt <= .25)
        { CancelRush(now); return; }
        if (activeRush != RushCue.Unknown && now < rushEnd)
        {
            bool dropkick = activeRush == RushCue.Offensive && now - rushStarted >= timings.SafeDropkick;
            activeRush = RushCue.Unknown;
            correctionAllowed = false;
            Notice(dropkick ? "DROPKICK USED" : "RUSH CANCELLED", now);
            return;
        }
        activeRush = RushCue.Unknown;
        requestedRushAt = inputTime ?? now;
        correctionAllowed = requestedRushAt >= kickPressedAt && requestedRushAt - kickPressedAt <= 1;
        // The game hides its ability cards during windup. A recent confirmed
        // pre-input color remains valid evidence even after an Unknown sample.
        RushCue variant = latestRush == RushCue.Unknown ? lastConfirmedRush : latestRush;
        double observedAt = latestRush == RushCue.Unknown ? lastKnownRushAt : rushObservedAt;
        bool hitConfirmed = now >= hitAt && now < hitUntil;
        if (hitConfirmed) variant = RushCue.Offensive;
        if (!hitConfirmed && (variant == RushCue.Unknown || now - observedAt > .35 || now < observedAt))
        { Notice("RUSH UNCONFIRMED — check detection", now); return; }
        activeRush = variant;
        rushStarted = inputTime ?? now;
        rushEnd = rushStarted + (activeRush == RushCue.Offensive ? timings.OffensiveWindup + timings.OffensiveSprint : timings.SupportWindup + timings.SupportSprint);
        noticeEnd = 0;
    }
    public bool TryConfirmOffensive(double evidenceAt, double receivedAt)
    {
        if (!correctionAllowed || activeRush == RushCue.Offensive || receivedAt < requestedRushAt
            || receivedAt - requestedRushAt > .25 || evidenceAt < requestedRushAt - .20 || evidenceAt > requestedRushAt + .15)
            return false;
        activeRush = RushCue.Offensive;
        rushStarted = requestedRushAt;
        rushEnd = rushStarted + timings.OffensiveWindup + timings.OffensiveSprint;
        noticeEnd = 0;
        return true;
    }
    public bool AddPickup(double now)
    {
        if (activeRush != RushCue.Supportive || now < rushStarted + timings.CarryHitbox || now >= rushEnd) return false;
        rushEnd += 2; Notice("ALLY PICKUP +2s", now); return true;
    }
    public GuestFrame Frame(double now)
    {
        double followupRemaining = Math.Max(0, followupEnd - now);
        var phase = RushPhase.Idle;
        double remaining = 0, safeRemaining = 0, total = 0, sprintRemaining = 0, sprintTotal = 0;
        bool carry = false;
        if (activeRush != RushCue.Unknown && now < rushEnd)
        {
            double age = Math.Max(0, now - rushStarted);
            double windup = activeRush == RushCue.Supportive ? timings.SupportWindup : timings.OffensiveWindup;
            sprintTotal = rushEnd - rushStarted - windup;
            sprintRemaining = Math.Min(sprintTotal, rushEnd - now);
            if (activeRush == RushCue.Supportive)
            {
                phase = age < timings.SupportWindup ? RushPhase.SupportWindup : RushPhase.SupportSprint;
                remaining = phase == RushPhase.SupportWindup ? timings.SupportWindup - age : rushEnd - now;
                total = phase == RushPhase.SupportWindup ? timings.SupportWindup : rushEnd - rushStarted - timings.SupportWindup;
                carry = age >= timings.CarryHitbox;
            }
            else
            {
                phase = age < timings.OffensiveWindup ? RushPhase.OffensiveWindup : age < timings.SafeDropkick ? RushPhase.RecastWait : RushPhase.DropkickReady;
                remaining = phase == RushPhase.OffensiveWindup ? timings.OffensiveWindup - age : rushEnd - now;
                safeRemaining = Math.Max(0, timings.SafeDropkick - age);
                total = phase == RushPhase.OffensiveWindup ? timings.OffensiveWindup : phase == RushPhase.RecastWait ? timings.SafeDropkick - timings.OffensiveWindup
                    : timings.OffensiveWindup + timings.OffensiveSprint - timings.SafeDropkick;
            }
        }
        else activeRush = RushCue.Unknown;
        return new(followupRemaining > 0 ? followup : KickCue.Unknown, followupRemaining,
            Math.Max(0, offensiveEnd - now), phase, remaining, safeRemaining, carry, now < noticeEnd ? notice : "", total, sprintRemaining, sprintTotal);
    }
    private void Notice(string text, double now) { notice = text; noticeEnd = now + 1.2; }
    public void Reset(bool forgetCues = true)
    {
        followup = KickCue.Unknown; activeRush = RushCue.Unknown;
        correctionAllowed = false; hitUntil = 0; hitAt = kickPressedAt = requestedRushAt = double.NegativeInfinity; hitSawOffensive = false;
        if (forgetCues) { lastKick = KickCue.Unknown; lastConfirmedRush = latestRush = RushCue.Unknown; rushObservedAt = lastKnownRushAt = double.NegativeInfinity; }
        followupEnd = offensiveEnd = rushEnd = noticeEnd = 0;
    }
}

/// <summary>Require consecutive agreeing samples; uncertainty never becomes a confirmed cue immediately.</summary>
public sealed class StableCue<T> where T : struct, Enum
{
    private T candidate;
    private int count;
    public T Value { get; private set; }
    public double Since { get; private set; }
    public bool Push(T value, double now = 0)
    {
        if (count == 0 || !value.Equals(candidate)) { candidate = value; count = 1; Since = now; }
        else count++;
        if (count < 2) return false;
        Value = value;
        return true;
    }
}
