using System.Numerics;

namespace FuseTimer.Core;

public sealed record TextEventTemplate(int Width, int Height, byte[] Mask)
{
    public bool Valid => Width is >= 20 and <= 512 && Height is >= 6 and <= 80
        && Mask is not null && Mask.Length == Width * Height && Mask.All(value => value <= 1)
        && Mask.Count(value => value == 1) >= 40;
}

/// <summary>Matches a calibrated white phrase, without reading its XP/points prefix.</summary>
public static class TextEventDetection
{
    private static byte White(int pixel)
    {
        int r = (pixel >> 16) & 255, g = (pixel >> 8) & 255, b = pixel & 255;
        return Math.Min(r, Math.Min(g, b)) >= 140 && Math.Max(r, Math.Max(g, b)) - Math.Min(r, Math.Min(g, b)) <= 65 ? (byte)1 : (byte)0;
    }
    public static TextEventTemplate Learn(PixelGrid grid)
    {
        int left = grid.Width, right = -1, top = grid.Height, bottom = -1;
        for (int y = 0; y < grid.Height; y++) for (int x = 0; x < grid.Width; x++)
            if (White(grid.Pixels[y * grid.Width + x]) != 0)
            { left = Math.Min(left, x); right = Math.Max(right, x); top = Math.Min(top, y); bottom = Math.Max(bottom, y); }
        if (right < left) return new(0, 0, []);
        int width = right - left + 1, height = bottom - top + 1;
        var mask = new byte[width * height];
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++) mask[y * width + x] = White(grid.Pixels[(top + y) * grid.Width + left + x]);
        return new(width, height, mask);
    }
    public static TextEventTemplate Scale(TextEventTemplate source, double scaleX, double scaleY)
    {
        if (!source.Valid || !double.IsFinite(scaleX) || !double.IsFinite(scaleY) || scaleX <= 0 || scaleY <= 0) return new(0, 0, []);
        int width = (int)Math.Round(source.Width * scaleX), height = (int)Math.Round(source.Height * scaleY);
        if (width is < 20 or > 512 || height is < 6 or > 80) return new(0, 0, []);
        var mask = new byte[width * height];
        for (int y = 0; y < height; y++) for (int x = 0; x < width; x++)
            mask[y * width + x] = source.Mask[Math.Min(source.Height - 1, (int)(y / scaleY)) * source.Width + Math.Min(source.Width - 1, (int)(x / scaleX))];
        return new(width, height, mask);
    }
    public static int Count(PixelGrid grid, TextEventTemplate template)
    {
        if (!template.Valid || template.Width > grid.Width || template.Height > grid.Height) return 0;
        byte[] pixels = grid.Pixels.Select(White).ToArray();
        int stride = (grid.Width + 63) / 64 + 1, words = (template.Width + 63) / 64;
        var imageBits = new ulong[stride * grid.Height];
        var targetBits = new ulong[words * template.Height];
        for (int y = 0; y < grid.Height; y++) for (int x = 0; x < grid.Width; x++)
            if (pixels[y * grid.Width + x] != 0) imageBits[y * stride + x / 64] |= 1UL << (x % 64);
        var positives = new List<int>();
        for (int i = 0; i < template.Mask.Length; i++) if (template.Mask[i] != 0)
        { int y = i / template.Width, x = i % template.Width; targetBits[y * words + x / 64] |= 1UL << (x % 64); positives.Add(i); }
        int[] anchors = Enumerable.Range(0, 32).Select(i => positives[i * (positives.Count - 1) / 31]).ToArray();
        int count = 0, lastY = -template.Height;
        for (int y = 0; y <= grid.Height - template.Height; y++)
        {
            if (y - lastY < Math.Max(2, template.Height / 2)) continue;
            for (int x = 0; x <= grid.Width - template.Width; x++)
            {
                int misses = 0;
                foreach (int anchor in anchors)
                    if (pixels[(y + anchor / template.Width) * grid.Width + x + anchor % template.Width] == 0 && ++misses > 5) break;
                if (misses > 5) continue;
                int intersection = 0, union = 0;
                for (int ty = 0; ty < template.Height; ty++) for (int word = 0; word < words; word++)
                {
                    int offset = x + word * 64, index = (y + ty) * stride + offset / 64, shift = offset % 64;
                    ulong sample = imageBits[index] >> shift;
                    if (shift != 0) sample |= imageBits[index + 1] << (64 - shift);
                    int validBits = Math.Min(64, template.Width - word * 64);
                    if (validBits < 64) sample &= (1UL << validBits) - 1;
                    ulong target = targetBits[ty * words + word];
                    intersection += BitOperations.PopCount(sample & target); union += BitOperations.PopCount(sample | target);
                }
                if (union == 0 || intersection / (double)union < .82) continue;
                lastY = y;
                if (++count >= 8) return count;
                break; // one phrase per XP row; nearby translations are the same event
            }
        }
        return count;
    }
}

/// <summary>A newly appearing phrase after an attack, not a lingering or scrolling toast.</summary>
public sealed class SweepEventGate
{
    private readonly StableCueCount count = new();
    private double kickAt = double.NegativeInfinity;
    private bool used;
    public double EventAt { get; private set; }
    public void Kick(double now) { kickAt = now; used = false; }
    public bool Sample(int matches, double now, bool enabled)
    {
        bool increased = count.Push(matches, now);
        if (!increased || !enabled || used || count.Since < kickAt || now - kickAt > 1.5) return false;
        EventAt = count.Since;
        used = true; return true;
    }
    public void Reset() { count.Reset(); kickAt = double.NegativeInfinity; used = false; }
    private sealed class StableCueCount
    {
        private int candidate = -1, confirmed = -1, repeats;
        public double Since { get; private set; }
        public bool Push(int value, double now)
        {
            if (value != candidate) { candidate = value; repeats = 1; Since = now; return false; }
            if (++repeats < 2) return false;
            bool increase = confirmed >= 0 && value > confirmed;
            confirmed = value; return increase;
        }
        public void Reset() { candidate = confirmed = -1; repeats = 0; }
    }
}
