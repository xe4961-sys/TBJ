namespace FuseTimer.Core;

public static class PassengerDetection
{
    public static bool RedBox(PixelGrid grid)
    {
        int red = 0, left = grid.Width, right = -1, top = grid.Height, bottom = -1;
        for (int y = 0; y < grid.Height; y++) for (int x = 0; x < grid.Width; x++)
        {
            int pixel = grid.Pixels[y * grid.Width + x];
            int r = (pixel >> 16) & 255, g = (pixel >> 8) & 255, b = pixel & 255;
            if (r < 90 || r - g < 35 || r < g * 1.5 || r < b * 1.3) continue;
            red++; left = Math.Min(left, x); right = Math.Max(right, x); top = Math.Min(top, y); bottom = Math.Max(bottom, y);
        }
        double coverage = red / (double)grid.Pixels.Length;
        return coverage is >= .04 and <= .8 && right - left >= grid.Width * .5 && bottom - top >= grid.Height * .4;
    }
}

/// <summary>Optional heuristic: presence then sustained disappearance, once per supportive run.</summary>
public sealed class PassengerGate
{
    private double started, presentAt = double.NaN, absentAt = double.NaN;
    private int presentCount, absentCount;
    private bool armed, seen, used;
    public void Start(double now) { Reset(); started = now; armed = true; }
    public void MarkUsed() => used = true;
    public void Reset() { armed = seen = used = false; presentCount = absentCount = 0; presentAt = absentAt = double.NaN; }
    public bool Sample(bool red, double at, GuestFrame frame, bool enabled)
    {
        if (!armed || used || !enabled || at < started) return false;
        if (frame.Rush is not (RushPhase.SupportWindup or RushPhase.SupportSprint)) { Reset(); return false; }
        if (frame.Rush != RushPhase.SupportSprint || !frame.CarryReady) return false;
        if (frame.RushRemaining <= .3) { used = true; return false; }
        if (red)
        {
            absentCount = 0; absentAt = double.NaN;
            if (presentCount++ == 0) presentAt = at;
            if (presentCount >= 3 && at - presentAt >= .1) seen = true;
            return false;
        }
        if (!seen) { presentCount = 0; presentAt = double.NaN; return false; }
        if (absentCount++ == 0) absentAt = at;
        if (absentCount < 3 || at - absentAt < .15) return false;
        used = true; return true;
    }
}
