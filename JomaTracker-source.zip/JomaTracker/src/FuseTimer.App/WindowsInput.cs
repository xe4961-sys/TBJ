using System.Runtime.InteropServices;

namespace FuseTimer;

internal static class WindowsInput
{
    [DllImport("user32.dll")]
    private static extern short GetAsyncKeyState(int virtualKey);
    // Escape cancels capture. Left/right clicks remain available for the UI;
    // Mouse middle, Mouse 4, and Mouse 5 can be used for grenade bindings.
    public static readonly int[] CapturableKeys = [4, 5, 6, .. Enumerable.Range(8, 247).Where(key => key != 27)];
    public static readonly int[] GuestKeys = [1, 2, .. CapturableKeys];
    public static bool IsDown(int key) => (GetAsyncKeyState(key) & 0x8000) != 0;
    public static bool AnyKeyDown() => Enumerable.Range(1, 254).Any(IsDown);
    public static string Name(int key) => key switch
    {
        1 => "Mouse left", 2 => "Mouse right", 4 => "Mouse middle", 5 => "Mouse 4", 6 => "Mouse 5",
        16 or 160 or 161 => "Shift", 17 or 162 or 163 => "Ctrl", 18 or 164 or 165 => "Alt",
        32 => "Space", 13 => "Enter", 9 => "Tab",
        >= 48 and <= 57 => ((char)key).ToString(),
        >= 65 and <= 90 => ((char)key).ToString(),
        _ => ((Keys)key).ToString()
    };
}
