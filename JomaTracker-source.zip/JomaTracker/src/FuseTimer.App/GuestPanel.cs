using FuseTimer.Core;

namespace FuseTimer;

internal sealed class GuestPanel : UserControl
{
    private readonly TimerSettings settings;
    private readonly Action changed;
    private readonly GuestRuntime runtime;
    private readonly ComboBox profiles = new() { Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly ComboBox screens = new() { Width = 250, DropDownStyle = ComboBoxStyle.DropDownList };
    private readonly TextBox profileName = new() { Width = 250, MaxLength = 60 };
    private readonly Label detection, timingError, profileHint;
    private readonly PictureBox kickPreview = new() { Size = new Size(185, 48), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Black };
    private readonly PictureBox rushPreview = new() { Size = new Size(185, 48), SizeMode = PictureBoxSizeMode.Zoom, BackColor = Color.Black };
    private readonly Dictionary<string, NumericUpDown> timingFields = new();
    private CaptureResult? displayed;
    private bool loading;
    public event Action<Screen>? CalibrationRequested;
    public event Action<RushCue>? PreviewRequested;
    public GuestPanel(TimerSettings settings, GuestRuntime runtime, Action changed)
    {
        this.settings = settings; this.runtime = runtime; this.changed = changed;
        Dock = DockStyle.Fill; AutoScroll = true; BackColor = Ui.Background;
        var content = Ui.Stack(405); content.Padding = new Padding(5); Controls.Add(content);
        content.Controls.Add(Ui.Label("GUEST — RECAST WINDOWS", 390, 32));
        var tests = Ui.Row();
        tests.Controls.Add(Ui.Button("Test supportive Rush", () => PreviewRequested?.Invoke(RushCue.Supportive)));
        tests.Controls.Add(Ui.Button("Test offensive Rush", () => PreviewRequested?.Invoke(RushCue.Offensive)));
        content.Controls.Add(tests);
        content.Controls.Add(Ui.Label("Tests hide controls and show the timer without calibration.\nThey simulate input; they do not activate a move in game.", 390, 44));
        content.Controls.Add(Ui.Label("Calibrate with base Kick and Supportive Rush visible.\nOnly the selected text regions are checked; no video is saved.", 390, 45));
        content.Controls.Add(Ui.Label("Saved calibration profile", 390, 25)); content.Controls.Add(profiles);
        profileHint = Ui.Label("", 390, 40); content.Controls.Add(profileHint);
        foreach (var screen in Screen.AllScreens) screens.Items.Add($"{screen.DeviceName} · {screen.Bounds.Width}x{screen.Bounds.Height}");
        screens.SelectedIndex = Math.Max(0, Array.FindIndex(Screen.AllScreens, screen => screen.Primary));
        content.Controls.Add(Ui.Label("Monitor for calibration", 390, 25)); content.Controls.Add(screens);
        content.Controls.Add(Ui.Label("Profile name (used when saving calibration)", 390, 25)); content.Controls.Add(profileName);
        var calibration = Ui.Row();
        calibration.Controls.Add(Ui.Button("Calibrate text regions", () => CalibrationRequested?.Invoke(Screen.AllScreens[Math.Clamp(screens.SelectedIndex, 0, Screen.AllScreens.Length - 1)])));
        calibration.Controls.Add(Ui.Button("Learn Strike label", () => { runtime.ArmLearn(); UpdatePreview(); }));
        content.Controls.Add(calibration);
        content.Controls.Add(Ui.Label("Learn Strike: return to the game, roll, then press the Learn key\nwhile STRIKE is visible. This supports white or gold text.", 390, 44));
        var previews = Ui.Row(390, 53); previews.Controls.Add(kickPreview); previews.Controls.Add(rushPreview); content.Controls.Add(previews);
        detection = Ui.Label("Waiting for calibration…", 390, 75); content.Controls.Add(detection);
        content.Controls.Add(Ui.Label("Changeable binds — click, release, then press the new key.\nEscape cancels. Binds must differ from one another and Controls.", 390, 45));
        AddBind(content, "Kick / recast", () => settings.Guest.KickKey, key => settings.Guest.KickKey = key);
        AddBind(content, "Dodgeroll", () => settings.Guest.RollKey, key => settings.Guest.RollKey = key);
        AddBind(content, "Rush / Dropkick", () => settings.Guest.RushKey, key => settings.Guest.RushKey = key);
        AddBind(content, "Reset Guest windows", () => settings.Guest.ResetKey, key => settings.Guest.ResetKey = key);
        AddBind(content, "Learn Strike sample", () => settings.Guest.LearnKey, key => settings.Guest.LearnKey = key);
        content.Controls.Add(Ui.Check("Enable manual ally-pickup +2s key", settings.Guest.PickupEnabled, value =>
        {
            settings.Guest.PickupEnabled = value;
            if (!settings.Guest.BindingsValid(settings.ControlsKey)) { settings.Guest.PickupEnabled = false; MessageBox.Show("Pickup key conflicts with another bind. Change it first."); }
            changed();
        }));
        AddBind(content, "Ally pickup (+2s; support only)", () => settings.Guest.PickupKey, key => settings.Guest.PickupKey = key);
        content.Controls.Add(Ui.Check("Beep when a follow-up / Dropkick becomes ready", settings.Guest.ReadyBeeps, value => { settings.Guest.ReadyBeeps = value; changed(); }));
        var hz = Ui.Number(settings.Guest.CaptureHz, 5, 30, 0);
        hz.ValueChanged += (_, _) => { settings.Guest.CaptureHz = (int)hz.Value; changed(); };
        content.Controls.Add(Ui.Field("Detection checks per second", hz));
        content.Controls.Add(Ui.Label("Lower rates reduce capture work but delay detection.\nEarly endings are manual; reset if a wall/stun cancels a move.", 390, 45));
        content.Controls.Add(Ui.Button("Reset active Guest windows", runtime.Reset, 380));
        content.Controls.Add(Ui.Label("ADJUSTABLE TIMINGS — seconds", 390, 35));
        timingError = Ui.Label("", 390, 43); timingError.ForeColor = Color.LightSalmon;
        AddTiming(content, "Sweep window", nameof(GuestTimings.Sweep));
        AddTiming(content, "Strike window", nameof(GuestTimings.Strike));
        AddTiming(content, "Offensive Rush availability", nameof(GuestTimings.OffensiveAvailable));
        AddTiming(content, "Supportive windup", nameof(GuestTimings.SupportWindup));
        AddTiming(content, "Supportive carrying hitbox delay", nameof(GuestTimings.CarryHitbox));
        AddTiming(content, "Offensive windup", nameof(GuestTimings.OffensiveWindup));
        AddTiming(content, "Safe Dropkick delay (from Rush press)", nameof(GuestTimings.SafeDropkick));
        AddTiming(content, "Supportive sprint duration", nameof(GuestTimings.SupportSprint));
        AddTiming(content, "Offensive sprint duration", nameof(GuestTimings.OffensiveSprint));
        content.Controls.Add(timingError);
        profiles.SelectedIndexChanged += (_, _) =>
        {
            if (loading || profiles.SelectedItem is not CaptureProfile selected) return;
            settings.Guest.ActiveProfile = selected.Name; profileName.Text = selected.Name;
            int index = Array.FindIndex(Screen.AllScreens, screen => screen.DeviceName == selected.ScreenName);
            if (index >= 0) screens.SelectedIndex = index;
            UpdateHint(); changed();
        };
        ReloadProfiles();
    }
    private void AddBind(FlowLayoutPanel content, string label, Func<int> read, Action<int> write)
    {
        var button = new BindButton(read(), key =>
        {
            int previous = read(); write(key);
            bool valid = settings.Guest.BindingsValid(settings.ControlsKey);
            // Even a currently disabled pickup bind must not reuse another Guest bind.
            int[] all = [settings.Guest.KickKey, settings.Guest.RollKey, settings.Guest.RushKey, settings.Guest.ResetKey, settings.Guest.LearnKey, settings.Guest.PickupKey, settings.ControlsKey];
            valid &= all.Distinct().Count() == all.Length;
            write(previous); return valid;
        }, key => { write(key); changed(); });
        content.Controls.Add(Ui.Field(label, button));
    }
    private void AddTiming(FlowLayoutPanel content, string label, string property)
    {
        var info = typeof(GuestTimings).GetProperty(property)!;
        var field = Ui.Number((decimal)(double)info.GetValue(settings.Guest.Timings)!, .001M, 30);
        timingFields[property] = field;
        field.ValueChanged += (_, _) =>
        {
            var candidate = settings.Guest.Timings with { };
            foreach (var pair in timingFields) typeof(GuestTimings).GetProperty(pair.Key)!.SetValue(candidate, (double)pair.Value.Value);
            if (!candidate.Valid) { timingError.Text = "Not applied: safe delay must be within offensive sprint; carrying hitbox cannot precede support sprint."; return; }
            timingError.Text = ""; settings.Guest.Timings = candidate; changed();
        };
        content.Controls.Add(Ui.Field(label, field));
    }
    public void Calibrated(CaptureProfile profile)
    {
        profile.Name = string.IsNullOrWhiteSpace(profileName.Text) ? profile.Name : profileName.Text.Trim();
        settings.Guest.Profiles.RemoveAll(item => item.Name == profile.Name);
        settings.Guest.Profiles.Add(profile); settings.Guest.ActiveProfile = profile.Name;
        ReloadProfiles(); changed();
    }
    private void ReloadProfiles()
    {
        loading = true; profiles.Items.Clear();
        foreach (var profile in settings.Guest.Profiles) profiles.Items.Add(profile);
        profiles.SelectedItem = settings.Guest.Profile;
        profileName.Text = settings.Guest.Profile?.Name ?? $"{Screen.PrimaryScreen?.Bounds.Width}x{Screen.PrimaryScreen?.Bounds.Height}";
        loading = false; UpdateHint();
    }
    private void UpdateHint()
    {
        var profile = settings.Guest.Profile;
        profileHint.Text = profile is null ? "No profile yet. Calibrate while base Kick is visible." : $"{profile.ScreenWidth}x{profile.ScreenHeight} · {(profile.StrikeTemplate is null ? "Strike uses gold color; learn its label for white text." : "Strike image learned.")}";
    }
    public void UpdatePreview()
    {
        detection.Text = runtime.Status + "\n" + runtime.LastRushEvent;
        if (ReferenceEquals(displayed, runtime.Latest)) return;
        displayed = runtime.Latest;
        static void Set(PictureBox box, PixelGrid? pixels)
        { var previous = box.Image; box.Image = pixels is null ? null : ScreenCapture.Preview(pixels); previous?.Dispose(); }
        Set(kickPreview, displayed?.Kick); Set(rushPreview, displayed?.Rush); UpdateHint();
    }
    protected override void Dispose(bool disposing)
    {
        if (disposing) { kickPreview.Image?.Dispose(); rushPreview.Image?.Dispose(); }
        base.Dispose(disposing);
    }
}
