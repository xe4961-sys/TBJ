using FuseTimer.Core;

namespace FuseTimer;

internal sealed class CalibrationForm : Form
{
    private readonly Bitmap screenshot;
    private readonly Rectangle screen;
    private readonly string screenName;
    private Point start;
    private Rectangle selection;
    private Rectangle? kick;
    public CaptureProfile? Result { get; private set; }
    public CalibrationForm(Screen monitor)
    {
        screen = monitor.Bounds; screenName = monitor.DeviceName;
        screenshot = ScreenCapture.Bitmap(screen);
        AutoScaleMode = AutoScaleMode.None; FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual; Bounds = screen; TopMost = true; DoubleBuffered = true;
        Cursor = Cursors.Cross; KeyPreview = true;
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); } };
        MouseDown += (_, e) => { if (e.Button == MouseButtons.Left) { start = e.Location; selection = Rectangle.Empty; Capture = true; } };
        MouseMove += (_, e) => { if (Capture) { selection = Rectangle.FromLTRB(Math.Min(start.X, e.X), Math.Min(start.Y, e.Y), Math.Max(start.X, e.X), Math.Max(start.Y, e.Y)); Invalidate(); } };
        MouseUp += (_, e) =>
        {
            if (e.Button != MouseButtons.Left || !Capture) return;
            Capture = false;
            selection.Intersect(ClientRectangle);
            if (selection.Width < 15 || selection.Height < 8 || (long)selection.Width * selection.Height > 200000)
            { selection = Rectangle.Empty; Invalidate(); return; }
            if (kick is null) { kick = selection; selection = Rectangle.Empty; Invalidate(); return; }
            PixelGrid Read(Rectangle box)
            {
                using var crop = screenshot.Clone(box, screenshot.PixelFormat);
                // Use the frozen image, excluding this calibration overlay.
                var pixels = new int[crop.Width * crop.Height];
                for (int y = 0; y < crop.Height; y++) for (int x = 0; x < crop.Width; x++) pixels[y * crop.Width + x] = crop.GetPixel(x, y).ToArgb();
                return new(crop.Width, crop.Height, pixels);
            }
            if (CueDetection.Rush(Read(selection)) == RushCue.Unknown)
            {
                MessageBox.Show(this, "No clear green/red Rush text was found. Drag tightly around the colored SUPPORTIVE or OFFENSIVE word. Exclude the white Rush word, F icon, and card border.", "Select the colored Rush label");
                selection = Rectangle.Empty; Invalidate(); return;
            }
            byte[] mask = CueDetection.Mask(Read(kick.Value));
            if (!CueDetection.UsableTemplate(mask))
            { MessageBox.Show(this, "No readable Kick text found. Cancel and try again with base Kick visible."); DialogResult = DialogResult.Cancel; Close(); return; }
            NormalizedRegion Normalize(Rectangle box) => new(box.X / (double)screen.Width, box.Y / (double)screen.Height, box.Width / (double)screen.Width, box.Height / (double)screen.Height);
            Result = new() { Name = $"{screen.Width}x{screen.Height}", ScreenName = screenName, ScreenWidth = screen.Width, ScreenHeight = screen.Height, KickRegion = Normalize(kick.Value), RushRegion = Normalize(selection), BaseTemplate = mask };
            DialogResult = DialogResult.OK; Close();
        };
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.DrawImageUnscaled(screenshot, 0, 0);
        using var shade = new SolidBrush(Color.FromArgb(80, 0, 0, 0)); e.Graphics.FillRectangle(shade, ClientRectangle);
        using var pen = new Pen(Color.Cyan, 2);
        if (kick is not null) e.Graphics.DrawRectangle(pen, kick.Value);
        if (!selection.IsEmpty) e.Graphics.DrawRectangle(pen, selection);
        string text = kick is null ? "STEP 1: Drag tightly around the base word KICK only. Exclude the border and LMB icon."
            : "STEP 2: Drag around the colored SUPPORTIVE / OFFENSIVE word only. Exclude RUSH and F.";
        using var back = new SolidBrush(Color.FromArgb(235, 16, 27, 45));
        e.Graphics.FillRectangle(back, 15, 15, Math.Min(1000, Width - 30), 76);
        using var font = new Font("Segoe UI", 12, FontStyle.Bold);
        e.Graphics.DrawString(text + "\nEscape cancels. Small, tight boxes improve detection.", font, Brushes.White, new RectangleF(25, 24, Width - 50, 65));
    }
    protected override void Dispose(bool disposing) { if (disposing) screenshot.Dispose(); base.Dispose(disposing); }
}
