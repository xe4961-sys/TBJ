using FuseTimer.Core;

namespace FuseTimer;

internal sealed class ExtraCalibrationForm : Form
{
    private readonly Bitmap screenshot;
    private readonly bool sweep;
    private Point start;
    private Rectangle selection;
    private TextEventTemplate? learned;
    public NormalizedRegion? SelectedRegion { get; private set; }
    public TextEventTemplate? Template { get; private set; }
    public ExtraCalibrationForm(Screen monitor, bool sweep)
    {
        this.sweep = sweep; screenshot = ScreenCapture.Bitmap(monitor.Bounds);
        AutoScaleMode = AutoScaleMode.None; FormBorderStyle = FormBorderStyle.None;
        StartPosition = FormStartPosition.Manual; Bounds = monitor.Bounds; TopMost = true; DoubleBuffered = true;
        Cursor = Cursors.Cross; KeyPreview = true;
        KeyDown += (_, e) => { if (e.KeyCode == Keys.Escape) { DialogResult = DialogResult.Cancel; Close(); } };
        MouseDown += (_, e) => { if (e.Button == MouseButtons.Left) { start = e.Location; selection = Rectangle.Empty; Capture = true; } };
        MouseMove += (_, e) => { if (Capture) { selection = Rectangle.FromLTRB(Math.Min(start.X, e.X), Math.Min(start.Y, e.Y), Math.Max(start.X, e.X), Math.Max(start.Y, e.Y)); Invalidate(); } };
        MouseUp += (_, e) =>
        {
            if (e.Button != MouseButtons.Left || !Capture) return;
            Capture = false; selection.Intersect(ClientRectangle);
            if (selection.Width < 20 || selection.Height < 8 || (long)selection.Width * selection.Height > 200000)
            { MessageBox.Show(this, "Select a smaller region (at most 200,000 pixels). Escape cancels."); return; }
            var pixels = Read(selection);
            if (sweep && learned is null)
            {
                learned = TextEventDetection.Learn(pixels);
                if (!learned.Valid) { learned = null; MessageBox.Show(this, "Select only the readable white words Landed Sweep. Include both words; exclude XP/points."); return; }
                selection = Rectangle.Empty; Invalidate(); return;
            }
            if (sweep && TextEventDetection.Count(pixels, learned!) == 0)
            { MessageBox.Show(this, "The search area must contain the sampled phrase. Include the rows where XP messages appear, excluding other HUD text."); return; }
            if (!sweep && !PassengerDetection.RedBox(pixels))
            { MessageBox.Show(this, "No clear red box found. Select the visible red rectangle around the capsule. Escape cancels; try another capture during Supportive Rush."); return; }
            SelectedRegion = new(selection.X / (double)Width, selection.Y / (double)Height, selection.Width / (double)Width, selection.Height / (double)Height);
            Template = learned; DialogResult = DialogResult.OK; Close();
        };
    }
    private PixelGrid Read(Rectangle box)
    {
        var pixels = new int[box.Width * box.Height];
        for (int y = 0; y < box.Height; y++) for (int x = 0; x < box.Width; x++) pixels[y * box.Width + x] = screenshot.GetPixel(box.X + x, box.Y + y).ToArgb();
        return new(box.Width, box.Height, pixels);
    }
    protected override void OnPaint(PaintEventArgs e)
    {
        e.Graphics.DrawImageUnscaled(screenshot, 0, 0);
        using var pen = new Pen(Color.Cyan, 2);
        if (!selection.IsEmpty) e.Graphics.DrawRectangle(pen, selection);
        string instruction = !sweep ? "Drag around the red rectangular Rush hitbox. Include its sides; exclude unrelated red HUD elements."
            : learned is null ? "STEP 1: Select ONLY the white words Landed Sweep. (not XP or point numbers)."
            : "STEP 2: Select the XP message search area, including this phrase and the rows where it can move.";
        using var background = new SolidBrush(Color.FromArgb(245, 16, 27, 45));
        e.Graphics.FillRectangle(background, 15, 15, Math.Min(1100, Width - 30), 80);
        using var font = new Font("Segoe UI", 12, FontStyle.Bold);
        e.Graphics.DrawString(instruction + "\nEscape cancels. The screen is frozen; take your time.", font, Brushes.White, new RectangleF(25, 24, Width - 50, 70));
    }
    protected override void Dispose(bool disposing) { if (disposing) screenshot.Dispose(); base.Dispose(disposing); }
}
