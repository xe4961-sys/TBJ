using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Globalization;
using System.Runtime.InteropServices;
using FuseTimer.Core;

namespace FuseTimer;

/// <summary>Per-pixel alpha: only glyphs are visible, never a window rectangle.</summary>
internal sealed class TimerOverlay : Form
{
    private CountdownFrame frame = new(CountdownPhase.Ready, 3, false);
    private bool flash;
    private bool clickThrough = true;
    private long lastRender;
    private bool positionChecked;
    private bool guestMode;
    private GuestLine[] guestLines = Array.Empty<GuestLine>();
    internal string? LastError { get; private set; }

    [StructLayout(LayoutKind.Sequential)] private struct Point { public int X, Y; public Point(int x, int y) { X = x; Y = y; } }
    [StructLayout(LayoutKind.Sequential)] private struct NativeSize { public int Width, Height; public NativeSize(int w, int h) { Width = w; Height = h; } }
    [StructLayout(LayoutKind.Sequential, Pack = 1)] private struct Blend { public byte Operation, Flags, Alpha, Format; }
    [DllImport("user32.dll")] private static extern nint GetDC(nint window);
    [DllImport("user32.dll")] private static extern int ReleaseDC(nint window, nint dc);
    [DllImport("gdi32.dll")] private static extern nint CreateCompatibleDC(nint dc);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(nint dc);
    [DllImport("gdi32.dll")] private static extern nint SelectObject(nint dc, nint item);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(nint item);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool UpdateLayeredWindow(nint window, nint screen, ref Point position, ref NativeSize size, nint source, ref Point origin, uint key, ref Blend blend, uint flags);
    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")] private static extern nint GetWindowLongPtr(nint window, int index);
    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")] private static extern nint SetWindowLongPtr(nint window, int index, nint style);
    [DllImport("user32.dll")] private static extern bool ReleaseCapture();
    [DllImport("user32.dll")] private static extern nint SendMessage(nint window, uint message, nint wParam, nint lParam);

    public TimerOverlay(int? x, int? y)
    {
        Text = "Joma Tracker overlay";
        AutoScaleDimensions = new SizeF(96, 96);
        AutoScaleMode = AutoScaleMode.Dpi;
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        TopMost = true;
        ClientSize = new Size(220, 78);
        StartPosition = FormStartPosition.Manual;
        var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1024, 768);
        var desired = new Rectangle(x ?? area.Right - Width - 30, y ?? area.Top + 30, Width, Height);
        Location = Screen.AllScreens.Any(screen => screen.WorkingArea.IntersectsWith(desired))
            ? desired.Location : new System.Drawing.Point(area.Right - Width - 30, area.Top + 30);
        AccessibleName = "Fuse Timer countdown, armed/release warning, and bullseye cue";
    }
    protected override bool ShowWithoutActivation => true;
    public void SetGuestMode(bool enabled)
    {
        guestMode = enabled;
        ClientSize = enabled ? new Size(360 * DeviceDpi / 96, 205 * DeviceDpi / 96) : new Size(220 * DeviceDpi / 96, 78 * DeviceDpi / 96);
        positionChecked = false;
    }
    public void PositionAt(int? x, int? y)
    {
        var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1024, 768);
        Location = new System.Drawing.Point(x ?? area.Right - Width - 30, y ?? area.Top + 30);
        positionChecked = false;
    }
    public void PresentGuest(GuestLine[] lines, bool shouldShow)
    {
        guestLines = lines;
        if (!shouldShow) { if (Visible) Hide(); return; }
        if (!Visible) { if (RenderSurface()) Show(); }
        else RenderSurface();
    }
    protected override CreateParams CreateParams
    {
        get
        {
            var value = base.CreateParams;
            value.ExStyle |= 0x00080000 | 0x08000000 | 0x00000080; // Layered, no activate, tool window.
            if (clickThrough) value.ExStyle |= 0x00000020;
            return value;
        }
    }
    public void SetInteractive(bool interactive)
    {
        clickThrough = !interactive;
        if (!IsHandleCreated) return;
        long style = GetWindowLongPtr(Handle, -20).ToInt64();
        SetWindowLongPtr(Handle, -20, new nint(clickThrough ? style | 0x20 : style & ~0x20));
    }
    public void Present(CountdownFrame update, bool flashing, bool shouldShow)
    {
        bool phaseChanged = frame.Phase != update.Phase;
        frame = update; flash = flashing;
        if (!shouldShow) { if (Visible) Hide(); return; }
        if (!Visible)
        {
            if (RenderSurface()) Show(); // Populate alpha pixels before showing; no white-frame flash.
        }
        else if (phaseChanged || Environment.TickCount64 - lastRender >= 16) RenderSurface();
    }
    private bool RenderSurface()
    {
        nint screen = 0, memory = 0, bitmapHandle = 0, previous = 0;
        try
        {
            _ = Handle;
            if (!positionChecked)
            {
                var bounds = new Rectangle(Left, Top, Width, Height);
                if (!Screen.AllScreens.Any(screen => screen.WorkingArea.Contains(bounds)))
                {
                    var area = Screen.PrimaryScreen?.WorkingArea ?? new Rectangle(0, 0, 1024, 768);
                    Location = new System.Drawing.Point(Math.Max(area.Left, area.Right - Width - 30), area.Top + 30);
                }
                positionChecked = true;
            }
            using var bitmap = new Bitmap(Width, Height, PixelFormat.Format32bppPArgb);
            using (var graphics = Graphics.FromImage(bitmap))
            {
                graphics.Clear(Color.Transparent);
                graphics.SmoothingMode = SmoothingMode.AntiAlias;
                if (guestMode)
                {
                    for (int i = 0; i < guestLines.Length; i++)
                    {
                        string line = guestLines[i].Text;
                        float textSize = (line.Length > 32 ? 16 : 20) * DeviceDpi / 96f;
                        using var guestFont = new Font("Segoe UI", textSize, FontStyle.Bold, GraphicsUnit.Pixel);
                        using var guestFormat = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center, FormatFlags = StringFormatFlags.NoWrap };
                        using var path = new GraphicsPath();
                        path.AddString(line, guestFont.FontFamily, (int)guestFont.Style, textSize, new RectangleF(0, i * 31 * DeviceDpi / 96f, Width, 31 * DeviceDpi / 96f), guestFormat);
                        Color ink = line.Contains("WAIT") || line.Contains("CANCEL") || line.Contains("UNCONFIRMED") ? Color.FromArgb(255, 190, 135)
                            : line.Contains("READY") ? Color.FromArgb(135, 245, 197) : Color.FromArgb(207, 233, 255);
                        using var stroke = new Pen(Color.FromArgb(210, 8, 17, 28), 3) { LineJoin = LineJoin.Round };
                        using var fill = new SolidBrush(ink);
                        graphics.DrawPath(stroke, path); graphics.FillPath(fill, path);
                        if (guestLines[i].Progress is double progress)
                        {
                            float barWidth = Width - 32 * DeviceDpi / 96f;
                            float barX = 16 * DeviceDpi / 96f, barY = (i * 31 + 28) * DeviceDpi / 96f;
                            using var track = new SolidBrush(Color.FromArgb(130, 20, 35, 55));
                            graphics.FillRectangle(track, barX, barY, barWidth, 3 * DeviceDpi / 96f);
                            graphics.FillRectangle(fill, barX, barY, barWidth * (float)Math.Clamp(progress, 0, 1), 3 * DeviceDpi / 96f);
                        }
                    }
                }
                else
                {
                bool warning = frame.Phase is CountdownPhase.Armed or CountdownPhase.Release;
                double opacity = warning ? OverlayPolicy.WarningOpacity(flash, frame.WarningAge) : 1;
                string text = frame.Phase switch
                {
                    CountdownPhase.Armed => "ARMED",
                    CountdownPhase.Release => "RELEASE!",
                    CountdownPhase.Bullseye => "BULLSEYE!!",
                    _ => frame.Remaining.ToString("0.00", CultureInfo.InvariantCulture)
                };
                float size = (frame.Phase == CountdownPhase.Bullseye ? 26 : frame.Phase == CountdownPhase.Release ? 28 : warning ? 32 : 44) * DeviceDpi / 96f;
                using var font = new Font("Segoe UI", size, FontStyle.Bold, GraphicsUnit.Pixel);
                using var format = new StringFormat { Alignment = StringAlignment.Center, LineAlignment = StringAlignment.Center };
                using var glyphs = new GraphicsPath();
                glyphs.AddString(text, font.FontFamily, (int)font.Style, size, new RectangleF(0, 0, Width, Height), format);
                Color color = frame.Phase == CountdownPhase.Bullseye ? Color.FromArgb(135, 245, 197)
                    : frame.Phase == CountdownPhase.Release ? Color.FromArgb(255, 147, 115)
                    : frame.Phase == CountdownPhase.Armed ? Color.FromArgb(255, 209, 128) : Color.FromArgb(207, 233, 255);
                using var outline = new Pen(Color.FromArgb((int)(180 * opacity), 8, 17, 28), 3) { LineJoin = LineJoin.Round };
                using var brush = new SolidBrush(Color.FromArgb((int)(255 * opacity), color));
                graphics.DrawPath(outline, glyphs); graphics.FillPath(brush, glyphs);
                }
            }
            screen = GetDC(0); memory = CreateCompatibleDC(screen);
            bitmapHandle = bitmap.GetHbitmap(Color.FromArgb(0)); previous = SelectObject(memory, bitmapHandle);
            var position = new Point(Left, Top); var dimensions = new NativeSize(Width, Height); var origin = new Point(0, 0);
            var blend = new Blend { Operation = 0, Flags = 0, Alpha = 255, Format = 1 };
            bool result = UpdateLayeredWindow(Handle, screen, ref position, ref dimensions, memory, ref origin, 0, ref blend, 2);
            LastError = result ? null : $"Overlay error {Marshal.GetLastWin32Error()}";
            lastRender = Environment.TickCount64;
            return result;
        }
        catch (Exception e) when (e is System.ComponentModel.Win32Exception or ArgumentException or ExternalException)
        {
            LastError = "Overlay could not be rendered.";
            return false;
        }
        finally
        {
            if (previous != 0 && memory != 0) SelectObject(memory, previous);
            if (bitmapHandle != 0) DeleteObject(bitmapHandle);
            if (memory != 0) DeleteDC(memory);
            if (screen != 0) ReleaseDC(0, screen);
        }
    }
    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (!clickThrough && e.Button == MouseButtons.Left)
        {
            ReleaseCapture(); SendMessage(Handle, 0x00A1, 2, 0);
        }
    }
}
