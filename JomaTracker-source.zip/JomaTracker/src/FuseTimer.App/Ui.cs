namespace FuseTimer;

internal static class Ui
{
    public static readonly Color Background = Color.FromArgb(16, 27, 45), Text = Color.FromArgb(233, 244, 255), Accent = Color.FromArgb(138, 200, 255);
    public static FlowLayoutPanel Stack(int width) => new() { Width = width, AutoSize = true, FlowDirection = FlowDirection.TopDown, WrapContents = false, Margin = Padding.Empty };
    public static FlowLayoutPanel Row(int width = 390, int height = 38) => new() { Size = new Size(width, height), WrapContents = false, Margin = Padding.Empty };
    public static Label Label(string text, int width = 390, int height = 32) => new() { Text = text, Size = new Size(width, height), ForeColor = Text, TextAlign = ContentAlignment.MiddleLeft, Margin = Padding.Empty };
    public static Button Button(string text, Action action, int width = 188)
    {
        var button = new Button { Text = text, Size = new Size(width, 30), FlatStyle = FlatStyle.Flat, BackColor = Color.FromArgb(29, 52, 80), ForeColor = Text, Margin = new Padding(0, 2, 8, 2) };
        button.Click += (_, _) => action(); return button;
    }
    public static NumericUpDown Number(decimal value, decimal min, decimal max, int places = 3) => new() { Width = 95, Height = 28, Minimum = min, Maximum = max, Value = Math.Clamp(value, min, max), DecimalPlaces = places, Increment = places == 0 ? 1 : .01M, BackColor = Background, ForeColor = Text };
    public static CheckBox Check(string text, bool value, Action<bool> change, int width = 390)
    {
        var box = new CheckBox { Text = text, Checked = value, Width = width, Height = 29, ForeColor = Text, Margin = Padding.Empty };
        box.CheckedChanged += (_, _) => change(box.Checked); return box;
    }
    public static FlowLayoutPanel Field(string label, Control control)
    {
        var row = Row(); row.Controls.Add(Label(label, 270)); row.Controls.Add(control); return row;
    }
}

internal sealed class BindButton : Button
{
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 15 };
    private readonly Func<int, bool> accept;
    private readonly Action<int> save;
    private bool waitingRelease;
    private long deadline;
    private int key;
    internal bool Listening => timer.Enabled;
    public BindButton(int initial, Func<int, bool> accept, Action<int> save)
    {
        key = initial; this.accept = accept; this.save = save;
        Text = WindowsInput.Name(key); Size = new Size(115, 29);
        BackColor = Color.FromArgb(29, 52, 80); ForeColor = Ui.Text; FlatStyle = FlatStyle.Flat;
        Click += (_, _) => { Text = "Release keys…"; waitingRelease = true; deadline = Environment.TickCount64 + 15000; timer.Start(); };
        timer.Tick += (_, _) =>
        {
            if (WindowsInput.IsDown(27) || Environment.TickCount64 >= deadline) { Finish(); return; }
            if (waitingRelease) { if (!WindowsInput.AnyKeyDown()) { waitingRelease = false; Text = "Press a key…"; } return; }
            int pressed = WindowsInput.GuestKeys.FirstOrDefault(WindowsInput.IsDown);
            if (pressed == 0) return;
            if (!accept(pressed)) { Text = "Key in use"; waitingRelease = true; return; }
            key = pressed; save(key); Finish();
        };
    }
    private void Finish() { timer.Stop(); Text = WindowsInput.Name(key); }
    public void CancelCapture() => Finish();
    protected override bool ProcessCmdKey(ref Message msg, Keys keyData) => Listening || base.ProcessCmdKey(ref msg, keyData);
    protected override void Dispose(bool disposing) { if (disposing) timer.Dispose(); base.Dispose(disposing); }
}
