using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed record CaptureResult(PixelGrid? Kick, PixelGrid? Rush, KickCue KickCue, RushCue RushCue, double At, double Milliseconds, string? Error);

internal sealed class GuestRuntime
{
    private readonly TimerSettings settings;
    private GuestTracker tracker;
    private StableCue<KickCue> stableKick = new();
    private StableCue<RushCue> stableRush = new();
    private readonly PressEdge kickEdge = new(), rollEdge = new(), rushEdge = new(), resetEdge = new(), pickupEdge = new(), learnEdge = new();
    private Task<CaptureResult>? pending;
    private int generation, pendingGeneration;
    private double nextCapture, lastGoodCapture = double.NegativeInfinity;
    private bool active;
    private GuestTracker? previewTracker;
    private double previewEnd;
    public CaptureResult? Latest { get; private set; }
    public string Status { get; private set; } = "Select Guest and calibrate the ability labels.";
    public bool LearnArmed { get; private set; }
    public bool PreviewActive => previewTracker is not null;
    public string LastRushEvent { get; private set; } = "No Rush input yet. Hide controls, then press your Rush key.";
    public event Action? Learned;
    public event Action? Ready;
    public GuestFrame Current { get; private set; }
    public GuestRuntime(TimerSettings settings) { this.settings = settings; tracker = new(settings.Guest.Timings); }
    public void Changed()
    {
        generation++; tracker = new(settings.Guest.Timings); stableKick = new(); stableRush = new();
        Latest = null; lastGoodCapture = double.NegativeInfinity; nextCapture = 0;
        Current = default; LearnArmed = false; previewTracker = null;
    }
    public void Reset() { tracker.Reset(false); Current = default; }
    public void ArmLearn() { LearnArmed = true; Status = $"Return to game. While Strike is visible, press {WindowsInput.Name(settings.Guest.LearnKey)}."; }
    public void Preview(RushCue variant, double now)
    {
        previewTracker = new(settings.Guest.Timings);
        previewTracker.ObserveRush(variant, now); previewTracker.RushPressed(now);
        var t = settings.Guest.Timings;
        previewEnd = now + (variant == RushCue.Offensive ? t.OffensiveWindup + t.OffensiveSprint : t.SupportWindup + t.SupportSprint) + .3;
        LastRushEvent = "Simulated Rush input — testing overlay only.";
    }
    public void Tick(double now, bool run, bool controlsVisible, bool calibrating)
    {
        var prefs = settings.Guest;
        bool canInput = run && !controlsVisible && !calibrating && previewTracker is null;
        bool kick = kickEdge.Sample(WindowsInput.IsDown(prefs.KickKey), canInput);
        bool roll = rollEdge.Sample(WindowsInput.IsDown(prefs.RollKey), canInput);
        bool rush = rushEdge.Sample(WindowsInput.IsDown(prefs.RushKey), canInput);
        if (rush) LastRushEvent = "Rush key received — using the last confirmed indicator.";
        bool reset = resetEdge.Sample(WindowsInput.IsDown(prefs.ResetKey), canInput);
        bool pickup = pickupEdge.Sample(WindowsInput.IsDown(prefs.PickupKey), canInput && prefs.PickupEnabled);
        bool learn = learnEdge.Sample(WindowsInput.IsDown(prefs.LearnKey), canInput && LearnArmed);
        if (!run || calibrating)
        {
            if (active) { active = false; Changed(); }
            Status = calibrating ? "Detection paused during calibration / overlay positioning." : "Guest tracking paused.";
            return;
        }
        active = true;
        if (previewTracker is not null)
        {
            if (now >= previewEnd || controlsVisible) { Changed(); return; }
            var previousPreview = Current; Current = previewTracker.Frame(now);
            Status = "Rush overlay preview — no detection required. F8 exits.";
            if (prefs.ReadyBeeps && Current.Rush == RushPhase.DropkickReady && previousPreview.Rush != RushPhase.DropkickReady) Ready?.Invoke();
            return;
        }
        var profile = prefs.Profile;
        if (profile?.Valid != true)
        {
            Status = "Calibrate first: base Kick and colored Rush labels.";
            if (rush) LastRushEvent = "Rush key received, but calibration is missing.";
            return;
        }
        if (pending?.IsCompleted == true)
        {
            CaptureResult result = pending.GetAwaiter().GetResult(); pending = null;
            if (pendingGeneration == generation)
            {
                Latest = result;
                if (result.Error is null)
                {
                    lastGoodCapture = result.At;
                    if (stableKick.Push(result.KickCue, result.At)) tracker.ObserveKick(stableKick.Value, stableKick.Since);
                    if (stableRush.Push(result.RushCue, result.At))
                    {
                        tracker.ObserveRush(stableRush.Value, result.At, stableRush.Since);
                    }
                    if (!LearnArmed) Status = $"Kick: {stableKick.Value} · Rush: {stableRush.Value}\n"
                        + (stableRush.Value == RushCue.Unknown
                            ? tracker.Frame(now).Rush != RushPhase.Idle ? "Rush HUD hidden; the latched timer continues." : "Rush not confirmed: check the colored word in its crop."
                            : $"{prefs.CaptureHz} checks/s · last capture {result.Milliseconds:0.0} ms");
                }
                else Status = result.Error;
            }
        }
        if (now - lastGoodCapture > .35) tracker.ObserveRush(RushCue.Unknown, now);
        if (learn && Latest?.Kick is not null && now - Latest.At <= .35)
        {
            byte[] mask = CueDetection.Mask(Latest.Kick);
            if (CueDetection.Similarity(mask, profile.BaseTemplate) >= .85)
                Status = "That looks like base Kick. Wait for Strike, then press the Learn key again.";
            else if (CueDetection.UsableTemplate(mask))
            {
                profile.StrikeTemplate = mask; LearnArmed = false;
                generation++; tracker.Reset(); stableKick = new(); stableRush = new();
                Status = "Strike sample saved. Open controls to inspect detection."; Learned?.Invoke();
            }
            else Status = "No readable text captured. Try learning Strike again.";
        }
        if (kick) tracker.KickPressed();
        if (roll) tracker.RollPressed();
        if (rush)
        {
            double actionTime = Clock();
            tracker.RushPressed(actionTime, now);
            var selected = tracker.Frame(actionTime);
            LastRushEvent = selected.Rush == RushPhase.Idle ? selected.Notice
                : $"Rush input: {(selected.Rush == RushPhase.SupportWindup ? "supportive" : "offensive")} latched; HUD may hide.";
        }
        if (pickup) tracker.AddPickup(now);
        if (reset) Reset();
        var previous = Current;
        Current = tracker.Frame(now);
        if (!controlsVisible && prefs.ReadyBeeps && (Current.Rush == RushPhase.DropkickReady && previous.Rush != RushPhase.DropkickReady
            || Current.Followup != KickCue.Unknown && Current.Followup != previous.Followup)) Ready?.Invoke();
        if (pending is null && now >= nextCapture)
        {
            nextCapture = now + 1.0 / prefs.CaptureHz;
            var monitor = Screen.AllScreens.FirstOrDefault(screen => screen.DeviceName == profile.ScreenName);
            if (monitor is null) { Status = "Profile monitor is missing. Recalibrate on the current monitor."; return; }
            Rectangle bounds = monitor.Bounds;
            Rectangle kickBounds = ScreenCapture.Resolve(profile.KickRegion!, bounds), rushBounds = ScreenCapture.Resolve(profile.RushRegion!, bounds);
            byte[]? baseTemplate = profile.BaseTemplate, strikeTemplate = profile.StrikeTemplate;
            pendingGeneration = generation;
            pending = Task.Run(() =>
            {
                long start = Stopwatch.GetTimestamp();
                try
                {
                    var k = ScreenCapture.Read(kickBounds); var r = ScreenCapture.Read(rushBounds);
                    var kc = CueDetection.Kick(k, baseTemplate, strikeTemplate); var rc = CueDetection.Rush(r);
                    return new CaptureResult(k, r, kc, rc, Clock(), Stopwatch.GetElapsedTime(start).TotalMilliseconds, null);
                }
                catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException or InvalidOperationException)
                { return new CaptureResult(null, null, KickCue.Unknown, RushCue.Unknown, Clock(), Stopwatch.GetElapsedTime(start).TotalMilliseconds, "Capture failed. Check the monitor/profile and use windowed or borderless mode."); }
            });
        }
    }
    private static double Clock() => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
    public GuestLine[] Lines(bool preview)
    {
        var lines = GuestDisplay.Lines(Current, settings.Guest.Timings, false, preview, WindowsInput.Name(settings.ControlsKey));
        return previewTracker is null ? lines : new[] { new GuestLine("PREVIEW — SIMULATED INPUT") }.Concat(lines).Take(6).ToArray();
    }
}
