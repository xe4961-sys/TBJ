using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed record CaptureResult(PixelGrid? Kick, PixelGrid? Rush, KickCue KickCue, RushCue RushCue, double At, double Milliseconds, string? Error)
{
    public int? SweepMatches { get; init; }
    public bool? RedBox { get; init; }
    public double ExtraAt { get; init; }
    public string? ExtraError { get; init; }
}

internal sealed class GuestRuntime
{
    private readonly TimerSettings settings;
    private GuestTracker tracker;
    private StableCue<KickCue> stableKick = new();
    private StableCue<RushCue> stableRush = new();
    private readonly PressEdge kickEdge = new(), rollEdge = new(), rushEdge = new(), resetEdge = new(), pickupEdge = new(), learnEdge = new();
    private readonly FastKickEvidence fastKick = new();
    private readonly SweepEventGate sweepEvents = new();
    private readonly PassengerGate passengers = new();
    private double nextExtraCapture;
    private Task<CaptureResult>? pending;
    private int generation, pendingGeneration;
    private int captureTarget;
    private double nextCapture;
    private bool active;
    private GuestTracker? previewTracker;
    private double previewEnd;
    public CaptureResult? Latest { get; private set; }
    public string Status { get; private set; } = "Select Guest and calibrate the ability labels.";
    public bool LearnArmed { get; private set; }
    public bool PreviewActive => previewTracker is not null;
    public string ExtraStatus { get; private set; } = "Extra detectors are optional; calibrate before enabling.";
    public string ExtraPreview { get; private set; } = "No extra samples yet.";
    public string LastRushEvent { get; private set; } = "No Rush input yet. Hide controls, then press your Rush key.";
    public event Action? Learned;
    public event Action? Ready;
    public GuestFrame Current { get; private set; }
    public GuestRuntime(TimerSettings settings) { this.settings = settings; tracker = new(settings.Guest.Timings); }
    public void Changed()
    {
        generation++; tracker = new(settings.Guest.Timings); stableKick = new(); stableRush = new();
        Latest = null; nextCapture = 0;
        Current = default; LearnArmed = false; previewTracker = null;
        fastKick.Reset();
        sweepEvents.Reset(); passengers.Reset(); nextExtraCapture = 0;
        ExtraStatus = "Extra detectors reset; waiting for calibrated samples.";
        ExtraPreview = "No extra samples yet.";
    }
    public void Reset() { tracker.Reset(false); Current = default; fastKick.Reset(); sweepEvents.Reset(); passengers.Reset(); }
    public void ArmLearn() { LearnArmed = true; Status = $"Return to game. While Strike is visible, press {WindowsInput.Name(settings.Guest.LearnKey)}."; }
    public void Preview(RushCue variant, double now)
    {
        previewTracker = new(settings.Guest.Timings);
        previewTracker.ObserveRush(variant, now); previewTracker.RushPressed(now);
        var t = settings.Guest.Timings;
        previewEnd = now + (variant == RushCue.Offensive ? t.OffensiveWindup + t.OffensiveSprint : t.SupportWindup + t.SupportSprint) + .3;
        LastRushEvent = "Simulated Rush input — testing overlay only.";
    }
    public void Tick(double now, bool run, bool controlsVisible, bool calibrating)
    {
        var prefs = settings.Guest;
        bool canInput = run && !controlsVisible && !calibrating && previewTracker is null;
        bool kick = kickEdge.Sample(WindowsInput.IsDown(prefs.KickKey), canInput);
        if (kick) { fastKick.Kick(now); sweepEvents.Kick(now); nextCapture = 0; }
        if (controlsVisible) passengers.Reset();
        bool roll = rollEdge.Sample(WindowsInput.IsDown(prefs.RollKey), canInput);
        bool rush = rushEdge.Sample(WindowsInput.IsDown(prefs.RushKey), canInput);
        if (rush) LastRushEvent = "Rush key received — using the last confirmed indicator.";
        bool reset = resetEdge.Sample(WindowsInput.IsDown(prefs.ResetKey), canInput);
        bool pickup = pickupEdge.Sample(WindowsInput.IsDown(prefs.PickupKey), canInput && prefs.PickupEnabled);
        bool learn = learnEdge.Sample(WindowsInput.IsDown(prefs.LearnKey), canInput && LearnArmed);
        if (!run || calibrating)
        {
            if (active) { active = false; Changed(); }
            Status = calibrating ? "Detection paused during calibration / overlay positioning." : "Guest tracking paused.";
            return;
        }
        active = true;
        if (previewTracker is not null)
        {
            if (now >= previewEnd || controlsVisible) { Changed(); return; }
            var previousPreview = Current; Current = previewTracker.Frame(now);
            Status = "Rush overlay preview — no detection required. F8 exits.";
            if (prefs.ReadyBeeps && Current.Rush == RushPhase.DropkickReady && previousPreview.Rush != RushPhase.DropkickReady) Ready?.Invoke();
            return;
        }
        var profile = prefs.Profile;
        if (profile?.Valid != true)
        {
            Status = "Calibrate first: base Kick and colored Rush labels.";
            if (rush) LastRushEvent = "Rush key received, but calibration is missing.";
            return;
        }
        if (pending?.IsCompleted == true)
        {
            CaptureResult result = pending.GetAwaiter().GetResult(); pending = null;
            if (pendingGeneration == generation)
            {
                Latest = result;
                if (result.Error is null)
                {
                    var phaseBeforeCapture = tracker.Frame(Clock()).Rush;
                    if (stableKick.Push(result.KickCue, result.At)) tracker.ObserveKick(stableKick.Value, stableKick.Since, Clock());
                    if (stableRush.Push(result.RushCue, result.At))
                    {
                        tracker.ObserveRush(stableRush.Value, result.At, stableRush.Since, Clock());
                    }
                    // A freshly captured red Rush cue immediately after Kick
                    // can be the only visible frame before the HUD disappears.
                    // Require an actual red cue; pressing Kick is not a hit.
                    if (fastKick.Accept(result.RushCue, result.At, Clock())) tracker.ObserveRush(RushCue.Offensive, result.At, receivedAt: Clock());
                    if (result.ExtraError is not null) ExtraStatus = result.ExtraError;
                    else if (result.SweepMatches is not null || result.RedBox is not null)
                    {
                        ExtraPreview = $"XP matches: {result.SweepMatches?.ToString() ?? "—"} · Red box: {(result.RedBox is bool box ? box ? "visible" : "absent" : "—")}";
                        if (result.SweepMatches is int matches && Clock() - result.ExtraAt <= .35
                            && sweepEvents.Sample(matches, result.ExtraAt, canInput))
                        {
                            tracker.LandedSweep(sweepEvents.EventAt, Clock());
                            ExtraStatus = "Landed Sweep confirmed: Offensive window refreshed.";
                        }
                        if (result.RedBox is bool red && Clock() - result.ExtraAt <= .35
                            && passengers.Sample(red, result.ExtraAt, tracker.Frame(Clock()), canInput) && tracker.AddPickup(Clock(), true))
                            ExtraStatus = "Pickup ASSUMED from red box loss: +2s (walls can cause this).";
                    }
                    if (phaseBeforeCapture != RushPhase.OffensiveWindup && tracker.Frame(Clock()).Rush == RushPhase.OffensiveWindup)
                        LastRushEvent = "Offensive Rush confirmed after Kick; original input time kept.";
                    if (!LearnArmed) Status = $"Kick: {stableKick.Value} · Rush: {stableRush.Value}\n"
                        + (stableRush.Value == RushCue.Unknown
                            ? tracker.Frame(now).Rush != RushPhase.Idle ? "Rush HUD hidden; the latched timer continues." : "Rush not confirmed: check the colored word in its crop."
                            : $"Target {captureTarget} checks/s · last capture {result.Milliseconds:0.0} ms");
                }
                else Status = result.Error;
            }
        }
        if (learn && Latest?.Kick is not null && now - Latest.At <= .35)
        {
            byte[] mask = CueDetection.Mask(Latest.Kick);
            if (CueDetection.Similarity(mask, profile.BaseTemplate) >= .85)
                Status = "That looks like base Kick. Wait for Strike, then press the Learn key again.";
            else if (CueDetection.UsableTemplate(mask))
            {
                profile.StrikeTemplate = mask; LearnArmed = false;
                generation++; tracker.Reset(); stableKick = new(); stableRush = new();
                Status = "Strike sample saved. Open controls to inspect detection."; Learned?.Invoke();
            }
            else Status = "No readable text captured. Try learning Strike again.";
        }
        if (kick) tracker.KickPressed(now);
        if (roll) tracker.RollPressed();
        if (rush)
        {
            bool wasIdle = tracker.Frame(Clock()).Rush == RushPhase.Idle;
            if (tracker.Frame(Clock()).Rush == RushPhase.Idle) QuickRushCheck(profile);
            double actionTime = Clock();
            tracker.RushPressed(actionTime, now);
            var selected = tracker.Frame(actionTime);
            LastRushEvent = selected.Rush == RushPhase.Idle ? selected.Notice
                : $"Rush input: {(selected.Rush == RushPhase.SupportWindup ? "supportive" : "offensive")} latched; HUD may hide.";
            if (wasIdle && selected.Rush == RushPhase.SupportWindup) passengers.Start(now);
            else passengers.Reset();
        }
        if (pickup && tracker.AddPickup(now)) passengers.MarkUsed();
        if (reset) Reset();
        var previous = Current;
        Current = tracker.Frame(now);
        if (!controlsVisible && prefs.ReadyBeeps && (Current.Rush == RushPhase.DropkickReady && previous.Rush != RushPhase.DropkickReady
            || Current.Followup != KickCue.Unknown && Current.Followup != previous.Followup)) Ready?.Invoke();
        if (pending is null && now >= nextCapture)
        {
            int hz = prefs.FastKickSampling && fastKick.IsBurst(now) ? Math.Max(prefs.CaptureHz, 60) : prefs.CaptureHz;
            captureTarget = hz;
            nextCapture += 1.0 / hz;
            if (nextCapture <= now) nextCapture = now + 1.0 / hz;
            var monitor = Screen.AllScreens.FirstOrDefault(screen => screen.DeviceName == profile.ScreenName);
            if (monitor is null) { Status = "Profile monitor is missing. Recalibrate on the current monitor."; return; }
            Rectangle bounds = monitor.Bounds;
            Rectangle kickBounds = ScreenCapture.Resolve(profile.KickRegion!, bounds), rushBounds = ScreenCapture.Resolve(profile.RushRegion!, bounds);
            byte[]? baseTemplate = profile.BaseTemplate, strikeTemplate = profile.StrikeTemplate;
            Rectangle? sweepBounds = null, passengerBounds = null;
            TextEventTemplate? sweepTemplate = null;
            if (now >= nextExtraCapture)
            {
                nextExtraCapture = now + .1; // extra regions never participate in the 60/s burst
                if (prefs.SweepEventEnabled && profile.SweepEventRegion?.Valid == true && profile.SweepEventTemplate?.Valid == true)
                {
                    sweepBounds = ScreenCapture.Resolve(profile.SweepEventRegion, bounds);
                    sweepTemplate = TextEventDetection.Scale(profile.SweepEventTemplate,
                        bounds.Width / (double)profile.ScreenWidth, bounds.Height / (double)profile.ScreenHeight);
                }
                if (prefs.PassengerEnabled && !controlsVisible && Current.Rush == RushPhase.SupportSprint && Current.CarryReady && profile.PassengerRegion?.Valid == true)
                    passengerBounds = ScreenCapture.Resolve(profile.PassengerRegion, bounds);
            }
            pendingGeneration = generation;
            pending = Task.Run(() =>
            {
                long start = Stopwatch.GetTimestamp();
                try
                {
                    var k = ScreenCapture.Read(kickBounds); var r = ScreenCapture.Read(rushBounds);
                    var kc = CueDetection.Kick(k, baseTemplate, strikeTemplate); var rc = CueDetection.Rush(r);
                    double cueAt = Clock(), extraAt = cueAt;
                    int? matches = null; bool? red = null; string? extraError = null;
                    try
                    {
                        if (sweepBounds is Rectangle sb && sweepTemplate?.Valid == true) matches = TextEventDetection.Count(ScreenCapture.Read(sb), sweepTemplate);
                        if (passengerBounds is Rectangle pb) red = PassengerDetection.RedBox(ScreenCapture.Read(pb));
                        extraAt = Clock();
                    }
                    catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException or InvalidOperationException)
                    { extraError = "Extra capture failed; check the extra regions. Main ability detection continues."; }
                    return new CaptureResult(k, r, kc, rc, cueAt, Stopwatch.GetElapsedTime(start).TotalMilliseconds, null)
                    { SweepMatches = matches, RedBox = red, ExtraAt = extraAt, ExtraError = extraError };
                }
                catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException or InvalidOperationException)
                { return new CaptureResult(null, null, KickCue.Unknown, RushCue.Unknown, Clock(), Stopwatch.GetElapsedTime(start).TotalMilliseconds, "Capture failed. Check the monitor/profile and use windowed or borderless mode."); }
            });
        }
    }
    private static double Clock() => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
    private void QuickRushCheck(CaptureProfile profile)
    {
        // One input-triggered sample complements periodic checks. If the HUD
        // has already vanished, leave the last confirmed evidence untouched.
        try
        {
            var monitor = Screen.AllScreens.FirstOrDefault(item => item.DeviceName == profile.ScreenName);
            if (monitor is null) return;
            var pixels = ScreenCapture.Read(ScreenCapture.Resolve(profile.RushRegion!, monitor.Bounds));
            double at = Clock();
            if (fastKick.Accept(CueDetection.Rush(pixels), at, at)) tracker.ObserveRush(RushCue.Offensive, at);
        }
        catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException or InvalidOperationException)
        { /* Normal async capture and existing confirmed cues remain available. */ }
    }
    public GuestLine[] Lines(bool preview)
    {
        var lines = GuestDisplay.Lines(Current, settings.Guest.Timings, false, preview, WindowsInput.Name(settings.ControlsKey), settings.CompactDisplay);
        if (previewTracker is null) return lines;
        if (settings.CompactDisplay) return lines.Select((line, index) => index == 0 ? line with { Text = "TEST | " + line.Text } : line).ToArray();
        return new[] { new GuestLine("PREVIEW — SIMULATED INPUT") }.Concat(lines).Take(6).ToArray();
    }
}
