using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed record GuestLine(string Text, double? Progress = null);

internal sealed record CaptureResult(PixelGrid? Kick, PixelGrid? Rush, KickCue KickCue, RushCue RushCue, double At, double Milliseconds, string? Error);

internal sealed class GuestRuntime
{
    private readonly TimerSettings settings;
    private GuestTracker tracker;
    private StableCue<KickCue> stableKick = new();
    private StableCue<RushCue> stableRush = new();
    private readonly PressEdge kickEdge = new(), rollEdge = new(), rushEdge = new(), resetEdge = new(), pickupEdge = new(), learnEdge = new();
    private Task<CaptureResult>? pending;
    private int generation, pendingGeneration;
    private double nextCapture, lastGoodCapture = double.NegativeInfinity;
    private double rushConfirmedAt = double.NegativeInfinity;
    private bool active;
    private double? rushInput;
    public CaptureResult? Latest { get; private set; }
    public string Status { get; private set; } = "Select Guest and calibrate the ability labels.";
    public bool LearnArmed { get; private set; }
    public event Action? Learned;
    public event Action? Ready;
    public GuestFrame Current { get; private set; }
    public GuestRuntime(TimerSettings settings) { this.settings = settings; tracker = new(settings.Guest.Timings); }
    public void Changed()
    {
        generation++; tracker = new(settings.Guest.Timings); stableKick = new(); stableRush = new();
        Latest = null; lastGoodCapture = rushConfirmedAt = double.NegativeInfinity; nextCapture = 0;
        Current = default; LearnArmed = false; rushInput = null;
    }
    public void Reset() { tracker.Reset(false); Current = default; rushInput = null; }
    public void ArmLearn() { LearnArmed = true; Status = $"Return to game. While Strike is visible, press {WindowsInput.Name(settings.Guest.LearnKey)}."; }
    public void Tick(double now, bool run, bool controlsVisible, bool calibrating)
    {
        var prefs = settings.Guest;
        bool canInput = run && !controlsVisible && !calibrating;
        bool kick = kickEdge.Sample(WindowsInput.IsDown(prefs.KickKey), canInput);
        bool roll = rollEdge.Sample(WindowsInput.IsDown(prefs.RollKey), canInput);
        bool rush = rushEdge.Sample(WindowsInput.IsDown(prefs.RushKey), canInput);
        bool reset = resetEdge.Sample(WindowsInput.IsDown(prefs.ResetKey), canInput);
        bool pickup = pickupEdge.Sample(WindowsInput.IsDown(prefs.PickupKey), canInput && prefs.PickupEnabled);
        bool learn = learnEdge.Sample(WindowsInput.IsDown(prefs.LearnKey), canInput && LearnArmed);
        if (!run || calibrating)
        {
            if (active) { active = false; Changed(); }
            Status = calibrating ? "Calibrating…" : "Guest tracking paused.";
            return;
        }
        active = true;
        var profile = prefs.Profile;
        if (profile?.Valid != true) { Status = "Calibrate first: base Kick and colored Rush labels."; return; }
        if (pending?.IsCompleted == true)
        {
            CaptureResult result = pending.GetAwaiter().GetResult(); pending = null;
            if (pendingGeneration == generation)
            {
                Latest = result;
                if (result.Error is null)
                {
                    lastGoodCapture = result.At;
                    if (stableKick.Push(result.KickCue, result.At)) tracker.ObserveKick(stableKick.Value, stableKick.Since);
                    if (stableRush.Push(result.RushCue, result.At))
                    {
                        tracker.ObserveRush(stableRush.Value, result.At, stableRush.Since);
                        if (stableRush.Value != RushCue.Unknown) rushConfirmedAt = result.At;
                    }
                    if (!LearnArmed) Status = $"Kick: {stableKick.Value} · Rush: {stableRush.Value}\n{prefs.CaptureHz} checks/s · last capture {result.Milliseconds:0.0} ms";
                }
                else Status = result.Error;
            }
        }
        if (now - lastGoodCapture > .35) tracker.ObserveRush(RushCue.Unknown, now);
        if (learn && Latest?.Kick is not null && now - Latest.At <= .35)
        {
            byte[] mask = CueDetection.Mask(Latest.Kick);
            if (CueDetection.Similarity(mask, profile.BaseTemplate) >= .85)
                Status = "That looks like base Kick. Wait for Strike, then press the Learn key again.";
            else if (CueDetection.UsableTemplate(mask))
            {
                profile.StrikeTemplate = mask; LearnArmed = false;
                generation++; tracker.Reset(); stableKick = new(); stableRush = new();
                Status = "Strike sample saved. Open controls to inspect detection."; Learned?.Invoke();
            }
            else Status = "No readable text captured. Try learning Strike again.";
        }
        if (kick) tracker.KickPressed();
        if (roll) tracker.RollPressed();
        if (rush)
        {
            if (rushInput is not null) { rushInput = null; tracker.CancelRush(now); }
            else if (tracker.Frame(now).Rush != RushPhase.Idle) tracker.RushPressed(now);
            else rushInput = now;
        }
        // Let the color detector catch up to a kick that landed just before F.
        // Timings remain anchored to the original key press, not the later sample.
        if (rushInput is double input && (rushConfirmedAt >= input + Math.Clamp(2.5 / prefs.CaptureHz, .10, .50) || now - input >= .50))
        { tracker.RushPressed(now, input); rushInput = null; }
        if (pickup) tracker.AddPickup(now);
        if (reset) Reset();
        var previous = Current;
        Current = tracker.Frame(now);
        if (!controlsVisible && prefs.ReadyBeeps && (Current.Rush == RushPhase.DropkickReady && previous.Rush != RushPhase.DropkickReady
            || Current.Followup != KickCue.Unknown && Current.Followup != previous.Followup)) Ready?.Invoke();
        if (pending is null && now >= nextCapture)
        {
            nextCapture = now + 1.0 / prefs.CaptureHz;
            var monitor = Screen.AllScreens.FirstOrDefault(screen => screen.DeviceName == profile.ScreenName);
            if (monitor is null) { Status = "Profile monitor is missing. Recalibrate on the current monitor."; return; }
            Rectangle bounds = monitor.Bounds;
            Rectangle kickBounds = ScreenCapture.Resolve(profile.KickRegion!, bounds), rushBounds = ScreenCapture.Resolve(profile.RushRegion!, bounds);
            byte[]? baseTemplate = profile.BaseTemplate, strikeTemplate = profile.StrikeTemplate;
            pendingGeneration = generation;
            pending = Task.Run(() =>
            {
                long start = Stopwatch.GetTimestamp();
                try
                {
                    var k = ScreenCapture.Read(kickBounds); var r = ScreenCapture.Read(rushBounds);
                    var kc = CueDetection.Kick(k, baseTemplate, strikeTemplate); var rc = CueDetection.Rush(r);
                    return new CaptureResult(k, r, kc, rc, Clock(), Stopwatch.GetElapsedTime(start).TotalMilliseconds, null);
                }
                catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException or InvalidOperationException)
                { return new CaptureResult(null, null, KickCue.Unknown, RushCue.Unknown, Clock(), Stopwatch.GetElapsedTime(start).TotalMilliseconds, "Capture failed. Check the monitor/profile and use windowed or borderless mode."); }
            });
        }
    }
    private static double Clock() => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;
    public GuestLine[] Lines(bool preview)
    {
        var f = Current;
        var t = settings.Guest.Timings;
        var lines = new List<GuestLine>();
        void Add(string text, double? progress = null) => lines.Add(new(text, progress is double value ? Math.Clamp(value, 0, 1) : null));
        if (rushInput is not null) Add("RUSH — CHECKING INDICATOR");
        if (f.Followup != KickCue.Unknown) Add($"{f.Followup.ToString().ToUpperInvariant()} READY  {f.FollowupRemaining:0.00}s", f.FollowupRemaining / (f.Followup == KickCue.Sweep ? t.Sweep : t.Strike));
        if (f.OffensiveRemaining > 0) Add($"OFFENSIVE AVAILABLE  {f.OffensiveRemaining:0.00}s", f.OffensiveRemaining / t.OffensiveAvailable);
        switch (f.Rush)
        {
            case RushPhase.SupportWindup: Add($"SUPPORT WINDUP  {f.RushRemaining:0.00}s", f.RushRemaining / f.RushTotal); break;
            case RushPhase.SupportSprint: Add($"SUPPORT RUSH  {f.RushRemaining:0.00}s", f.RushRemaining / f.RushTotal); if (!f.CarryReady) Add("CARRY HITBOX STARTING"); break;
            case RushPhase.OffensiveWindup: Add($"OFFENSIVE WINDUP  {f.RushRemaining:0.00}s", f.RushRemaining / f.RushTotal); Add($"WAIT — RECAST CANCELS  {f.SafeRemaining:0.00}s", f.SafeRemaining / t.SafeDropkick); break;
            case RushPhase.RecastWait: Add($"WAIT — RECAST CANCELS  {f.SafeRemaining:0.00}s", f.SafeRemaining / f.RushTotal); break;
            case RushPhase.DropkickReady: Add($"DROPKICK READY  {f.RushRemaining:0.00}s", f.RushRemaining / f.RushTotal); break;
        }
        if (!string.IsNullOrEmpty(f.Notice)) Add(f.Notice);
        if (lines.Count == 0 && preview) { Add("GUEST — WAITING FOR CUES"); Add("SWEEP / STRIKE / RUSH"); Add($"{WindowsInput.Name(settings.ControlsKey)} opens controls"); }
        return lines.Take(5).ToArray();
    }
}
