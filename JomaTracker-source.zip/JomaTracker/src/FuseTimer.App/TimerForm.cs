using System.Diagnostics;
using FuseTimer.Core;

namespace FuseTimer;

internal sealed class TimerForm : Form
{
    private readonly TimerSettings settings;
    private readonly Countdown countdown = new();
    private readonly PressEdge grenadeEdge = new(), controlsEdge = new();
    private readonly System.Windows.Forms.Timer poll = new() { Interval = 10 };
    private readonly TimerOverlay overlay;
    private readonly GuestRuntime guest;
    private readonly GuestPanel guestPanel;
    private readonly TabControl modes;
    private readonly Label status, audioStatus;
    private readonly NotifyIcon tray;
    private readonly ContextMenuStrip menu;
    private readonly ToolStripMenuItem trayEnabled, traySound;
    private readonly CheckBox enabled, sound;
    private readonly Button position;
    private Sounds sounds;
    private CountdownFrame frame;
    private bool positioning, exitRequested, calibrating;
    private bool overlayBlocked;
    private string layoutNotice = "";
    private double layoutNoticeEnd;
    private Rectangle? checkedBounds;
    private double nextDisplay;
    private static double Now => Stopwatch.GetTimestamp() / (double)Stopwatch.Frequency;

    public TimerForm(TimerSettings initial)
    {
        settings = initial;
        settings.Guest.Normalize(settings.ControlsKey);
        trayEnabled = new ToolStripMenuItem("Tracking enabled") { Checked = settings.Enabled };
        traySound = new ToolStripMenuItem("Sound on") { Checked = settings.Sound };
        audioStatus = Ui.Label("", 410, 43);
        overlay = new(settings.OverlayX, settings.OverlayY);
        sounds = new(settings.Volume) { Muted = !settings.Sound };
        guest = new(settings);
        countdown.Reset(settings.Duration); frame = countdown.Advance(Now);
        Text = "Joma Tracker — Wrecker / Guest";
        Font = new Font("Segoe UI", 9); BackColor = Ui.Background; ForeColor = Ui.Text;
        AutoScaleDimensions = new SizeF(96, 96); AutoScaleMode = AutoScaleMode.Dpi;
        ClientSize = new Size(460, 850); MinimumSize = new Size(460, 650);
        StartPosition = FormStartPosition.CenterScreen; MaximizeBox = false; ShowInTaskbar = false;
        Icon = Icon.ExtractAssociatedIcon(Environment.ProcessPath!) ?? SystemIcons.Application;
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 4, Padding = new Padding(16, 8, 16, 8) };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 33)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 43));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); root.RowStyles.Add(new RowStyle(SizeType.Absolute, 290));
        Controls.Add(root);
        var title = Ui.Label("JOMA TRACKER  /  2.0.2", 425, 32); title.ForeColor = Ui.Accent; root.Controls.Add(title, 0, 0);
        status = Ui.Label("", 425, 43); root.Controls.Add(status, 0, 1);
        modes = new TabControl { Dock = DockStyle.Fill };
        var wrecker = new TabPage("Wrecker") { BackColor = Ui.Background, AutoScroll = true };
        var guestTab = new TabPage("Guest") { BackColor = Ui.Background };
        modes.TabPages.Add(wrecker); modes.TabPages.Add(guestTab);
        modes.SelectedIndex = settings.Mode == TrackerMode.Guest ? 1 : 0;
        root.Controls.Add(modes, 0, 2);
        var wreckerContent = Ui.Stack(400); wreckerContent.Padding = new Padding(6); wrecker.Controls.Add(wreckerContent);
        wreckerContent.Controls.Add(Ui.Label("WRECKER — GRENADE TIMER"));
        var grenadeBind = new BindButton(settings.KeyCode, key => key != settings.ControlsKey, key => { settings.KeyCode = key; Save(); });
        wreckerContent.Controls.Add(Ui.Field("Grenade key", grenadeBind));
        var duration = Ui.Number((decimal)settings.Duration, .5M, 15, 2);
        duration.ValueChanged += (_, _) => { settings.Duration = (double)duration.Value; ResetWrecker(); Save(); };
        wreckerContent.Controls.Add(Ui.Field("Seconds until ARMED", duration));
        var actions = Ui.Row(); actions.Controls.Add(Ui.Button("Start / restart", StartWrecker)); actions.Controls.Add(Ui.Button("Cancel", ResetWrecker));
        wreckerContent.Controls.Add(actions);
        wreckerContent.Controls.Add(Ui.Label("0–3.00s: countdown with accelerating beeps\n3.00–3.20s: ARMED\n3.20–3.70s: RELEASE!\n3.70–4.00s: BULLSEYE!!\nChanging the countdown shifts all later phases.", 390, 120));
        guestPanel = new(settings, guest, GuestChanged); guestTab.Controls.Add(guestPanel);
        guestPanel.CalibrationRequested += Calibrate;
        guestPanel.PreviewRequested += variant => { guest.Preview(variant, Now); HideControls(); };
        guest.Learned += Save;
        guest.Ready += () => sounds.PlayTick(true);
        var common = Ui.Stack(425); common.Dock = DockStyle.Fill; root.Controls.Add(common, 0, 3);
        var toggles = Ui.Row(425, 31);
        enabled = Ui.Check("Tracking enabled", settings.Enabled, value =>
        {
            settings.Enabled = value; if (!value) { ResetWrecker(); guest.Changed(); } Save();
        }, 205);
        sound = Ui.Check("Sound on", settings.Sound, value =>
        {
            settings.Sound = value; sounds.Muted = !value; if (!value) sounds.Stop(); traySound.Checked = value; Save(); UpdateAudio();
        }, 185);
        toggles.Controls.Add(enabled); toggles.Controls.Add(sound); common.Controls.Add(toggles);
        var volume = Ui.Number(settings.Volume, 0, 100, 0);
        volume.ValueChanged += (_, _) => { settings.Volume = (int)volume.Value; sounds.Dispose(); sounds = new(settings.Volume) { Muted = !settings.Sound }; Save(); UpdateAudio(); };
        common.Controls.Add(Ui.Field("Volume (all modes)", volume));
        var audio = Ui.Row(425);
        audio.Controls.Add(Ui.Button("Test sound", () =>
        { ResetWrecker(); sounds.Dispose(); sounds = new(settings.Volume) { Muted = !settings.Sound }; sounds.PlayTest(); UpdateAudio(true); }));
        audio.Controls.Add(Ui.Button("Windows mixer", () =>
        {
            try { Process.Start(new ProcessStartInfo("ms-settings:apps-volume") { UseShellExecute = true }); }
            catch (Exception e) when (e is System.ComponentModel.Win32Exception or InvalidOperationException) { audioStatus.Text = "Open Windows Settings → System → Sound → Volume mixer."; }
        })); common.Controls.Add(audio);
        common.Controls.Add(audioStatus);
        var controlsBind = new BindButton(settings.ControlsKey, key =>
        {
            if (!WindowsInput.CapturableKeys.Contains(key) || key == settings.KeyCode) return false;
            return settings.Guest.BindingsValid(key);
        }, key => { settings.ControlsKey = key; controlsEdge.Synchronize(true); Save(); });
        common.Controls.Add(Ui.Field("Show / hide controls", controlsBind));
        var visibility = Ui.Row(425, 30);
        visibility.Controls.Add(Ui.Check("Hide idle overlay", settings.OnlyWhilePrimed, value => { settings.OnlyWhilePrimed = value; Save(); }, 190));
        visibility.Controls.Add(Ui.Check("Wrecker text pulse", settings.FlashWarnings, value => { settings.FlashWarnings = value; Save(); }, 205)); common.Controls.Add(visibility);
        var overlayRow = Ui.Row(425);
        position = Ui.Button("Position overlay", TogglePosition);
        overlayRow.Controls.Add(position); overlayRow.Controls.Add(Ui.Button("Hide controls", HideControls)); common.Controls.Add(overlayRow);
        common.Controls.Add(Ui.Button("Exit app", ExitApp, 385));

        menu = new ContextMenuStrip(); menu.Items.Add("Show controls", null, (_, _) => OpenControls());
        menu.Items.Add("Wrecker mode", null, (_, _) => modes.SelectedIndex = 0);
        menu.Items.Add("Guest mode", null, (_, _) => modes.SelectedIndex = 1);
        trayEnabled.Click += (_, _) => enabled.Checked = !enabled.Checked;
        traySound.Click += (_, _) => sound.Checked = !sound.Checked;
        menu.Items.Add(trayEnabled); menu.Items.Add(traySound); menu.Items.Add("Exit", null, (_, _) => ExitApp());
        tray = new() { Text = "Joma Tracker", Icon = Icon, ContextMenuStrip = menu, Visible = true }; tray.DoubleClick += (_, _) => OpenControls();
        ApplyOverlayMode();
        modes.SelectedIndexChanged += (_, _) =>
        {
            SavePosition(); settings.Mode = modes.SelectedIndex == 1 ? TrackerMode.Guest : TrackerMode.Wrecker;
            ResetWrecker(); guest.Changed(); sounds.Stop(); positioning = false; position.Text = "Position overlay";
            overlay.SetInteractive(false); ApplyOverlayMode(); Save();
        };
        Resize += (_, _) => { if (WindowState == FormWindowState.Minimized) HideControls(); };
        FormClosing += (_, e) => { if (!exitRequested && e.CloseReason == CloseReason.UserClosing) { e.Cancel = true; HideControls(); } };
        FormClosed += (_, _) => { poll.Stop(); poll.Dispose(); SavePosition(); SettingsStore.Save(settings); overlay.Dispose(); tray.Visible = false; tray.Dispose(); menu.Dispose(); sounds.Dispose(); };
        controlsEdge.Synchronize(WindowsInput.IsDown(settings.ControlsKey)); grenadeEdge.Synchronize(WindowsInput.IsDown(settings.KeyCode));
        UpdateAudio(); UpdateStatus(); poll.Tick += (_, _) => Tick(); poll.Start();
    }
    private void GuestChanged() { guest.Changed(); KeepOverlayClear(); Save(); }
    private void TogglePosition()
    {
        positioning = !positioning; position.Text = positioning ? "Done positioning" : "Position overlay";
        if (positioning) { ResetWrecker(); guest.Reset(); }
        overlay.SetInteractive(positioning); if (!positioning) { KeepOverlayClear(); Save(); }
    }
    private void ApplyOverlayMode()
    {
        bool isGuest = settings.Mode == TrackerMode.Guest;
        overlay.SetGuestMode(isGuest);
        overlay.PositionAt(isGuest ? settings.GuestOverlayX : settings.OverlayX, isGuest ? settings.GuestOverlayY : settings.OverlayY);
        checkedBounds = null; KeepOverlayClear();
    }
    private void KeepOverlayClear()
    {
        overlayBlocked = false;
        if (settings.Mode != TrackerMode.Guest || settings.Guest.Profile is not { Valid: true } profile) return;
        var monitor = Screen.AllScreens.FirstOrDefault(item => item.DeviceName == profile.ScreenName);
        if (monitor is null) return;
        Rectangle[] labels = [ScreenCapture.Resolve(profile.KickRegion!, monitor.Bounds), ScreenCapture.Resolve(profile.RushRegion!, monitor.Bounds)];
        var clear = OverlayPlacement.ClearOfLabels(overlay.Bounds, Screen.FromRectangle(overlay.Bounds).WorkingArea, labels);
        if (clear is null) { overlayBlocked = true; return; }
        if (clear.Value.Location != overlay.Location)
        {
            overlay.Location = clear.Value.Location;
            layoutNotice = "Overlay moved clear of the ability labels to avoid reading its own text.";
            layoutNoticeEnd = Now + 5;
        }
        checkedBounds = overlay.Bounds;
    }
    private void SavePosition()
    {
        if (settings.Mode == TrackerMode.Guest) { settings.GuestOverlayX = overlay.Left; settings.GuestOverlayY = overlay.Top; }
        else { settings.OverlayX = overlay.Left; settings.OverlayY = overlay.Top; }
    }
    private void Save()
    {
        SavePosition();
        if (!SettingsStore.Save(settings)) status.Text = "Settings could not save; this session still works.";
    }
    private void StartWrecker()
    {
        countdown.Start(Now, settings.Duration); sounds.Stop(); frame = countdown.Advance(Now);
        if (frame.Tick) sounds.PlayTick(false);
    }
    private void ResetWrecker() { countdown.Reset(settings.Duration); sounds.Stop(); frame = countdown.Advance(Now); }
    private void OpenControls()
    {
        ShowInTaskbar = true; WindowState = FormWindowState.Normal;
        var area = Screen.FromPoint(Location).WorkingArea;
        MinimumSize = new Size(460, Math.Min(650, area.Height - 30)); Height = Math.Min(Height, area.Height - 30);
        Show(); Activate();
    }
    private void HideControls()
    {
        static void Cancel(Control parent) { foreach (Control child in parent.Controls) { if (child is BindButton bind) bind.CancelCapture(); Cancel(child); } }
        Cancel(this); positioning = false; position.Text = "Position overlay"; overlay.SetInteractive(false);
        KeepOverlayClear(); Hide(); ShowInTaskbar = false; Save();
    }
    private async void Calibrate(Screen screen)
    {
        if (calibrating) return;
        calibrating = true; overlay.Hide(); HideControls();
        try
        {
            await Task.Delay(350);
            if (IsDisposed || exitRequested) return;
            using var picker = new CalibrationForm(screen);
            if (picker.ShowDialog() == DialogResult.OK && picker.Result is not null) guestPanel.Calibrated(picker.Result);
        }
        catch (Exception e) when (e is ArgumentException or System.ComponentModel.Win32Exception or System.Runtime.InteropServices.ExternalException)
        { MessageBox.Show("Could not capture the monitor. Try borderless/windowed mode and calibrate again.", "Joma Tracker"); }
        finally { calibrating = false; if (!IsDisposed && !exitRequested) OpenControls(); }
    }
    private void ExitApp() { exitRequested = true; _ = Handle; Close(); }
    private void UpdateAudio(bool testing = false)
    {
        audioStatus.Text = !settings.Sound ? "Sound muted." : settings.Volume == 0 ? "Volume is 0."
            : sounds.LastError ?? (testing ? "Test sent to Windows. If silent, check mixer/output device." : "Audio: default Windows output device.");
    }
    private void UpdateStatus()
    {
        trayEnabled.Checked = settings.Enabled;
        tray.Text = $"Joma Tracker · {settings.Mode} · {WindowsInput.Name(settings.ControlsKey)} controls";
        status.Text = overlayBlocked ? "Overlay covers the detection labels. Move it clear."
            : Now < layoutNoticeEnd ? layoutNotice
            : overlay.LastError ?? (settings.Mode == TrackerMode.Guest ? guest.Status : $"Wrecker · {WindowsInput.Name(settings.KeyCode)} primes · {WindowsInput.Name(settings.ControlsKey)} controls");
    }
    private void Tick()
    {
        double now = Now;
        // Inputs are observed, never blocked, synthesized, or retained.
        static bool Listening(Control parent) => parent.Controls.Cast<Control>().Any(child => child is BindButton bind && bind.Listening || Listening(child));
        bool controls = controlsEdge.Sample(WindowsInput.IsDown(settings.ControlsKey), !calibrating && (!Visible || !Listening(this)));
        if (controls) { if (Visible) HideControls(); else OpenControls(); }
        bool grenade = grenadeEdge.Sample(WindowsInput.IsDown(settings.KeyCode), settings.Mode == TrackerMode.Wrecker && settings.Enabled && !Visible && !calibrating);
        if (grenade) StartWrecker();
        if (settings.Mode == TrackerMode.Guest && !positioning && !calibrating && checkedBounds != overlay.Bounds) KeepOverlayClear();
        guest.Tick(now, settings.Mode == TrackerMode.Guest && (settings.Enabled || guest.PreviewActive), Visible, calibrating || positioning || overlayBlocked);
        if (settings.Mode == TrackerMode.Wrecker)
        {
            var previous = frame.Phase; frame = countdown.Advance(now);
            if (frame.Tick) sounds.PlayTick(frame.Phase is CountdownPhase.Armed or CountdownPhase.Release || frame.Remaining <= 1);
            if (previous != frame.Phase && frame.Phase is CountdownPhase.Bullseye or CountdownPhase.Complete) sounds.Stop();
            if (!calibrating) overlay.Present(frame, settings.FlashWarnings, OverlayPolicy.Visible(frame.Phase, settings.OnlyWhilePrimed, positioning));
        }
        else if (!calibrating && now >= nextDisplay)
        {
            nextDisplay = now + 1.0 / 30;
            GuestLine[] lines = guest.Lines(positioning || !settings.OnlyWhilePrimed);
            overlay.PresentGuest(lines, positioning || lines.Length > 0);
        }
        if (Visible && now >= nextDisplayStatus)
        { nextDisplayStatus = now + .15; guestPanel.UpdatePreview(); UpdateStatus(); if (sounds.LastError is not null) UpdateAudio(); }
    }
    private double nextDisplayStatus;
}
