using FuseTimer.Core;

namespace FuseTimer;

public enum TrackerMode { Wrecker, Guest }
public sealed record CaptureProfile
{
    public string Name { get; set; } = "Default";
    public string ScreenName { get; set; } = "";
    public int ScreenWidth { get; set; }
    public int ScreenHeight { get; set; }
    public NormalizedRegion? KickRegion { get; set; }
    public NormalizedRegion? RushRegion { get; set; }
    public byte[]? BaseTemplate { get; set; }
    public byte[]? StrikeTemplate { get; set; }
    public bool Valid => KickRegion?.Valid == true && RushRegion?.Valid == true && CueDetection.UsableTemplate(BaseTemplate);
    public override string ToString() => Name;
}
public sealed record GuestPreferences
{
    public int KickKey { get; set; } = 1;
    public int RollKey { get; set; } = 0x51;
    public int RushKey { get; set; } = 0x46;
    public int ResetKey { get; set; } = 0x76;
    public int PickupKey { get; set; } = 0x79;
    public int LearnKey { get; set; } = 0x75;
    public bool PickupEnabled { get; set; }
    public bool ReadyBeeps { get; set; }
    public int CaptureHz { get; set; } = 20;
    public string ActiveProfile { get; set; } = "";
    public List<CaptureProfile> Profiles { get; set; } = new();
    public GuestTimings Timings { get; set; } = new();
    public CaptureProfile? Profile => Profiles.FirstOrDefault(item => item.Name == ActiveProfile);
    public bool BindingsValid(int controlsKey)
    {
        int[] keys = [KickKey, RollKey, RushKey, ResetKey, LearnKey, PickupKey, controlsKey];
        return keys.All(key => WindowsInput.GuestKeys.Contains(key)) && keys.Distinct().Count() == keys.Length;
    }
    public void Normalize(int controlsKey)
    {
        CaptureHz = Math.Clamp(CaptureHz, 5, 30);
        if (Timings?.Valid != true) Timings = new();
        Profiles = (Profiles ?? new()).Where(profile => profile is not null && profile.Valid && !string.IsNullOrWhiteSpace(profile.Name)).Take(16).ToList();
        if (!BindingsValid(controlsKey))
        {
            // Retain the controls key and choose unused defaults for Guest.
            var used = new HashSet<int> { controlsKey };
            int Pick(int preferred)
            {
                int key = used.Contains(preferred) ? WindowsInput.GuestKeys.First(key => !used.Contains(key)) : preferred;
                used.Add(key); return key;
            }
            KickKey = Pick(1); RollKey = Pick(0x51); RushKey = Pick(0x46); ResetKey = Pick(0x76); LearnKey = Pick(0x75); PickupKey = Pick(0x79);
        }
    }
}
