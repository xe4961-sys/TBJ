using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using FuseTimer.Core;

namespace FuseTimer;

internal static class ScreenCapture
{
    public static Bitmap Bitmap(Rectangle bounds)
    {
        if (bounds.Width < 1 || bounds.Height < 1) throw new ArgumentException("Empty screen region");
        var image = new Bitmap(bounds.Width, bounds.Height, PixelFormat.Format32bppArgb);
        try
        {
            using var graphics = Graphics.FromImage(image);
            graphics.CopyFromScreen(bounds.Location, Point.Empty, bounds.Size, CopyPixelOperation.SourceCopy);
            return image;
        }
        catch { image.Dispose(); throw; }
    }
    public static PixelGrid Read(Rectangle bounds)
    {
        if ((long)bounds.Width * bounds.Height > 200000) throw new ArgumentException("Capture box is too large; select only the ability text.");
        using var image = Bitmap(bounds);
        var data = image.LockBits(new Rectangle(Point.Empty, image.Size), ImageLockMode.ReadOnly, PixelFormat.Format32bppArgb);
        try
        {
            var pixels = new int[image.Width * image.Height];
            for (int y = 0; y < image.Height; y++) Marshal.Copy(data.Scan0 + y * data.Stride, pixels, y * image.Width, image.Width);
            return new(image.Width, image.Height, pixels);
        }
        finally { image.UnlockBits(data); }
    }
    public static Bitmap Preview(PixelGrid grid)
    {
        var image = new Bitmap(grid.Width, grid.Height, PixelFormat.Format32bppArgb);
        var data = image.LockBits(new Rectangle(Point.Empty, image.Size), ImageLockMode.WriteOnly, PixelFormat.Format32bppArgb);
        try { for (int y = 0; y < image.Height; y++) Marshal.Copy(grid.Pixels, y * image.Width, data.Scan0 + y * data.Stride, image.Width); }
        finally { image.UnlockBits(data); }
        return image;
    }
    public static Rectangle Resolve(NormalizedRegion region, Rectangle screen)
    {
        var r = region.Resolve(screen.Width, screen.Height);
        return new Rectangle(screen.X + r.X, screen.Y + r.Y, r.Width, r.Height);
    }
}
