using FuseTimer.Core;
using System.Text.Json;

internal static class GuestTests
{
    private static void True(bool value) { if (!value) throw new Exception("Expected true"); }
    private static void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
    private static void Near(double expected, double actual, double tolerance = .00001) { if (Math.Abs(expected - actual) > tolerance) throw new Exception($"Expected {expected}, got {actual}"); }
    private static PixelGrid Glyph(string[] rows, int color, int scale = 2, int padding = 2)
    {
        int width = rows[0].Length * scale + padding * 2, height = rows.Length * scale + padding * 2;
        int[] pixels = Enumerable.Repeat(unchecked((int)0xff101010), width * height).ToArray();
        for (int y = 0; y < rows.Length; y++) for (int x = 0; x < rows[y].Length; x++)
            if (rows[y][x] == '#') for (int sy = 0; sy < scale; sy++) for (int sx = 0; sx < scale; sx++) pixels[(padding + y * scale + sy) * width + padding + x * scale + sx] = color;
        return new(width, height, pixels);
    }
    public static int Run()
    {
        int passed = 0;
        void Test(string name, Action run) { run(); Console.WriteLine("PASS " + name); passed++; }
        GuestTracker New() => new(new());
        string[] k = ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"];
        string[] s = [".####", "#....", "#....", ".###.", "....#", "....#", "####."];
        int white = unchecked((int)0xffeeeeee), red = unchecked((int)0xffdf6565), green = unchecked((int)0xff87df70), gold = unchecked((int)0xffd8d09a);
        Test("Sweep expiry does not remove independently observed offensive availability", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Base, 118 / 60.0);
            var frame = t.Frame(2); Equal(KickCue.Unknown, frame.Followup); Near(179 / 60.0 - 2, frame.OffensiveRemaining);
            t.ObserveRush(RushCue.Supportive, 179 / 60.0); Near(0, t.Frame(3).OffensiveRemaining);
        });
        Test("unchanged cues and brief uncertainty do not repeatedly extend windows", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Unknown, .5); t.ObserveRush(RushCue.Unknown, .5);
            t.ObserveKick(KickCue.Sweep, 1); t.ObserveRush(RushCue.Offensive, 1);
            Near(118 / 60.0 - 1, t.Frame(1).FollowupRemaining); Near(179 / 60.0 - 1, t.Frame(1).OffensiveRemaining);
        });
        Test("Strike is a separate window, consumed by Kick without consuming Rush availability", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RollPressed(); t.ObserveKick(KickCue.Strike, .1);
            Equal(KickCue.Strike, t.Frame(.2).Followup); Near(118 / 60.0 - .1, t.Frame(.2).FollowupRemaining);
            t.KickPressed(); Equal(KickCue.Unknown, t.Frame(.3).Followup); True(t.Frame(.3).OffensiveRemaining > 0);
        });
        Test("offensive windup, safe point, and sprint deadline match the 60 FPS measurements", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            Equal(RushPhase.OffensiveWindup, t.Frame(.9).Rush);
            Equal(RushPhase.RecastWait, t.Frame(55 / 60.0).Rush);
            Equal(RushPhase.RecastWait, t.Frame(1.04999).Rush);
            Equal(RushPhase.DropkickReady, t.Frame(1.05).Rush);
            Near(55 / 60.0 + 3 - 1.05, t.Frame(1.05).RushTotal);
            Near(55 / 60.0 + 3 - 1.05, t.Frame(1.05).RushRemaining);
            Equal(RushPhase.DropkickReady, t.Frame(55 / 60.0 + 3 - .0001).Rush);
            Equal(RushPhase.Idle, t.Frame(55 / 60.0 + 3).Rush);
        });
        Test("rush variant stays latched when its availability color changes", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            t.ObserveRush(RushCue.Supportive, .5); Equal(RushPhase.DropkickReady, t.Frame(1.1).Rush);
        });
        Test("fresh screen confirmation is required to start Rush", () => {
            var t = New(); t.RushPressed(0); Equal(RushPhase.Idle, t.Frame(.1).Rush); True(t.Frame(.1).Notice.Contains("UNCONFIRMED"));
            t.ObserveRush(RushCue.Offensive, 1); t.RushPressed(1.36); Equal(RushPhase.Idle, t.Frame(1.4).Rush);
            t.ObserveRush(RushCue.Unknown, 2); t.RushPressed(2); Equal(RushPhase.Idle, t.Frame(2).Rush);
        });
        Test("variant confirmation after a key press preserves the original input deadline", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, .12); t.RushPressed(.13, 0);
            Equal(RushPhase.DropkickReady, t.Frame(1.05).Rush); Equal(RushPhase.Idle, t.Frame(55 / 60.0 + 3).Rush);
        });
        Test("a second Rush input cancels startup or consumes the safe Dropkick window", () => {
            var early = New(); early.ObserveRush(RushCue.Offensive, 0); early.RushPressed(0); early.RushPressed(.5);
            Equal(RushPhase.Idle, early.Frame(.5).Rush); Equal("RUSH CANCELLED", early.Frame(.5).Notice);
            var safe = New(); safe.ObserveRush(RushCue.Offensive, 0); safe.RushPressed(0); safe.RushPressed(1.05);
            Equal(RushPhase.Idle, safe.Frame(1.05).Rush); Equal("DROPKICK USED", safe.Frame(1.05).Notice);
        });
        Test("supportive movement and carrying hitbox begin at different measured times", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            Equal(RushPhase.SupportWindup, t.Frame(1.5499).Rush);
            Equal(RushPhase.SupportSprint, t.Frame(1.55).Rush); Near(4, t.Frame(1.55).RushRemaining); True(!t.Frame(1.55).CarryReady);
            True(t.Frame(1.65).CarryReady); Equal(RushPhase.Idle, t.Frame(5.55).Rush);
        });
        Test("manual pickup adds exactly two seconds only during a valid supportive run", () => {
            var t = New(); True(!t.AddPickup(0)); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            True(!t.AddPickup(1.6)); True(t.AddPickup(1.65)); Near(5.9, t.Frame(1.65).RushRemaining); Near(6, t.Frame(1.65).RushTotal);
            Equal(RushPhase.SupportSprint, t.Frame(7.5499).Rush); Equal(RushPhase.Idle, t.Frame(7.55).Rush); True(!t.AddPickup(8));
            var off = New(); off.ObserveRush(RushCue.Offensive, 0); off.RushPressed(0); True(!off.AddPickup(1.7));
        });
        Test("manual reset suppresses current labels until a real label transition", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0); t.Reset(false);
            t.ObserveKick(KickCue.Sweep, .1); t.ObserveRush(RushCue.Offensive, .1);
            Near(0, t.Frame(.1).FollowupRemaining); Near(0, t.Frame(.1).OffensiveRemaining);
            t.ObserveKick(KickCue.Base, .2); t.ObserveKick(KickCue.Sweep, .3); True(t.Frame(.4).FollowupRemaining > 0);
        });
        Test("rush cancellation preserves an unrelated Sweep window", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.CancelRush(.1); Equal(KickCue.Sweep, t.Frame(.2).Followup);
        });
        Test("debouncing requires agreeing samples and retains the first observation time", () => {
            var stable = new StableCue<RushCue>(); True(!stable.Push(RushCue.Offensive, 1)); True(stable.Push(RushCue.Offensive, 1.05)); Near(1, stable.Since);
            True(!stable.Push(RushCue.Supportive, 1.1)); Equal(RushCue.Offensive, stable.Value);
            True(stable.Push(RushCue.Supportive, 1.15)); Equal(RushCue.Supportive, stable.Value); Near(1.1, stable.Since);
        });
        Test("rush colors distinguish supportive, offensive, and uncertain screen regions", () => {
            Equal(RushCue.Supportive, CueDetection.Rush(Glyph(k, green))); Equal(RushCue.Offensive, CueDetection.Rush(Glyph(k, red)));
            Equal(RushCue.Unknown, CueDetection.Rush(Glyph(k, white))); Equal(RushCue.Unknown, CueDetection.Rush(new(5, 5, new int[25])));
        });
        Test("Sweep red and Strike gold are detected without OCR", () => {
            byte[] baseMask = CueDetection.Mask(Glyph(k, white));
            Equal(KickCue.Sweep, CueDetection.Kick(Glyph(s, red), baseMask, null));
            Equal(KickCue.Strike, CueDetection.Kick(Glyph(s, gold), baseMask, null));
            Equal(KickCue.Unknown, CueDetection.Kick(Glyph(s, white), baseMask, null));
        });
        Test("a learned Strike shape recognizes white text and a tinted base Kick stays base", () => {
            byte[] baseMask = CueDetection.Mask(Glyph(k, white)), strikeMask = CueDetection.Mask(Glyph(s, gold));
            Equal(KickCue.Strike, CueDetection.Kick(Glyph(s, white), baseMask, strikeMask));
            Equal(KickCue.Base, CueDetection.Kick(Glyph(k, gold), baseMask, strikeMask));
        });
        Test("template normalization tolerates integer scaling and surrounding padding", () => {
            byte[] first = CueDetection.Mask(Glyph(k, white, 2, 2)); byte[] scaled = CueDetection.Mask(Glyph(k, white, 4, 8));
            True(CueDetection.UsableTemplate(first)); Near(1, CueDetection.Similarity(first, scaled));
            True(!CueDetection.UsableTemplate(new byte[64 * 24])); Near(0, CueDetection.Similarity(first, new byte[5]));
        });
        Test("normalized regions scale to other resolutions and reject invalid bounds", () => {
            var region = new NormalizedRegion(.75, .8, .1, .05);
            Equal((1440, 960, 192, 60), region.Resolve(1920, 1200)); Equal((1920, 1152, 256, 72), region.Resolve(2560, 1440));
            True(!new NormalizedRegion(-.1, 0, .2, .1).Valid); True(!new NormalizedRegion(.9, 0, .2, .1).Valid);
            True(!new NormalizedRegion(0, 0, double.NaN, .1).Valid);
        });
        Test("invalid timing combinations are rejected and measured settings survive JSON", () => {
            True(new GuestTimings().Valid); True(!new GuestTimings { SafeDropkick = .25 }.Valid);
            True(!new GuestTimings { CarryHitbox = 1 }.Valid); True(!new GuestTimings { Sweep = double.NaN }.Valid);
            True(!new GuestTimings { OffensiveSprint = 0 }.Valid);
            var restored = JsonSerializer.Deserialize<GuestTimings>(JsonSerializer.Serialize(new GuestTimings()))!;
            True(restored.Valid); Near(63 / 60.0, restored.SafeDropkick); Near(93 / 60.0, restored.SupportWindup);
        });
        Test("screen disappearance does not invent a new recast or a new offensive window", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Unknown, 1); t.ObserveRush(RushCue.Unknown, 1);
            Equal(KickCue.Unknown, t.Frame(3).Followup); Near(0, t.Frame(3).OffensiveRemaining);
            t.ObserveKick(KickCue.Sweep, 4); t.ObserveRush(RushCue.Offensive, 4);
            Near(0, t.Frame(4).FollowupRemaining); Near(0, t.Frame(4).OffensiveRemaining);
        });
        return passed;
    }
}
