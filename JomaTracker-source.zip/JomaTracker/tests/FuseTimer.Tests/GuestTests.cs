using FuseTimer.Core;
using System.Text.Json;

internal static class GuestTests
{
    private static void True(bool value) { if (!value) throw new Exception("Expected true"); }
    private static void Equal<T>(T expected, T actual) { if (!EqualityComparer<T>.Default.Equals(expected, actual)) throw new Exception($"Expected {expected}, got {actual}"); }
    private static void Near(double expected, double actual, double tolerance = .00001) { if (Math.Abs(expected - actual) > tolerance) throw new Exception($"Expected {expected}, got {actual}"); }
    private static PixelGrid Glyph(string[] rows, int color, int scale = 2, int padding = 2)
    {
        int width = rows[0].Length * scale + padding * 2, height = rows.Length * scale + padding * 2;
        int[] pixels = Enumerable.Repeat(unchecked((int)0xff101010), width * height).ToArray();
        for (int y = 0; y < rows.Length; y++) for (int x = 0; x < rows[y].Length; x++)
            if (rows[y][x] == '#') for (int sy = 0; sy < scale; sy++) for (int sx = 0; sx < scale; sx++) pixels[(padding + y * scale + sy) * width + padding + x * scale + sx] = color;
        return new(width, height, pixels);
    }
    public static int Run()
    {
        int passed = 0;
        void Test(string name, Action run) { run(); Console.WriteLine("PASS " + name); passed++; }
        GuestTracker New() => new(new());
        string[] k = ["#...#", "#..#.", "#.#..", "##...", "#.#..", "#..#.", "#...#"];
        string[] s = [".####", "#....", "#....", ".###.", "....#", "....#", "####."];
        int white = unchecked((int)0xffeeeeee), red = unchecked((int)0xffdf6565), green = unchecked((int)0xff87df70), gold = unchecked((int)0xffd8d09a);
        Test("Sweep expiry does not remove independently observed offensive availability", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Base, 118 / 60.0);
            var frame = t.Frame(2); Equal(KickCue.Unknown, frame.Followup); Near(179 / 60.0 - 2, frame.OffensiveRemaining);
            t.ObserveRush(RushCue.Supportive, 179 / 60.0); Near(0, t.Frame(3).OffensiveRemaining);
        });
        Test("unchanged cues and brief uncertainty do not repeatedly extend windows", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Unknown, .5); t.ObserveRush(RushCue.Unknown, .5);
            t.ObserveKick(KickCue.Sweep, 1); t.ObserveRush(RushCue.Offensive, 1);
            Near(118 / 60.0 - 1, t.Frame(1).FollowupRemaining); Near(179 / 60.0 - 1, t.Frame(1).OffensiveRemaining);
        });
        Test("Strike is a separate window, consumed by Kick without consuming Rush availability", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RollPressed(); t.ObserveKick(KickCue.Strike, .1);
            Equal(KickCue.Strike, t.Frame(.2).Followup); Near(118 / 60.0 - .1, t.Frame(.2).FollowupRemaining);
            t.KickPressed(); Equal(KickCue.Unknown, t.Frame(.3).Followup); True(t.Frame(.3).OffensiveRemaining > 0);
        });
        Test("offensive windup, safe point, and sprint deadline match the 60 FPS measurements", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            Equal(RushPhase.OffensiveWindup, t.Frame(.9).Rush);
            Equal(RushPhase.RecastWait, t.Frame(55 / 60.0).Rush);
            Equal(RushPhase.RecastWait, t.Frame(1.04999).Rush);
            Equal(RushPhase.DropkickReady, t.Frame(1.05).Rush);
            Near(55 / 60.0 + 3 - 1.05, t.Frame(1.05).RushTotal);
            Near(55 / 60.0 + 3 - 1.05, t.Frame(1.05).RushRemaining);
            Equal(RushPhase.DropkickReady, t.Frame(55 / 60.0 + 3 - .0001).Rush);
            Equal(RushPhase.Idle, t.Frame(55 / 60.0 + 3).Rush);
        });
        Test("rush variant stays latched when its availability color changes", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            t.ObserveRush(RushCue.Supportive, .5); Equal(RushPhase.DropkickReady, t.Frame(1.1).Rush);
        });
        Test("fresh screen confirmation is required to start Rush", () => {
            var t = New(); t.RushPressed(0); Equal(RushPhase.Idle, t.Frame(.1).Rush); True(t.Frame(.1).Notice.Contains("UNCONFIRMED"));
            t.ObserveRush(RushCue.Offensive, 1); t.RushPressed(1.36); Equal(RushPhase.Idle, t.Frame(1.4).Rush);
            t.ObserveRush(RushCue.Unknown, 2); t.RushPressed(2); Equal(RushPhase.Idle, t.Frame(2).Rush);
        });
        Test("variant confirmation after a key press preserves the original input deadline", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, .12); t.RushPressed(.13, 0);
            Equal(RushPhase.DropkickReady, t.Frame(1.05).Rush); Equal(RushPhase.Idle, t.Frame(55 / 60.0 + 3).Rush);
        });
        Test("a second Rush input cancels startup or consumes the safe Dropkick window", () => {
            var early = New(); early.ObserveRush(RushCue.Offensive, 0); early.RushPressed(0); early.RushPressed(.5);
            Equal(RushPhase.Idle, early.Frame(.5).Rush); Equal("RUSH CANCELLED", early.Frame(.5).Notice);
            var safe = New(); safe.ObserveRush(RushCue.Offensive, 0); safe.RushPressed(0); safe.RushPressed(1.05);
            Equal(RushPhase.Idle, safe.Frame(1.05).Rush); Equal("DROPKICK USED", safe.Frame(1.05).Notice);
        });
        Test("supportive movement and carrying hitbox begin at different measured times", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            Equal(RushPhase.SupportWindup, t.Frame(1.5499).Rush);
            Equal(RushPhase.SupportSprint, t.Frame(1.55).Rush); Near(4, t.Frame(1.55).RushRemaining); True(!t.Frame(1.55).CarryReady);
            True(t.Frame(1.65).CarryReady); Equal(RushPhase.Idle, t.Frame(5.55).Rush);
        });
        Test("manual pickup adds exactly two seconds only during a valid supportive run", () => {
            var t = New(); True(!t.AddPickup(0)); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            True(!t.AddPickup(1.6)); True(t.AddPickup(1.65)); Near(5.9, t.Frame(1.65).RushRemaining); Near(6, t.Frame(1.65).RushTotal);
            Equal(RushPhase.SupportSprint, t.Frame(7.5499).Rush); Equal(RushPhase.Idle, t.Frame(7.55).Rush); True(!t.AddPickup(8));
            var off = New(); off.ObserveRush(RushCue.Offensive, 0); off.RushPressed(0); True(!off.AddPickup(1.7));
        });
        Test("manual reset suppresses current labels until a real label transition", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0); t.Reset(false);
            t.ObserveKick(KickCue.Sweep, .1); t.ObserveRush(RushCue.Offensive, .1);
            Near(0, t.Frame(.1).FollowupRemaining); Near(0, t.Frame(.1).OffensiveRemaining);
            t.ObserveKick(KickCue.Base, .2); t.ObserveKick(KickCue.Sweep, .3); True(t.Frame(.4).FollowupRemaining > 0);
        });
        Test("rush cancellation preserves an unrelated Sweep window", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.CancelRush(.1); Equal(KickCue.Sweep, t.Frame(.2).Followup);
        });
        Test("debouncing requires agreeing samples and retains the first observation time", () => {
            var stable = new StableCue<RushCue>(); True(!stable.Push(RushCue.Offensive, 1)); True(stable.Push(RushCue.Offensive, 1.05)); Near(1, stable.Since);
            True(!stable.Push(RushCue.Supportive, 1.1)); Equal(RushCue.Offensive, stable.Value);
            True(stable.Push(RushCue.Supportive, 1.15)); Equal(RushCue.Supportive, stable.Value); Near(1.1, stable.Since);
        });
        Test("rush colors distinguish supportive, offensive, and uncertain screen regions", () => {
            Equal(RushCue.Supportive, CueDetection.Rush(Glyph(k, green))); Equal(RushCue.Offensive, CueDetection.Rush(Glyph(k, red)));
            Equal(RushCue.Unknown, CueDetection.Rush(Glyph(k, white))); Equal(RushCue.Unknown, CueDetection.Rush(new(5, 5, new int[25])));
        });
        Test("Sweep red and Strike gold are detected without OCR", () => {
            byte[] baseMask = CueDetection.Mask(Glyph(k, white));
            Equal(KickCue.Sweep, CueDetection.Kick(Glyph(s, red), baseMask, null));
            Equal(KickCue.Strike, CueDetection.Kick(Glyph(s, gold), baseMask, null));
            Equal(KickCue.Unknown, CueDetection.Kick(Glyph(s, white), baseMask, null));
        });
        Test("a learned Strike shape recognizes white text and a tinted base Kick stays base", () => {
            byte[] baseMask = CueDetection.Mask(Glyph(k, white)), strikeMask = CueDetection.Mask(Glyph(s, gold));
            Equal(KickCue.Strike, CueDetection.Kick(Glyph(s, white), baseMask, strikeMask));
            Equal(KickCue.Base, CueDetection.Kick(Glyph(k, gold), baseMask, strikeMask));
        });
        Test("template normalization tolerates integer scaling and surrounding padding", () => {
            byte[] first = CueDetection.Mask(Glyph(k, white, 2, 2)); byte[] scaled = CueDetection.Mask(Glyph(k, white, 4, 8));
            True(CueDetection.UsableTemplate(first)); Near(1, CueDetection.Similarity(first, scaled));
            True(!CueDetection.UsableTemplate(new byte[64 * 24])); Near(0, CueDetection.Similarity(first, new byte[5]));
        });
        Test("normalized regions scale to other resolutions and reject invalid bounds", () => {
            var region = new NormalizedRegion(.75, .8, .1, .05);
            Equal((1440, 960, 192, 60), region.Resolve(1920, 1200)); Equal((1920, 1152, 256, 72), region.Resolve(2560, 1440));
            True(!new NormalizedRegion(-.1, 0, .2, .1).Valid); True(!new NormalizedRegion(.9, 0, .2, .1).Valid);
            True(!new NormalizedRegion(0, 0, double.NaN, .1).Valid);
        });
        Test("invalid timing combinations are rejected and measured settings survive JSON", () => {
            True(new GuestTimings().Valid); True(!new GuestTimings { SafeDropkick = .25 }.Valid);
            True(!new GuestTimings { CarryHitbox = 1 }.Valid); True(!new GuestTimings { Sweep = double.NaN }.Valid);
            True(!new GuestTimings { OffensiveSprint = 0 }.Valid);
            var restored = JsonSerializer.Deserialize<GuestTimings>(JsonSerializer.Serialize(new GuestTimings()))!;
            True(restored.Valid); Near(63 / 60.0, restored.SafeDropkick); Near(93 / 60.0, restored.SupportWindup);
        });
        Test("screen disappearance does not invent a new recast or a new offensive window", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0);
            t.ObserveKick(KickCue.Unknown, 1); t.ObserveRush(RushCue.Unknown, 1);
            Equal(KickCue.Unknown, t.Frame(3).Followup); Near(0, t.Frame(3).OffensiveRemaining);
            t.ObserveKick(KickCue.Sweep, 4); t.ObserveRush(RushCue.Offensive, 4);
            Near(0, t.Frame(4).FollowupRemaining); Near(0, t.Frame(4).OffensiveRemaining);
        });
        Test("offensive sprint duration stays separate from windup and WAIT text", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            var frame = t.Frame(.5); Near(3, frame.SprintRemaining); Near(3, frame.SprintTotal);
            var lines = GuestDisplay.Lines(frame, new(), false, false, "F8");
            True(lines.Any(line => line.Text.StartsWith("OFFENSIVE SPRINT NEXT")));
            True(lines.Any(line => line.Text.StartsWith("WINDUP")));
            True(lines.Any(line => line.Text.StartsWith("WAIT — RECAST CANCELS")));
            True(!lines.Any(line => line.Text == "DROPKICK READY"));
        });
        Test("offensive duration continues through WAIT and remains alongside DROPKICK READY", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            var wait = t.Frame(1); Near(55 / 60.0 + 3 - 1, wait.SprintRemaining);
            var waitLines = GuestDisplay.Lines(wait, new(), false, false, "F8");
            True(waitLines.Any(line => line.Text.StartsWith("OFFENSIVE SPRINT  ")));
            True(waitLines.Any(line => line.Text.StartsWith("WAIT — RECAST CANCELS")));
            var ready = t.Frame(1.05); var readyLines = GuestDisplay.Lines(ready, new(), false, false, "F8");
            True(readyLines.Any(line => line.Text.StartsWith("OFFENSIVE SPRINT  ")));
            True(readyLines.Any(line => line.Text == "DROPKICK READY"));
            True(!readyLines.Any(line => line.Text.StartsWith("WAIT")));
            True(readyLines.Single(line => line.Text.StartsWith("OFFENSIVE SPRINT")).Progress is > 0 and < 1);
        });
        Test("supportive duration starts at four seconds and grows only for a valid pickup", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            Near(4, t.Frame(1).SprintRemaining); Near(4, t.Frame(1.55).SprintRemaining);
            True(t.AddPickup(1.7)); Near(5.85, t.Frame(1.7).SprintRemaining); Near(6, t.Frame(1.7).SprintTotal);
            var lines = GuestDisplay.Lines(t.Frame(1.7), new(), false, false, "F8");
            True(lines.Any(line => line.Text.StartsWith("SUPPORT SPRINT")));
            True(!lines.Any(line => line.Text.Contains("DROPKICK") || line.Text.StartsWith("WAIT")));
        });
        Test("Rush display retains its critical phase alongside independent recast windows", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.ObserveKick(KickCue.Sweep, 0); t.RushPressed(0);
            var lines = GuestDisplay.Lines(t.Frame(.5), new(), false, false, "F8");
            True(lines.Length <= 6); True(lines[0].Text.StartsWith("OFFENSIVE SPRINT"));
            True(lines.Any(line => line.Text.StartsWith("WAIT"))); True(lines.Any(line => line.Text.StartsWith("SWEEP READY")));
            True(lines.Any(line => line.Text.StartsWith("OFFENSIVE AVAILABLE")));
            Equal(0, GuestDisplay.Lines(t.Frame(10), new(), false, false, "F8").Length);
        });
        Test("an overlay moved onto the ability labels is placed clear of both regions", () => {
            var area = new System.Drawing.Rectangle(0, 0, 1920, 1160);
            System.Drawing.Rectangle[] labels = [new(1600, 1060, 90, 30), new(1790, 1035, 105, 25)];
            var original = new System.Drawing.Rectangle(1530, 990, 360, 205);
            var moved = OverlayPlacement.ClearOfLabels(original, area, labels);
            True(moved is not null); True(area.Contains(moved!.Value));
            True(labels.All(label => !moved.Value.IntersectsWith(label)));
        });
        Test("clear overlay placement is preserved on a monitor with a negative origin", () => {
            var area = new System.Drawing.Rectangle(-1920, 0, 1920, 1160);
            var original = new System.Drawing.Rectangle(-400, 200, 360, 205);
            System.Drawing.Rectangle[] labels = [new(-300, 1050, 90, 30)];
            Equal(original, OverlayPlacement.ClearOfLabels(original, area, labels)!.Value);
        });
        Test("an impossible placement reports failure instead of covering capture labels", () => {
            var area = new System.Drawing.Rectangle(0, 0, 100, 100);
            True(OverlayPlacement.ClearOfLabels(area, area, new[] { area }) is null);
        });
        Test("Rush latches a recent confirmed color when its card vanishes at input", () => {
            foreach (var variant in new[] { RushCue.Supportive, RushCue.Offensive }) {
                var t = New(); t.ObserveRush(variant, 0); t.ObserveRush(RushCue.Unknown, .05); t.RushPressed(.06);
                Equal(variant == RushCue.Supportive ? RushPhase.SupportWindup : RushPhase.OffensiveWindup, t.Frame(.07).Rush);
                t.ObserveRush(RushCue.Unknown, .2); t.ObserveRush(RushCue.Unknown, 1.2);
                Equal(variant == RushCue.Supportive ? RushPhase.SupportWindup : RushPhase.DropkickReady, t.Frame(1.2).Rush);
            }
        });
        Test("hidden HUD fallback expires instead of reusing an old Rush variant", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.ObserveRush(RushCue.Unknown, .1); t.RushPressed(.36);
            Equal(RushPhase.Idle, t.Frame(.36).Rush); True(t.Frame(.36).Notice.Contains("UNCONFIRMED"));
            t.ObserveRush(RushCue.Supportive, .4); t.ObserveRush(RushCue.Unknown, .45); t.RushPressed(.46);
            Equal(RushPhase.SupportWindup, t.Frame(.5).Rush);
        });
        Test("confirmed Sweep can select offensive Rush while its own indicator is hidden", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.KickPressed(.1); t.ObserveKick(KickCue.Sweep, .2);
            t.ObserveRush(RushCue.Unknown, .25); t.RushPressed(.3);
            Equal(RushPhase.OffensiveWindup, t.Frame(.4).Rush);
        });
        Test("a missed Kick or a roll-only Strike does not grant offensive Rush", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.KickPressed(.1); t.RushPressed(.2);
            Equal(RushPhase.SupportWindup, t.Frame(.3).Rush);
            var strike = New(); strike.ObserveRush(RushCue.Supportive, 0); strike.RollPressed(); strike.ObserveKick(KickCue.Strike, .1); strike.RushPressed(.2);
            Equal(RushPhase.SupportWindup, strike.Frame(.3).Rush);
        });
        Test("confirmed-hit evidence outlasts Sweep but is cleared when offensive availability ends", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, .1); t.ObserveKick(KickCue.Base, 2);
            t.ObserveRush(RushCue.Unknown, 2.1); t.RushPressed(2.2);
            Equal(RushPhase.OffensiveWindup, t.Frame(2.3).Rush);
            var ended = New(); ended.ObserveKick(KickCue.Sweep, 0); ended.ObserveRush(RushCue.Offensive, .1); ended.ObserveRush(RushCue.Supportive, 2.9); ended.RushPressed(2.95);
            Equal(RushPhase.SupportWindup, ended.Frame(3).Rush);
        });
        Test("a late captured offensive cue recovers an unconfirmed Rush without restarting time", () => {
            var t = New(); t.KickPressed(0); t.RushPressed(.1);
            Equal(RushPhase.Idle, t.Frame(.11).Rush);
            t.ObserveRush(RushCue.Offensive, .2, .12);
            Equal(RushPhase.OffensiveWindup, t.Frame(.21).Rush);
            Equal(RushPhase.DropkickReady, t.Frame(.1 + 1.05).Rush);
            Equal(RushPhase.Idle, t.Frame(.1 + 55 / 60.0 + 3).Rush);
        });
        Test("an early post-Kick confirmation corrects support timing to offensive timing", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.KickPressed(.05); t.RushPressed(.1);
            Equal(RushPhase.SupportWindup, t.Frame(.11).Rush);
            t.ObserveKick(KickCue.Sweep, .08, .18);
            Equal(RushPhase.OffensiveWindup, t.Frame(.2).Rush);
            Equal(RushPhase.DropkickReady, t.Frame(1.15001).Rush);
        });
        Test("late unrelated cues and cancelled requests cannot rewrite or resurrect a Rush", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.KickPressed(.05); t.RushPressed(.1); t.ObserveRush(RushCue.Offensive, .5);
            Equal(RushPhase.SupportWindup, t.Frame(.6).Rush);
            var cancelled = New(); cancelled.KickPressed(0); cancelled.RushPressed(.1); cancelled.RushPressed(.12); cancelled.ObserveRush(RushCue.Offensive, .15);
            Equal(RushPhase.Idle, cancelled.Frame(.2).Rush);
            var used = New(); used.ObserveRush(RushCue.Supportive, 0); used.KickPressed(.05); used.RushPressed(.1); used.RushPressed(.12); used.ObserveRush(RushCue.Offensive, .15);
            Equal(RushPhase.Idle, used.Frame(.2).Rush);
        });
        Test("fast Kick evidence requires an actual fresh offensive cue within the input window", () => {
            var fast = new FastKickEvidence(); True(!fast.Accept(RushCue.Offensive, 0, 0));
            fast.Kick(1); True(fast.IsBurst(1.2)); True(!fast.IsBurst(1.5));
            True(fast.Accept(RushCue.Offensive, 1.05, 1.06));
            True(!fast.Accept(RushCue.Supportive, 1.05, 1.06)); True(!fast.Accept(RushCue.Unknown, 1.05, 1.06));
            True(!fast.Accept(RushCue.Offensive, .9, 1.06)); True(!fast.Accept(RushCue.Offensive, 1.05, 1.4));
            True(!fast.Accept(RushCue.Offensive, 2.1, 2.1)); fast.Reset(); True(!fast.IsBurst(2.2));
        });
        Test("a frame captured before Rush but received afterward can recover the same request", () => {
            var t = New(); t.KickPressed(0); t.RushPressed(.1);
            t.ObserveRush(RushCue.Offensive, .08, .08, .12);
            Equal(RushPhase.OffensiveWindup, t.Frame(.13).Rush);
            Equal(RushPhase.DropkickReady, t.Frame(1.15001).Rush);
        });
        Test("an older asynchronous frame cannot overwrite newer one-shot Rush evidence", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, .12);
            t.ObserveRush(RushCue.Supportive, .10, receivedAt: .13); t.RushPressed(.14);
            Equal(RushPhase.OffensiveWindup, t.Frame(.15).Rush);
        });
        PixelGrid DamageTint(PixelGrid source, double strength, bool gradient = false)
        {
            var pixels = new int[source.Pixels.Length];
            for (int y = 0; y < source.Height; y++) for (int x = 0; x < source.Width; x++) {
                int i = y * source.Width + x, pixel = source.Pixels[i];
                double alpha = Math.Clamp(strength + (gradient ? .18 * x / Math.Max(1, source.Width - 1) : 0), 0, 1);
                int r = (int)Math.Round(((pixel >> 16) & 255) * (1 - alpha) + 255 * alpha);
                int g = (int)Math.Round(((pixel >> 8) & 255) * (1 - alpha));
                int b = (int)Math.Round((pixel & 255) * (1 - alpha));
                pixels[i] = unchecked((int)0xff000000) | (r << 16) | (g << 8) | b;
            }
            return new(source.Width, source.Height, pixels);
        }
        Test("a damage-red wash does not turn supportive green lettering into Offensive Rush", () => {
            foreach (double strength in new[] { .15, .35, .6, .8 })
                Equal(RushCue.Supportive, CueDetection.Rush(DamageTint(Glyph(k, green, 3, 5), strength)));
        });
        Test("genuine offensive red lettering remains detectable during a damage vignette", () => {
            foreach (double strength in new[] { 0, .25, .5, .75 })
                Equal(RushCue.Offensive, CueDetection.Rush(DamageTint(Glyph(k, red, 3, 5), strength)));
        });
        Test("blank solid or smoothly graded red screens do not invent an offensive label", () => {
            var blank = new PixelGrid(100, 35, Enumerable.Repeat(unchecked((int)0xff101010), 3500).ToArray());
            Equal(RushCue.Unknown, CueDetection.Rush(DamageTint(blank, .7)));
            Equal(RushCue.Unknown, CueDetection.Rush(DamageTint(blank, .4, true)));
        });
        Test("a red damage gradient across supportive text cannot select the offensive variant", () => {
            foreach (double strength in new[] { .2, .4, .6 })
                True(CueDetection.Rush(DamageTint(Glyph(k, green, 3, 12), strength, true)) != RushCue.Offensive);
        });
        Test("white ability text under a damage wash does not become a red ability cue", () => {
            var grid = DamageTint(Glyph(s, white, 3, 5), .65);
            Equal(RushCue.Unknown, CueDetection.Rush(grid));
            True(CueDetection.Kick(grid, CueDetection.Mask(Glyph(k, white, 3, 5)), null) != KickCue.Sweep);
        });
        Test("fully obscured text fails closed instead of triggering an offensive window", () => {
            Equal(RushCue.Unknown, CueDetection.Rush(DamageTint(Glyph(k, green, 3, 5), 1)));
            var t = New(); t.ObserveRush(CueDetection.Rush(DamageTint(Glyph(k, green, 3, 5), 1)), 0);
            Near(0, t.Frame(.1).OffensiveRemaining);
        });
        Test("compact display combines independent windows without bars and retains safe recast phase", () => {
            var t = New(); t.ObserveKick(KickCue.Sweep, 0); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(0);
            foreach (double now in new[] { .2, .95, 1.1 }) {
                var lines = GuestDisplay.Lines(t.Frame(now), new(), false, false, "F8", true);
                Equal(2, lines.Length); True(lines.All(line => line.Progress is null));
                True(lines[1].Text.Contains("SWEEP") && lines[1].Text.Contains("OFF"));
                True(lines[0].Text.Contains(now < .9 ? "WINDUP" : now < 1.05 ? "WAIT" : "READY"));
            }
        });
        Test("compact display stays hidden when idle and keeps cancellation feedback", () => {
            var t = New(); Equal(0, GuestDisplay.Lines(t.Frame(0), new(), false, false, "F8", true).Length);
            Equal(1, GuestDisplay.Lines(t.Frame(0), new(), false, true, "F8", true).Length);
            t.CancelRush(1);
            True(GuestDisplay.Lines(t.Frame(1), new(), false, false, "F8", true).Single().Text.Contains("CANCELLED"));
        });
        PixelGrid Canvas(params (PixelGrid Grid, int X, int Y)[] pieces)
        {
            int width = 350, height = 100;
            int[] pixels = Enumerable.Repeat(unchecked((int)0xff101010), width * height).ToArray();
            foreach (var piece in pieces) for (int y = 0; y < piece.Grid.Height; y++) for (int x = 0; x < piece.Grid.Width; x++)
                pixels[(piece.Y + y) * width + piece.X + x] = piece.Grid.Pixels[y * piece.Grid.Width + x];
            return new(width, height, pixels);
        }
        string[] phrase = Enumerable.Range(0, 7).Select(y => k[y] + ".." + s[y] + ".." + s[y] + ".." + k[y] + ".." + s[y]).ToArray();
        var phraseGrid = Glyph(phrase, white);
        var phraseTemplate = TextEventDetection.Learn(phraseGrid);
        Test("XP phrase matching ignores colored numeric prefixes and counts separate scrolling rows", () => {
            True(phraseTemplate.Valid);
            var image = Canvas((Glyph(k, gold), 5, 8), (phraseGrid, 80, 8), (Glyph(s, red), 8, 50), (phraseGrid, 110, 50));
            Equal(2, TextEventDetection.Count(image, phraseTemplate));
            Equal(1, TextEventDetection.Count(Canvas((phraseGrid, 160, 25)), phraseTemplate));
            Equal(0, TextEventDetection.Count(Canvas(), phraseTemplate));
            Equal(0, TextEventDetection.Count(Canvas((Glyph(k, white), 100, 10)), phraseTemplate));
        });
        Test("XP templates survive settings serialization and calibrated resolution scaling", () => {
            var restored = JsonSerializer.Deserialize<TextEventTemplate>(JsonSerializer.Serialize(phraseTemplate))!;
            True(restored.Valid);
            var scaled = TextEventDetection.Scale(restored, 2, 2);
            Equal(1, TextEventDetection.Count(Canvas((Glyph(phrase, white, 4), 20, 10)), scaled));
            True(!TextEventDetection.Learn(Glyph(k, red)).Valid);
        });
        Test("a lingering or moving XP message never refreshes on M1 alone", () => {
            var gate = new SweepEventGate();
            True(!gate.Sample(1, 0, true)); True(!gate.Sample(1, .1, true));
            gate.Kick(.2);
            True(!gate.Sample(1, .3, true)); True(!gate.Sample(1, .4, true));
            True(!gate.Sample(0, .5, true)); True(!gate.Sample(1, .6, true)); True(!gate.Sample(1, .7, true));
        });
        Test("only a newly confirmed XP event after an attack triggers once", () => {
            var gate = new SweepEventGate(); gate.Sample(0, 0, true); gate.Sample(0, .1, true); gate.Kick(.2);
            True(!gate.Sample(1, .3, true)); True(gate.Sample(1, .4, true)); Near(.3, gate.EventAt);
            True(!gate.Sample(1, .5, true)); gate.Kick(.6);
            True(!gate.Sample(2, .7, true)); True(gate.Sample(2, .8, true));
            True(!gate.Sample(3, .9, true)); True(!gate.Sample(3, 1, true));
        });
        Test("a message first observed before the attack cannot become new hit evidence when its confirmation arrives late", () => {
            var gate = new SweepEventGate(); gate.Sample(0, 0, true); gate.Sample(0, .1, true);
            gate.Sample(1, .2, true); gate.Kick(.25); True(!gate.Sample(1, .3, true));
        });
        Test("XP events seen in settings or outside the recent attack window do not count", () => {
            var gate = new SweepEventGate(); gate.Sample(0, 0, false); gate.Sample(0, .1, false); gate.Kick(.2);
            True(!gate.Sample(1, .3, false)); True(!gate.Sample(1, .4, false)); True(!gate.Sample(1, .5, true));
            True(!gate.Sample(2, 2, true)); True(!gate.Sample(2, 2.1, true));
        });
        Test("a landed Sweep refreshes Offensive availability while red remains unchanged without extending an active Rush", () => {
            var t = New(); t.ObserveRush(RushCue.Offensive, 0); t.RushPressed(.1);
            t.KickPressed(.5); t.LandedSweep(.8); t.ObserveRush(RushCue.Offensive, 1.2);
            Near(179 / 60.0 - .4, t.Frame(1.2).OffensiveRemaining);
            Near(.1 + 55 / 60.0 + 3 - 1.2, t.Frame(1.2).SprintRemaining);
            t.ObserveRush(RushCue.Supportive, 1.3); Near(0, t.Frame(1.3).OffensiveRemaining);
        });
        PixelGrid Box(bool red)
        {
            int[] pixels = Enumerable.Repeat(unchecked((int)0xff302a35), 10000).ToArray();
            for (int y = 10; y < 90; y++) for (int x = 10; x < 90; x++)
                if (x < 20 || x >= 80) pixels[y * 100 + x] = red ? unchecked((int)0xffc83644) : unchecked((int)0xff55bb66);
            return new(100, 100, pixels);
        }
        Test("passenger cue checks broad red geometry rather than the green capsule", () => {
            True(PassengerDetection.RedBox(Box(true))); True(!PassengerDetection.RedBox(Box(false)));
            True(!PassengerDetection.RedBox(new(100, 100, Enumerable.Repeat(unchecked((int)0xffdd3333), 10000).ToArray())));
        });
        Test("passenger inference requires sustained presence then loss after the carry startup and adds time once", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            var gate = new PassengerGate(); gate.Start(0);
            foreach (double now in new[] { 1.65, 1.75, 1.85 }) True(!gate.Sample(true, now, t.Frame(now), true));
            True(!gate.Sample(false, 2, t.Frame(2), true)); True(!gate.Sample(false, 2.1, t.Frame(2.1), true));
            True(gate.Sample(false, 2.2, t.Frame(2.2), true)); True(t.AddPickup(2.2, true));
            Near(5.55 + 2 - 2.2, t.Frame(2.2).RushRemaining); True(t.Frame(2.2).Notice.Contains("PICKUP?"));
            True(!gate.Sample(false, 2.3, t.Frame(2.3), true));
        });
        Test("unseen boxes, short occlusions, manual pickups and ended Rushes cannot grant an inferred pickup", () => {
            var t = New(); t.ObserveRush(RushCue.Supportive, 0); t.RushPressed(0);
            var gate = new PassengerGate(); gate.Start(0);
            foreach (double now in new[] { 1.7, 1.8, 1.9 }) True(!gate.Sample(false, now, t.Frame(now), true));
            foreach (double now in new[] { 2.0, 2.1, 2.2 }) gate.Sample(true, now, t.Frame(now), true);
            True(!gate.Sample(false, 2.3, t.Frame(2.3), true)); True(!gate.Sample(true, 2.4, t.Frame(2.4), true));
            gate.MarkUsed(); True(!gate.Sample(false, 2.5, t.Frame(2.5), true)); True(!gate.Sample(false, 2.8, t.Frame(2.8), true));
            gate.Start(0); foreach (double now in new[] { 5.0, 5.1, 5.2 }) gate.Sample(true, now, t.Frame(now), true);
            True(!gate.Sample(false, 5.3, t.Frame(5.3), true)); True(!gate.Sample(false, 5.6, t.Frame(5.6), true));
        });
        return passed;
    }
}
