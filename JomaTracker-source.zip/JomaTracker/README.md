# Joma Tracker 2.0

A portable Windows 10/11 x64 overlay with **Wrecker** and **Guest** modes. Wrecker retains the grenade timer; Guest tracks recast windows from configured inputs and two calibrated ability-label regions. This is the first Guest test build. It does not read game memory or detect actual hitboxes.

## Start and update

1. Exit the previous Fuse Timer / Joma Tracker from its tray icon first. They share a single-instance guard so two versions cannot compete for inputs/audio.
2. Extract `JomaTracker-Windows-x64.zip` and run **JomaTracker.exe**. No separate .NET installation is required.
3. It starts hidden. Press **F8** (or your saved controls key) or double-click the clock tray icon.
4. Select the **Wrecker** or **Guest** tab. Only the selected mode runs; the selection is saved.
5. Hide controls before playing. Ability inputs are paused while controls are open; Guest's detection preview continues. Closing/minimizing controls hides them; **Exit app** / tray **Exit** quits.

## Wrecker

The default grenade key is **G**, configurable to match the game. The app observes the key without blocking or replaying it. A fresh press restarts the sequence; holding it triggers once.

| Default time after priming | Overlay / sound |
| --- | --- |
| 0–3.00s | Countdown; accelerating electronic beeps |
| 3.00–3.20s | ARMED; urgent beeps |
| 3.20–3.70s | RELEASE!; urgent beeps |
| 3.70–4.00s | BULLSEYE!! in green; audio stops |
| After 4.00s | Overlay hides by default |

Seconds until ARMED is adjustable. The following phases remain 0.20s / 0.50s / 0.30s. There is no spoken voice or added explosion sound. BULLSEYE is a timing marker, not detection of an actual hit.

## Guest: first-time calibration

Use **windowed or borderless** gameplay. A desktop overlay may not appear above exclusive fullscreen, and protected/unsupported screen surfaces may capture as black.

1. Make base **Kick** and the colored **Supportive / Offensive** Rush prefix visible. Keep controls away from these HUD areas.
2. Open Guest settings. Choose the monitor, enter a profile name, then click **Calibrate text regions**. Controls hide and the monitor image freezes for selection.
3. Drag a tight box around the **Kick word only**, allowing enough empty width for Sweep/Strike. Exclude the card border and LMB icon. This captures the base Kick shape.
4. Drag a tight box around the colored **Supportive / Offensive word only**. Exclude the white Rush word and F icon.
5. Calibration saves automatically. Check the two live crops and the Kick/Rush detection text. Unknown means the cue is not confirmed; a timer should not invent a Rush variant.
6. For reliable white/gold Strike recognition, click **Learn Strike label**, hide controls, perform a roll in game, and press **F6** (default Learn key) while **Strike** is visible. Only the normalized text mask is saved; no gameplay recording is stored. A sample matching base Kick is rejected.
7. Return to controls to inspect recognition. Switch between actual ability states; verify Base / Sweep / Strike and Supportive / Offensive before relying on timings. Then hide controls to play.

Profiles store normalized coordinates, monitor identity, and base/Strike text masks. Selecting another saved profile restores its regions. Saving calibration under an existing name replaces it. Integer scaling is handled by mask normalization; different aspect ratios, HUD scaling, monitor layouts, and font rendering can still require a new calibration/profile. Maximum individual capture region: 200,000 pixels; select text, not the full screen.

## Guest behavior and defaults

All timing fields are adjustable, using the user's 60 FPS measurements as defaults:

| Event | Default |
| --- | --- |
| Sweep recast window | 118/60s = 1.967s |
| Strike availability window | 118/60s = 1.967s |
| Offensive Rush availability | 179/60s = 2.983s |
| Supportive movement windup | 93/60s = 1.550s |
| Supportive carrying hitbox delay | 99/60s = 1.650s |
| Offensive movement windup | 55/60s = 0.917s |
| Safe Dropkick delay, from Rush input | 63/60s = 1.050s |
| Supportive / offensive sprint | 4s / 3s after the respective windup |

- Red Sweep starts its follow-up window. Gold Strike or a learned Strike mask starts Strike. Base Kick clears the follow-up. Kick consumes the displayed follow-up; Roll also clears it until another label confirms availability. Enhanced Kick is excluded.
- The separate Rush color confirms offensive availability. Sweep ending does not clear it. Availability windows count from the first consistent screen observation, capped at the configured duration; returning to the base/supportive cue ends the respective window early. Starting tracking halfway through a window cannot recover its original start time.
- Rush input briefly allows two detector samples to catch up to a recent hit (usually about 0.15–0.20s at the default 20 checks/s; at most 0.50s). The countdown stays anchored to the original input timestamp. A missing/uncertain/stale indicator shows **RUSH UNCONFIRMED** instead of selecting a variant. This does not delay or alter the game's input.
- The selected Rush variant stays locked for that run even if its HUD color changes. Offensive Rush shows a windup/wait warning, then **DROPKICK READY** from 1.05s until about 3.917s after input. A second Rush input consumes the window; during startup it is treated as cancellation. This assumes the game accepts the input.
- Supportive Rush shows its windup then a four-second sprint. Optional **manual ally pickup +2s** is off by default. When enabled, each pickup-key press after the carrying hitbox starts adds two seconds to that supportive run. Use it only for a real pickup; no automatic pickup detection is implemented.
- Windows have numeric timers and shrinking bars. The overlay hides when idle by default. **Reset Guest windows** clears estimates without instantly restarting from an unchanged label.
- Cooldowns, Enhanced Kick, actual hitbox detection, and automatic wall/stun/end detection are excluded. Use reset for interruptions.

### Guest bindings

| Action | Default |
| --- | --- |
| Kick / recast | Left mouse |
| Dodgeroll | Q |
| Rush / Dropkick | F |
| Reset Guest windows | F7 |
| Learn Strike sample | F6 |
| Manual pickup +2s (optional, initially disabled) | F10 |
| Open / hide controls (both modes) | F8 |

Click a binding button, release held keys/buttons, then press its replacement. Escape cancels; capture times out after 15 seconds. Guest binds and the controls key must differ, including the optional pickup key. The Wrecker grenade bind may overlap a Guest ability because only one mode runs. The app does not change in-game binds: configure it to match them.

## Shared controls

- **Tracking enabled** pauses/resumes tracking and Guest capture.
- **Sound on / Volume** affect all cues. Guest readiness beeps are separately optional, off by default.
- **Test sound** plays a longer beep and reconnects to the default Windows output. Errors are visible. **Windows mixer** opens app volume/output settings.
- **Hide idle overlay** hides inactive timers. **Wrecker text pulse** controls gentle 2 Hz ARMED/RELEASE pulsing only.
- **Position overlay** allows dragging the text; click Done positioning to restore click-through. Keep the overlay away from the calibrated HUD regions. Guest and Wrecker positions are saved separately. The normal overlay is transparent, borderless, topmost, non-activating, and has no taskbar entry.

## Capture and performance

Guest uses GDI screen copies of the two selected regions, then simple color checks and normalized binary-mask matching. There is no OCR model, full-frame recognition loop, video encoding, network access, or gameplay recording. One background capture job is allowed at a time. Consecutive agreeing samples reduce false positives. The default rate is **20 checks/second**, adjustable from **5 to 30**. Wrecker mode does not capture the screen.

The preview reports the last capture/analysis wall time, not FPS loss or GPU utilization. Detection has capture/scheduling latency; low sample rates, animation fades, scaling, obstructed HUDs, or stale frames may affect accuracy. We have not measured in-game FPS impact. Compare tracking on/off on the target PC; reducing checks/s reduces work and increases detection latency.

Settings remain in `%LOCALAPPDATA%\FuseTimer\settings.json` for compatibility with the previous app. Existing Wrecker mute/volume/binds are preserved. All captures are discarded except the normalized base/Strike label masks saved in the selected profile. There is no telemetry. The program observes only configured keys outside explicit bind capture; it never injects input or logs key history.

## Build and validation

Use the official .NET 10 SDK pinned in `global.json`:

```powershell
dotnet run --project tests/FuseTimer.Tests -c Release
dotnet publish src/FuseTimer.App -c Release -r win-x64 --self-contained true -o artifacts/win-x64
```

`build.ps1` tests, builds, and creates the portable ZIP. A Windows CI workflow is included in the source archive. Binaries/source ZIPs are published only on TBJ's separate `fuse-timer-download` branch; do not merge it into the website's main branch.

**45 tests pass** for Wrecker timing/audio regression, Guest timing boundaries, independent windows, input consumption, stale-cue rejection, variant locking, manual extensions, resets, debounce, normalized region scaling, and synthetic color/template samples. The Windows app is cross-compiled on Linux. Actual Windows capture, calibration UI, mixed-DPI behavior, game input, native overlay drawing, and speaker output still require a Windows gameplay test. Detector tests use synthetic images; they do not establish accuracy on live gameplay. The self-contained Windows x64 executable is unsigned.
